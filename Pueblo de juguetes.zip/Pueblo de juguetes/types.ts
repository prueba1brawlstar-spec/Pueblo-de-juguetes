
export enum ToyType {
  CARRO = 'Carro',
  ANIMAL = 'Animal',
  MONSTRUO = 'Monstruo',
  PLANTA = 'Planta',
  DINOSAURIO = 'Dinosaurio',
  TAPA = 'Tapa',
}

export type Gender = 'male' | 'female';

export type RelationType = 
  | 'Padre' | 'Madre' 
  | 'Hijo' | 'Hija' 
  | 'Hermano' | 'Hermana' 
  | 'Abuelo' | 'Abuela' 
  | 'Nieto' | 'Nieta' 
  | 'Bisabuelo' | 'Bisabuela' 
  | 'Bisnieto' | 'Bisnieta' 
  | 'Esposo' | 'Esposa' 
  | 'Suegro' | 'Suegra' 
  | 'Yerno' | 'Nuera' 
  | 'Cuñado' | 'Cuñada' 
  | 'Tío' | 'Tía' 
  | 'Sobrino' | 'Sobrina'
  | 'Primo' | 'Prima'
  | 'Pareja';

export interface Relation {
  toyId: string;
  type: RelationType;
}

export interface Toy {
  id: string;
  name: string;
  family: string;
  subFamily?: string; 
  isSubFamilyLeader?: boolean; 
  type: ToyType;
  gender: Gender;
  age?: number | null;      
  birthday?: string | null; 
  isLeader?: boolean;
  createdAt: number;
  relations?: Relation[]; 
  bankAccountId?: string | null; 
  accountBalance?: number;       
}

export interface BankEmployee {
  id: string;
  toyId: string;
  role: string; 
  salary: number;
}

export interface Bank {
  id: string; 
  name: string;
  ownerId: string;
  ownerPercentage: number; // 0-70
  employees: BankEmployee[];
  funds: number;
  fundsSuffix: string; 
  roleSalaries: Record<string, number>; 
  lastPayrollDate: number; 
}

export interface CompanyEmployee {
  id: string;
  toyId: string;
  role: string;
  salary: number;
}

export interface CompanyRole {
  id: string;
  name: string;
  baseSalary: number;
  salarySuffix?: string; // Helper for display
}

export interface Company {
  id: string;
  name: string;
  website?: string;
  capitalAmount: number;
  capitalSuffix: string; 
  description?: string;
  ownerId: string;
  bankAccountId?: string | null; // Linked Bank for finances
  createdAt: number;
  employees: CompanyEmployee[]; 
  customRoles: CompanyRole[]; 
}

// --- COLLEGE & EDUCATION TYPES ---

export interface Subject {
  id: string;
  name: string;
  professorId?: string; // Teacher Toy ID
}

export interface GradeScore {
  subjectId: string;
  period: 1 | 2 | 3 | 4;
  score: number; // 0.0 to 5.0 or 10.0
}

export interface StudentRecord {
  toyId: string;
  courseId: string; // "1A", "11B", etc.
  grades: GradeScore[];
}

export interface Course {
  id: string;
  name: string; // "Primero", "Segundo", etc.
  schedule: string; // "7:00 AM - 1:00 PM"
}

export interface College {
  id: string;
  name: string;
  directorId: string; // Principal/Owner
  subjects: Subject[];
  courses: Course[];
  students: StudentRecord[];
}

// --- END COLLEGE TYPES ---

export interface Law {
  id: string;
  title: string;
  description: string;
  creatorId: string;
  createdAt: number;
}

export interface Mandate {
  year: string;
  presidentId: string | null;
  vicePresidentId: string | null;
  mayorId: string | null;
}

export interface Government {
  presidentId: string | null;
  vicePresidentId: string | null;
  mayorId: string | null;
  termYear: string;
  history?: Mandate[]; 
}

export interface CrimeRecord {
  id: string;
  criminalId: string;
  crime: string;
  bailAmount: number;
  sentenceDays: number; 
  timestamp: number;
  active: boolean; 
}

export interface PoliceData {
  commissionerId: string | null; 
  officers: string[]; 
  prisoners: string[]; 
  records: CrimeRecord[]; 
}

// --- SOCIAL MEDIA TYPES ---
export type SocialPlatform = 'YouTube' | 'Instagram' | 'TikTok' | 'X' | 'Twitch' | 'Facebook';

export interface ContentItem {
  id: string;
  title: string;
  views: number;
  viewsSuffix: string; // K, M, B, etc.
  timestamp: number;
}

export interface SocialProfile {
  id: string;
  toyId: string; // The influencer
  handle: string; // @name
  platform: SocialPlatform;
  followers: number;
  followersSuffix: string;
  content: ContentItem[];
  joinedAt: number;
}

export interface HistoryLog {
  id: string;
  action: 'create' | 'update' | 'delete' | 'join';
  description: string;
  timestamp: number;
  author?: string; 
}

export interface TownMember {
  userId: string;
  name: string;
  role: 'admin' | 'member'; 
  joinedAt: number;
}

export interface JoinRequest {
  userId: string;
  name: string;
  timestamp: number;
}

export interface TownData {
  name: string;
  status: 'pendiente' | 'aprobado' | 'rechazado';
  createdAt: number;
  members: TownMember[]; 
  joinRequests: JoinRequest[]; 
  toys: Toy[];
  banks: Bank[];
  companies: Company[];
  colleges?: College[]; 
  government: Government;
  police?: PoliceData; 
  laws: Law[];
  socialProfiles?: SocialProfile[]; 
  history: HistoryLog[];
}
