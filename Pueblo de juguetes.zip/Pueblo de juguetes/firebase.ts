
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from "firebase/firestore";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCwAXiK1-WDEmQ-jlymw7SYKgE7-pWkYJQ",
  authDomain: "pueblojuguetes.firebaseapp.com",
  projectId: "pueblojuguetes",
  storageBucket: "pueblojuguetes.firebasestorage.app",
  messagingSenderId: "409865589014",
  appId: "1:409865589014:web:cd8a42df0903becccc0037",
  measurementId: "G-B3HLKQZ199"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Analytics (safely)
let analytics;
if (typeof window !== 'undefined') {
  try {
    analytics = getAnalytics(app);
  } catch (e) {
    console.warn("Analytics failed to initialize", e);
  }
}
export { analytics };

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Initialize Firestore with offline persistence enabled
// We use persistentLocalCache to allow offline usage.
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager()
  })
});
