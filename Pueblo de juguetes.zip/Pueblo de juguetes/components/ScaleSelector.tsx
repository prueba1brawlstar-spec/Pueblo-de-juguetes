
import React, { useState } from 'react';
import { Search, Check, Coins, X } from 'lucide-react';

interface ScaleSelectorProps {
  scales: string[];
  currentScale: string;
  onSelect: (scale: string) => void;
  onClose: () => void;
}

export const ScaleSelector: React.FC<ScaleSelectorProps> = ({ scales, currentScale, onSelect, onClose }) => {
  const [search, setSearch] = useState('');

  const filteredScales = scales.filter(s => 
    s.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-x-0 top-0 safe-screen z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm border border-slate-200 overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 bg-slate-50 shrink-0">
          <div className="flex justify-between items-center mb-3">
             <h3 className="font-bold text-slate-700 text-lg flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-500" />
                Escala Monetaria
             </h3>
             <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
                 <X className="w-5 h-5" />
             </button>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              autoFocus
              placeholder="Buscar escala..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-3 bg-white border border-slate-300 rounded-xl text-sm font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none shadow-sm placeholder:text-slate-400"
            />
          </div>
        </div>

        {/* List */}
        <div className="overflow-y-auto flex-1 p-2 space-y-1 custom-scrollbar bg-white">
          {filteredScales.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm font-medium">
              No se encontraron resultados.
            </div>
          ) : (
            filteredScales.map(scale => (
              <button
                key={scale}
                onClick={() => onSelect(scale)}
                className={`w-full flex items-center justify-between p-3 rounded-lg group transition-colors text-left border ${
                    scale === currentScale 
                    ? 'bg-blue-50 border-blue-200' 
                    : 'bg-white border-transparent hover:bg-slate-50 hover:border-slate-100'
                }`}
              >
                <span className={`font-bold text-sm ${scale === currentScale ? 'text-blue-700' : 'text-slate-600'}`}>
                    {scale}
                </span>
                {scale === currentScale && <Check className="w-4 h-4 text-blue-600" />}
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
