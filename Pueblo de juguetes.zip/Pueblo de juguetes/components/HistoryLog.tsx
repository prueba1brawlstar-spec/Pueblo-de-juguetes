
import React, { useEffect } from 'react';
import { History, X, Clock, Activity } from 'lucide-react';
import { HistoryLog } from '../types';

interface HistoryLogProps {
  logs: HistoryLog[];
  onClose: () => void;
}

export const HistoryLogModal: React.FC<HistoryLogProps> = ({ logs, onClose }) => {
  // Sort logs by newest first
  const sortedLogs = [...logs].sort((a, b) => b.timestamp - a.timestamp);

  useEffect(() => {
    // Prevent body scrolling when modal is open
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, []);

  return (
    <div className="fixed inset-x-0 top-0 safe-screen z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[85vh] border border-slate-200">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-purple-100 rounded-lg">
                <Activity className="w-5 h-5 text-purple-600" />
            </div>
            <div>
                <h3 className="font-bold text-slate-800 text-lg">Historial de Cambios</h3>
                <p className="text-xs text-slate-500">Registro de actividad del pueblo</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        {/* List */}
        <div className="overflow-y-auto flex-1 p-4 space-y-4 custom-scrollbar bg-slate-50/50">
          {sortedLogs.length === 0 ? (
            <div className="text-center py-10 text-slate-400 flex flex-col items-center">
              <History className="w-12 h-12 mb-2 opacity-50" />
              <p>No hay actividad registrada aún.</p>
            </div>
          ) : (
            sortedLogs.map(log => (
              <div key={log.id} className="flex gap-4 relative animate-in slide-in-from-left-2 duration-300">
                 {/* Timeline line */}
                 <div className="absolute left-[19px] top-8 bottom-[-16px] w-0.5 bg-slate-200 last:hidden"></div>
                 
                 <div className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center shrink-0 shadow-sm z-10">
                    <Clock className="w-4 h-4 text-slate-400" />
                 </div>
                 
                 <div className="flex-1 bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                    <div className="flex justify-between items-start mb-1">
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                            log.action === 'create' ? 'bg-green-100 text-green-700' :
                            log.action === 'delete' ? 'bg-red-100 text-red-700' :
                            log.action === 'update' ? 'bg-blue-100 text-blue-700' :
                            'bg-slate-100 text-slate-700'
                        }`}>
                            {log.action === 'create' ? 'Creación' : 
                             log.action === 'delete' ? 'Eliminación' : 
                             log.action === 'update' ? 'Actualización' : 'Ingreso'}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                            {new Date(log.timestamp).toLocaleTimeString()}
                        </span>
                    </div>
                    <p className="text-sm text-slate-700 font-medium leading-relaxed">
                        {log.description}
                    </p>
                 </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
