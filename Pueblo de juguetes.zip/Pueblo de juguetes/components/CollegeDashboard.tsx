import React, { useState } from 'react';
import { GraduationCap, ArrowLeft, Plus, Book, Calendar, UserCheck, Edit3, Save, Trash2, Clock, Users, BookOpen } from 'lucide-react';
import { Toy, College, Subject, Course, StudentRecord, GradeScore } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';
import { NotificationModal, NotificationType } from './NotificationModal';

interface CollegeDashboardProps {
  toys: Toy[];
  colleges: College[];
  onUpdateColleges: (colleges: College[]) => void;
  onBack: () => void;
}

const GRADES = [
    "Primero", "Segundo", "Tercero", "Cuarto", "Quinto", "Sexto", 
    "Séptimo", "Octavo", "Noveno", "Décimo", "Undécimo"
];

export const CollegeDashboard: React.FC<CollegeDashboardProps> = ({ toys, colleges, onUpdateColleges, onBack }) => {
  const [view, setView] = useState<'create' | 'main' | 'subjects' | 'courses' | 'grades'>('main');
  const [activeCollege, setActiveCollege] = useState<College | null>(colleges.length > 0 ? colleges[0] : null);
  
  // Forms State
  const [newCollegeName, setNewCollegeName] = useState('');
  const [newDirectorId, setNewDirectorId] = useState<string | null>(null);
  const [showDirectorSelector, setShowDirectorSelector] = useState(false);
  
  const [newSubjectName, setNewSubjectName] = useState('');
  const [newProfId, setNewProfId] = useState<string | null>(null);
  const [showProfSelector, setShowProfSelector] = useState(false);

  const [newCourseName, setNewCourseName] = useState(GRADES[0]);
  const [newSchedule, setNewSchedule] = useState('');
  const [showStudentSelector, setShowStudentSelector] = useState(false);
  const [targetCourseId, setTargetCourseId] = useState<string | null>(null);

  // Grading State
  const [selectedGradeCourse, setSelectedGradeCourse] = useState<string | null>(null);
  const [selectedStudentForGrade, setSelectedStudentForGrade] = useState<StudentRecord | null>(null);
  const [editingGrades, setEditingGrades] = useState<Record<string, string>>({}); // subjectId-period: score

  const [notification, setNotification] = useState<{show: boolean, type: NotificationType, title: string, message: string}>({ show: false, type: 'info', title: '', message: '' });

  // -- COLLEGE MANAGEMENT --
  const handleCreateCollege = () => {
      if (!newCollegeName || !newDirectorId) return;
      const newCollege: College = {
          id: crypto.randomUUID(),
          name: newCollegeName,
          directorId: newDirectorId,
          subjects: [],
          courses: [],
          students: []
      };
      const updated = [...colleges, newCollege];
      onUpdateColleges(updated);
      setActiveCollege(newCollege);
      setView('main');
  };

  const updateActiveCollege = (updated: College) => {
      const newColleges = colleges.map(c => c.id === updated.id ? updated : c);
      onUpdateColleges(newColleges);
      setActiveCollege(updated);
  };

  // -- SUBJECTS --
  const handleAddSubject = () => {
      if (!activeCollege || !newSubjectName) return;
      const newSubject: Subject = {
          id: crypto.randomUUID(),
          name: newSubjectName,
          professorId: newProfId || undefined
      };
      updateActiveCollege({ ...activeCollege, subjects: [...activeCollege.subjects, newSubject] });
      setNewSubjectName('');
      setNewProfId(null);
      setNotification({ show: true, type: 'success', title: 'Materia Creada', message: 'Se ha añadido la materia al currículo.' });
  };

  const handleDeleteSubject = (id: string) => {
      if (!activeCollege) return;
      updateActiveCollege({ ...activeCollege, subjects: activeCollege.subjects.filter(s => s.id !== id) });
  };

  // -- COURSES --
  const handleAddCourse = () => {
      if (!activeCollege || !newCourseName || !newSchedule) return;
      const newCourse: Course = {
          id: crypto.randomUUID(),
          name: newCourseName,
          schedule: newSchedule
      };
      updateActiveCollege({ ...activeCollege, courses: [...activeCollege.courses, newCourse] });
      setNewSchedule('');
      setNotification({ show: true, type: 'success', title: 'Curso Abierto', message: `Se ha abierto el grado ${newCourseName}.` });
  };

  const handleEnrollStudent = (toyId: string) => {
      if (!activeCollege || !targetCourseId) return;
      
      // Check if already enrolled in ANY course of this college
      const existingRecord = activeCollege.students.find(s => s.toyId === toyId);
      if (existingRecord) {
          setNotification({ show: true, type: 'error', title: 'Estudiante Matriculado', message: 'Este habitante ya estudia en este colegio.' });
          return;
      }

      const newRecord: StudentRecord = {
          toyId,
          courseId: targetCourseId,
          grades: []
      };
      
      updateActiveCollege({ ...activeCollege, students: [...activeCollege.students, newRecord] });
      setShowStudentSelector(false);
      setTargetCourseId(null);
  };

  // -- GRADING --
  const handleOpenGrading = (student: StudentRecord) => {
      setSelectedStudentForGrade(student);
      const initialGrades: Record<string, string> = {};
      student.grades.forEach(g => {
          initialGrades[`${g.subjectId}-${g.period}`] = g.score.toString();
      });
      setEditingGrades(initialGrades);
  };

  const handleSaveGrades = () => {
      if (!activeCollege || !selectedStudentForGrade) return;
      
      const newGradeScores: GradeScore[] = [];
      Object.entries(editingGrades).forEach(([key, val]) => {
          const parts = key.split('-');
          if (parts.length < 2) return;
          const subId = parts[0];
          const per = parts[1];
          
          const score = parseFloat(val as string);
          if (!isNaN(score)) {
              newGradeScores.push({
                  subjectId: subId,
                  period: parseInt(per, 10) as 1|2|3|4,
                  score
              });
          }
      });

      const updatedStudents = activeCollege.students.map(s => 
          s.toyId === selectedStudentForGrade.toyId ? { ...s, grades: newGradeScores } : s
      );

      updateActiveCollege({ ...activeCollege, students: updatedStudents });
      setSelectedStudentForGrade(null);
      setNotification({ show: true, type: 'success', title: 'Notas Guardadas', message: 'El boletín ha sido actualizado.' });
  };

  // -- RENDER HELPERS --
  const getToyName = (id?: string | null) => toys.find(t => t.id === id)?.name || 'Sin Asignar';

  if (!activeCollege && view !== 'create') {
      return (
          <FullScreenPage>
              <div className="max-w-md mx-auto px-4 mt-20 text-center">
                  <div className="w-24 h-24 bg-sky-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <GraduationCap className="w-12 h-12 text-sky-600" />
                  </div>
                  <h2 className="text-2xl font-black text-slate-800 mb-2">No hay Colegio</h2>
                  <p className="text-slate-500 mb-8">El pueblo necesita educación. ¡Funda el primer colegio ahora!</p>
                  <button onClick={() => setView('create')} className="w-full py-4 bg-sky-600 text-white font-bold rounded-xl shadow-lg btn-press">
                      Fundar Colegio
                  </button>
                  <button onClick={onBack} className="mt-4 text-slate-400 font-bold text-sm btn-press">Volver</button>
              </div>
          </FullScreenPage>
      );
  }

  if (view === 'create') {
      return (
          <FullScreenPage>
              {showDirectorSelector && <ToySelector toys={toys} title="Elegir Rector" minAge={25} onSelect={(id) => { setNewDirectorId(id); setShowDirectorSelector(false); }} onCancel={() => setShowDirectorSelector(false)} />}
              <div className="max-w-md mx-auto px-4 pt-4 mt-8">
                  <div className="flex items-center gap-3 mb-6"><button onClick={() => { if(colleges.length > 0) setView('main'); else onBack(); }} className="p-2 bg-white border border-slate-200 rounded-full btn-press"><ArrowLeft className="w-5 h-5 text-slate-600" /></button><h2 className="text-2xl font-bold text-slate-800">Nuevo Colegio</h2></div>
                  <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200 space-y-4">
                      <div><label className="text-xs font-bold text-slate-400 uppercase">Nombre de la Institución</label><input type="text" value={newCollegeName} onChange={e => setNewCollegeName(e.target.value)} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-sky-500" placeholder="Ej. Colegio Real" /></div>
                      <div><label className="text-xs font-bold text-slate-400 uppercase">Rector (Dueño)</label><button onClick={() => setShowDirectorSelector(true)} className="w-full p-3 border rounded-xl text-left font-bold text-sm bg-slate-50 text-slate-600 btn-press">{newDirectorId ? getToyName(newDirectorId) : 'Seleccionar...'}</button></div>
                      <button onClick={handleCreateCollege} disabled={!newCollegeName || !newDirectorId} className="w-full py-3 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl shadow-md btn-press disabled:opacity-50">Confirmar Registro</button>
                  </div>
              </div>
          </FullScreenPage>
      );
  }

  return (
    <FullScreenPage>
        <NotificationModal isOpen={notification.show} onClose={() => setNotification({ ...notification, show: false })} type={notification.type} title={notification.title} message={notification.message} />
        
        {/* Modals */}
        {showProfSelector && <ToySelector toys={toys} title="Asignar Profesor" minAge={20} onSelect={(id) => { setNewProfId(id); setShowProfSelector(false); }} onCancel={() => setShowProfSelector(false)} />}
        {showStudentSelector && <ToySelector toys={toys} title="Matricular Estudiante" minAge={3} onSelect={handleEnrollStudent} onCancel={() => setShowStudentSelector(false)} />}

        {/* GRADE EDITOR MODAL */}
        {selectedStudentForGrade && activeCollege && (
            <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 border border-slate-200 flex flex-col max-h-[85vh]">
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <h3 className="text-xl font-bold text-slate-800">{getToyName(selectedStudentForGrade.toyId)}</h3>
                            <p className="text-sm text-sky-600 font-bold">Boletín de Notas</p>
                        </div>
                        <button onClick={() => setSelectedStudentForGrade(null)} className="text-slate-400 hover:text-slate-600"><Trash2 className="w-5 h-5"/></button>
                    </div>
                    <div className="flex-1 overflow-y-auto custom-scrollbar space-y-6 pr-2">
                        {activeCollege.subjects.length === 0 ? <p className="text-slate-400 text-sm text-center">No hay materias configuradas.</p> : activeCollege.subjects.map(subj => (
                            <div key={subj.id} className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                                <h4 className="font-bold text-slate-700 text-sm mb-2 border-b border-slate-200 pb-1">{subj.name}</h4>
                                <div className="grid grid-cols-4 gap-2">
                                    {[1, 2, 3, 4].map(period => (
                                        <div key={period} className="flex flex-col items-center">
                                            <label className="text-[10px] text-slate-400 font-bold">P{period}</label>
                                            <input 
                                                type="number" 
                                                min="0" max="5" step="0.1"
                                                value={editingGrades[`${subj.id}-${period}`] || ''}
                                                onChange={(e) => setEditingGrades({...editingGrades, [`${subj.id}-${period}`]: e.target.value})}
                                                className="w-full text-center p-2 rounded-lg border border-slate-300 font-bold text-slate-800 focus:border-sky-500 outline-none text-sm"
                                                placeholder="-"
                                            />
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="pt-4 border-t border-slate-100 mt-4 flex gap-3">
                        <button onClick={() => setSelectedStudentForGrade(null)} className="flex-1 py-3 text-slate-500 font-bold btn-press">Cancelar</button>
                        <button onClick={handleSaveGrades} className="flex-1 py-3 bg-sky-600 text-white font-bold rounded-xl shadow btn-press">Guardar Notas</button>
                    </div>
                </div>
            </div>
        )}

        <div className="max-w-5xl mx-auto px-4 pt-4 md:pt-0 md:mt-8 pb-20">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div className="flex items-center gap-3">
                    <button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm btn-press"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
                    <div>
                        <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2"><GraduationCap className="w-6 h-6 text-sky-600" /> {activeCollege?.name}</h2>
                        <p className="text-sm text-slate-500 font-bold">Rector: {getToyName(activeCollege?.directorId)}</p>
                    </div>
                </div>
                {/* Navigation Tabs */}
                <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                    <button onClick={() => setView('main')} className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap btn-press border ${view === 'main' ? 'bg-sky-100 text-sky-700 border-sky-200' : 'bg-white text-slate-500 border-slate-200'}`}>Resumen</button>
                    <button onClick={() => setView('subjects')} className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap btn-press border ${view === 'subjects' ? 'bg-sky-100 text-sky-700 border-sky-200' : 'bg-white text-slate-500 border-slate-200'}`}>Materias</button>
                    <button onClick={() => setView('courses')} className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap btn-press border ${view === 'courses' ? 'bg-sky-100 text-sky-700 border-sky-200' : 'bg-white text-slate-500 border-slate-200'}`}>Cursos</button>
                    <button onClick={() => setView('grades')} className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap btn-press border ${view === 'grades' ? 'bg-sky-100 text-sky-700 border-sky-200' : 'bg-white text-slate-500 border-slate-200'}`}>Notas</button>
                </div>
            </div>

            {/* MAIN VIEW */}
            {view === 'main' && activeCollege && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-sky-50 p-6 rounded-2xl border border-sky-100 text-center">
                        <div className="text-4xl font-black text-sky-600 mb-1">{activeCollege.students.length}</div>
                        <div className="text-xs font-bold text-sky-400 uppercase tracking-widest">Estudiantes</div>
                    </div>
                    <div className="bg-purple-50 p-6 rounded-2xl border border-purple-100 text-center">
                        <div className="text-4xl font-black text-purple-600 mb-1">{activeCollege.courses.length}</div>
                        <div className="text-xs font-bold text-purple-400 uppercase tracking-widest">Cursos Activos</div>
                    </div>
                    <div className="bg-emerald-50 p-6 rounded-2xl border border-emerald-100 text-center">
                        <div className="text-4xl font-black text-emerald-600 mb-1">{activeCollege.subjects.length}</div>
                        <div className="text-xs font-bold text-emerald-400 uppercase tracking-widest">Materias Base</div>
                    </div>
                </div>
            )}

            {/* SUBJECTS CONFIG */}
            {view === 'subjects' && activeCollege && (
                <div className="space-y-6">
                    <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                        <h3 className="font-bold text-slate-700 mb-3 flex items-center gap-2"><Plus className="w-4 h-4 text-sky-500"/> Nueva Materia</h3>
                        <div className="flex flex-col md:flex-row gap-3">
                            <input type="text" value={newSubjectName} onChange={e => setNewSubjectName(e.target.value)} placeholder="Nombre (ej. Matemáticas)" className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-sky-500" />
                            <button onClick={() => setShowProfSelector(true)} className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-left text-slate-600 btn-press">{newProfId ? `Prof. ${getToyName(newProfId)}` : 'Asignar Profesor...'}</button>
                            <button onClick={handleAddSubject} className="bg-sky-600 text-white font-bold px-6 py-2.5 rounded-xl btn-press shadow-md">Crear</button>
                        </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {activeCollege.subjects.map(subj => (
                            <div key={subj.id} className="bg-white p-4 rounded-xl border border-slate-200 flex justify-between items-center shadow-sm">
                                <div>
                                    <div className="font-bold text-slate-800">{subj.name}</div>
                                    <div className="text-xs text-sky-600 font-bold flex items-center gap-1"><UserCheck className="w-3 h-3"/> {getToyName(subj.professorId)}</div>
                                </div>
                                <button onClick={() => handleDeleteSubject(subj.id)} className="text-slate-300 hover:text-red-500 btn-press"><Trash2 className="w-4 h-4"/></button>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* COURSES & ENROLLMENT */}
            {view === 'courses' && activeCollege && (
                <div className="space-y-6">
                    <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                        <h3 className="font-bold text-slate-700 mb-3 flex items-center gap-2"><Plus className="w-4 h-4 text-sky-500"/> Abrir Curso</h3>
                        <div className="flex flex-col gap-3">
                            <div className="flex gap-3">
                                <select value={newCourseName} onChange={e => setNewCourseName(e.target.value)} className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none">
                                    {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
                                </select>
                                <input type="text" value={newSchedule} onChange={e => setNewSchedule(e.target.value)} placeholder="Horario (Ej. 7am - 1pm)" className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none" />
                            </div>
                            <button onClick={handleAddCourse} className="w-full bg-sky-600 text-white font-bold px-6 py-2.5 rounded-xl btn-press shadow-md">Crear Grado</button>
                        </div>
                    </div>
                    <div className="space-y-4">
                        {activeCollege.courses.map(course => {
                            const enrolled = activeCollege.students.filter(s => s.courseId === course.id);
                            return (
                                <div key={course.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
                                    <div className="bg-slate-50 p-3 flex justify-between items-center border-b border-slate-100">
                                        <div>
                                            <h4 className="font-bold text-slate-800 flex items-center gap-2"><Book className="w-4 h-4 text-sky-500"/> {course.name}</h4>
                                            <p className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1"><Clock className="w-3 h-3"/> {course.schedule}</p>
                                        </div>
                                        <button onClick={() => { setTargetCourseId(course.id); setShowStudentSelector(true); }} className="text-xs bg-white border border-sky-200 text-sky-600 px-3 py-1.5 rounded-lg font-bold btn-press">Matricular</button>
                                    </div>
                                    <div className="p-3">
                                        {enrolled.length === 0 ? <p className="text-xs text-slate-400 italic text-center">Sin estudiantes.</p> : (
                                            <div className="flex flex-wrap gap-2">
                                                {enrolled.map(st => (
                                                    <span key={st.toyId} className="text-xs bg-sky-50 text-sky-700 px-2 py-1 rounded font-bold border border-sky-100">
                                                        {getToyName(st.toyId)}
                                                    </span>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* GRADING SYSTEM */}
            {view === 'grades' && activeCollege && (
                <div className="space-y-4">
                    <div className="flex gap-2 overflow-x-auto no-scrollbar">
                        {activeCollege.courses.map(course => (
                            <button 
                                key={course.id} 
                                onClick={() => setSelectedGradeCourse(course.id)}
                                className={`px-4 py-2 rounded-xl text-xs font-bold border whitespace-nowrap btn-press ${selectedGradeCourse === course.id ? 'bg-sky-600 text-white border-sky-600' : 'bg-white text-slate-500 border-slate-200'}`}
                            >
                                {course.name}
                            </button>
                        ))}
                    </div>
                    
                    {selectedGradeCourse ? (
                        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                            <div className="p-4 bg-slate-50 border-b border-slate-100"><h3 className="font-bold text-slate-700 text-sm">Lista de Estudiantes</h3></div>
                            <div className="divide-y divide-slate-100">
                                {activeCollege.students.filter(s => s.courseId === selectedGradeCourse).map(student => (
                                    <button 
                                        key={student.toyId} 
                                        onClick={() => handleOpenGrading(student)}
                                        className="w-full p-4 text-left hover:bg-sky-50 transition-colors flex justify-between items-center group btn-press"
                                    >
                                        <span className="font-bold text-slate-800 text-sm">{getToyName(student.toyId)}</span>
                                        <div className="flex items-center gap-2 text-xs text-slate-400 font-bold group-hover:text-sky-600">
                                            <Edit3 className="w-4 h-4"/> Calificar
                                        </div>
                                    </button>
                                ))}
                                {activeCollege.students.filter(s => s.courseId === selectedGradeCourse).length === 0 && (
                                    <div className="p-8 text-center text-slate-400 text-sm">No hay estudiantes en este curso.</div>
                                )}
                            </div>
                        </div>
                    ) : (
                        <div className="p-10 text-center bg-white rounded-2xl border border-dashed border-slate-300">
                            <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                            <p className="text-slate-400 font-bold text-sm">Selecciona un curso para ver el listado.</p>
                        </div>
                    )}
                </div>
            )}
        </div>
    </FullScreenPage>
  );
};