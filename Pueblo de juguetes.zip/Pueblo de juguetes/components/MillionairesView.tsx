import React, { useState } from 'react';
import { Crown, ArrowLeft, Coins, AlertCircle, BarChart3, List, MoreHorizontal, MoreVertical } from 'lucide-react';
import { Toy, Bank, Company } from '../types';
import { FullScreenPage } from './FullScreenPage';

interface MillionairesViewProps {
  toys: Toy[];
  banks: Bank[];
  companies: Company[];
  onBack: () => void;
}

const MONEY_SCALES = [
    "Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", 
    "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", 
    "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón",
    "Unvigintillón", "Duovigintillón", "Tresvigintillón", "Cuatrovigintillón", "Quinquevigintillón", "Sexvigintillón", "Septemvigintillón", "Octovigintillón", "Novemvigintillón",
    "Trigintillón", "Untrigintillón", "Duotrigintillón", "Trestrigintillón", "Cuatrotrigintillón", "Quinquetrigintillón", "Sextrigintillón", "Septemtrigintillón", "Octotrigintillón", "Novemtrigintillón",
    "Cuadragintillón", "Uncuadragintillón", "Duocuadragintillón", "Trescuadragintillón", "Cuatrocuadragintillón", "Quinquecuadragintillón", "Sexcuadragintillón", "Septemcuadragintillón", "Octocuadragintillón", "Novemcuadragintillón",
    "Quinquagintillón", "Unquinquagintillón", "Duoquinquagintillón", "Tresquinquagintillón", "Cuatroquinquagintillón", "Quinquequinquagintillón", "Sexquinquagintillón", "Septemquinquagintillón", "Octoquinquagintillón", "Novemquinquagintillón",
    "Sexagintillón", "Unsexagintillón", "Duosexagintillón", "Tresexagintillón", "Cuatrosexagintillón", "Quinquesexagintillón", "Sexsexagintillón", "Septemsexagintillón", "Octosexagintillón", "Novemsexagintillón",
    "Septuagintillón", "Unseptuagintillón", "Duoseptuagintillón", "Treseptuagintillón", "Cuatroseptuagintillón", "Quinquesseptuagintillón", "Sexseptuagintillón", "Septemseptuagintillón", "Octoseptuagintillón", "Novemseptuagintillón",
    "Octogintillón", "Unoctogintillón", "Duooctogintillón", "Tresoctogintillón", "Cuatrooctogintillón", "Quinqueoctogintillón", "Sexoctogintillón", "Septemoctogintillón", "Octooctogintillón", "Novemoctogintillón",
    "Nonagintillón", "Unnonagintillón", "Duononagintillón", "Tresnonagintillón", "Cuatrononagintillón", "Quinquenonagintillón", "Sexnonagintillón", "Septemnonagintillón", "Octononagintillón", "Novemnonagintillón",
    "Centillón"
];

const formatMoneyWithScale = (amount: number) => {
    if (amount >= 1000 && amount < 1000000) {
        return { amount: Math.round(amount / 1000), suffix: 'Mil' };
    }
    if (amount < 1000) return { amount: amount, suffix: '' };
    
    let temp = amount / 1000000;
    let scaleIdx = 0;
    while (temp >= 1000 && scaleIdx < MONEY_SCALES.length - 1) {
        temp /= 1000;
        scaleIdx++;
    }
    return { amount: Math.round(temp * 100) / 100, suffix: MONEY_SCALES[scaleIdx] };
};

export const MillionairesView: React.FC<MillionairesViewProps> = ({ toys, banks, companies, onBack }) => {
  const [viewMode, setViewMode] = useState<'list' | 'graph'>('list');
  const [graphOrientation, setGraphOrientation] = useState<'horizontal' | 'vertical'>('horizontal');

  const calculateWealth = (toyId: string) => {
      let totalWealth = 0;
      const toy = toys.find(t => t.id === toyId);
      
      // Only count bank balance if linked to a bank (implied by bankAccountId being set)
      if (toy?.bankAccountId && toy?.accountBalance) {
          totalWealth += toy.accountBalance;
      }

      // Add owned bank funds
      const myBanks = banks.filter(b => b.ownerId === toyId);
      myBanks.forEach(b => {
           const idx = MONEY_SCALES.indexOf(b.fundsSuffix || MONEY_SCALES[0]);
           const multiplier = Math.pow(1000, idx) * 1000000;
           const rawFunds = b.funds * multiplier;
           const ownership = (b.ownerPercentage ?? 100) / 100;
           totalWealth += (rawFunds * ownership);
      });

      // Add owned company capital IF linked to a bank
      const myCompanies = companies.filter(c => c.ownerId === toyId && c.bankAccountId);
      myCompanies.forEach(c => {
           const idx = MONEY_SCALES.indexOf(c.capitalSuffix);
           const multiplier = Math.pow(1000, idx) * 1000000;
           totalWealth += (c.capitalAmount * multiplier);
      });

      return totalWealth;
  };

  const getMillionaires = () => {
      const wealthMap = toys.map(t => ({
          ...t,
          wealth: calculateWealth(t.id)
      }));
      return wealthMap.sort((a, b) => b.wealth - a.wealth).filter(t => t.wealth > 0).slice(0, 10);
  };

  const millionaires = getMillionaires();
  const maxWealth = millionaires.length > 0 ? millionaires[0].wealth : 1;

  return (
    <FullScreenPage>
        <div className="max-w-xl mx-auto px-4 pt-4 md:pt-0 md:mt-8 pb-10">
            <div className="bg-white rounded-2xl shadow-xl border-4 border-yellow-300 overflow-hidden relative flex flex-col h-full max-h-[85vh]">
                <div className="absolute top-2 right-2 opacity-20"><Coins className="w-24 h-24 text-yellow-500" /></div>
                
                {/* Header */}
                <div className="bg-gradient-to-br from-yellow-400 via-orange-500 to-amber-600 p-6 text-white text-center relative z-10 shrink-0">
                        <div className="w-14 h-14 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center mx-auto mb-2 shadow-inner border border-white/40">
                            <Crown className="w-7 h-7 text-yellow-100 drop-shadow-md" />
                        </div>
                        <h2 className="text-2xl font-black uppercase tracking-widest drop-shadow-md">Top Forbes</h2>
                        
                        {/* View Toggle Buttons */}
                        <div className="flex justify-center gap-2 mt-4">
                            <button 
                                onClick={() => setViewMode('list')}
                                className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors border ${viewMode === 'list' ? 'bg-white text-orange-600 border-white' : 'bg-orange-600/30 text-white/80 border-white/20 hover:bg-orange-600/50'}`}
                            >
                                <List className="w-3 h-3" /> Lista
                            </button>
                            <button 
                                onClick={() => setViewMode('graph')}
                                className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors border ${viewMode === 'graph' ? 'bg-white text-orange-600 border-white' : 'bg-orange-600/30 text-white/80 border-white/20 hover:bg-orange-600/50'}`}
                            >
                                <BarChart3 className="w-3 h-3" /> Gráfica
                            </button>
                        </div>
                </div>

                {/* Content Area */}
                <div className="bg-white flex-1 overflow-hidden flex flex-col relative">
                    {millionaires.length === 0 ? (
                        <div className="p-10 text-center text-slate-400 flex flex-col items-center justify-center h-full">
                            <Coins className="w-12 h-12 mb-2 opacity-50" />
                            No hay fortunas registradas aún.
                        </div>
                    ) : (
                        <>
                            {viewMode === 'list' ? (
                                <div className="divide-y divide-slate-100 overflow-y-auto custom-scrollbar h-full">
                                    <div className="bg-orange-50/50 p-3 text-center border-b border-orange-100">
                                        <div className="flex items-center justify-center gap-2 text-[10px] font-bold text-orange-600">
                                            <AlertCircle className="w-3 h-3" />
                                            Requiere vinculación bancaria para aparecer.
                                        </div>
                                    </div>
                                    {millionaires.map((m, index) => {
                                        const { amount, suffix } = formatMoneyWithScale(m.wealth);
                                        return (
                                            <div key={m.id} className={`p-4 flex items-center gap-4 transition-colors ${index < 3 ? 'bg-yellow-50/50' : 'hover:bg-slate-50'}`}>
                                                <div className={`w-10 h-10 flex items-center justify-center font-black rounded-full shadow-sm shrink-0 ${index === 0 ? 'bg-yellow-400 text-white ring-4 ring-yellow-200' : index === 1 ? 'bg-slate-300 text-white ring-4 ring-slate-100' : index === 2 ? 'bg-amber-600 text-white ring-4 ring-amber-200' : 'text-slate-400 bg-slate-100'}`}>
                                                    {index + 1}
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <div className="font-bold text-slate-800 truncate">{m.name}</div>
                                                    <div className="text-[10px] text-slate-400 uppercase font-bold truncate">{m.family}</div>
                                                </div>
                                                <div className="text-right shrink-0">
                                                    <div className="font-extrabold text-emerald-600 text-base">COP ${amount.toLocaleString()}</div>
                                                    <div className="text-[10px] font-bold text-emerald-400 uppercase">{suffix}</div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            ) : (
                                <div className="flex flex-col h-full">
                                    {/* Graph Controls */}
                                    <div className="p-3 border-b border-slate-100 flex justify-end bg-slate-50 shrink-0">
                                        <button 
                                            onClick={() => setGraphOrientation(prev => prev === 'horizontal' ? 'vertical' : 'horizontal')}
                                            className="text-xs font-bold text-slate-500 bg-white border border-slate-200 px-3 py-1.5 rounded-lg hover:text-orange-600 hover:border-orange-200 transition-all flex items-center gap-2"
                                        >
                                            {graphOrientation === 'horizontal' ? <MoreVertical className="w-3 h-3"/> : <MoreHorizontal className="w-3 h-3"/>}
                                            {graphOrientation === 'horizontal' ? 'Ver Vertical' : 'Ver Horizontal'}
                                        </button>
                                    </div>

                                    {/* Graph Container */}
                                    <div className="flex-1 overflow-hidden relative bg-slate-50/30 p-4">
                                        {graphOrientation === 'horizontal' ? (
                                            // HORIZONTAL GRAPH
                                            <div className="overflow-y-auto custom-scrollbar h-full w-full pr-2">
                                                <div className="space-y-4 min-h-max pb-4">
                                                    {millionaires.map((m, index) => {
                                                        const percentage = Math.max(2, (m.wealth / maxWealth) * 100);
                                                        const { amount, suffix } = formatMoneyWithScale(m.wealth);
                                                        return (
                                                            <div key={m.id} className="w-full">
                                                                <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                                                                    <span className="truncate max-w-[150px]">{index + 1}. {m.name}</span>
                                                                    <span className="text-emerald-600">${amount} {suffix}</span>
                                                                </div>
                                                                <div className="h-3 w-full bg-slate-200 rounded-full overflow-hidden">
                                                                    <div 
                                                                        className={`h-full rounded-full ${index === 0 ? 'bg-yellow-400' : index === 1 ? 'bg-slate-400' : index === 2 ? 'bg-amber-600' : 'bg-emerald-500'}`} 
                                                                        style={{ width: `${percentage}%` }}
                                                                    ></div>
                                                                </div>
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </div>
                                        ) : (
                                            // VERTICAL GRAPH
                                            <div className="overflow-x-auto custom-scrollbar h-full w-full">
                                                <div className="flex items-end h-full min-w-max gap-4 px-2 pb-8 pt-6">
                                                    {millionaires.map((m, index) => {
                                                        const percentage = Math.max(5, (m.wealth / maxWealth) * 100);
                                                        const { amount, suffix } = formatMoneyWithScale(m.wealth);
                                                        return (
                                                            <div key={m.id} className="flex flex-col items-center justify-end h-full w-16 group">
                                                                <div className="text-[10px] font-bold text-emerald-600 mb-1 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap -translate-y-2">
                                                                    ${amount} {suffix}
                                                                </div>
                                                                <div 
                                                                    className={`w-full rounded-t-lg transition-all relative ${index === 0 ? 'bg-yellow-400' : index === 1 ? 'bg-slate-400' : index === 2 ? 'bg-amber-600' : 'bg-emerald-500'}`} 
                                                                    style={{ height: `${percentage}%` }}
                                                                >
                                                                    <div className="absolute -top-6 left-1/2 -translate-x-1/2 font-black text-slate-400/50 text-xl">{index + 1}</div>
                                                                </div>
                                                                <div className="mt-2 text-[10px] font-bold text-slate-600 truncate w-20 text-center -rotate-45 origin-top-left translate-y-4 translate-x-2">
                                                                    {m.name}
                                                                </div>
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </>
                    )}
                </div>

                <button onClick={onBack} className="w-full py-4 bg-slate-50 text-slate-500 font-bold hover:bg-slate-100 transition-colors border-t border-slate-100 uppercase text-xs tracking-wider shrink-0">Volver a Finanzas</button>
            </div>
        </div>
    </FullScreenPage>
  );
};