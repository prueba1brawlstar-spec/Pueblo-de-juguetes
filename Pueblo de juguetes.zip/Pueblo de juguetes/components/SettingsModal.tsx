
import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Settings, X, ShieldCheck, Mail, LogOut } from 'lucide-react';

interface SettingsModalProps {
  email: string | null;
  onClose: () => void;
  onLogout?: () => void; 
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ email, onClose, onLogout }) => {
  const [mounted, setMounted] = useState(false);
  
  useEffect(() => {
      setMounted(true);
      document.body.style.overflow = 'hidden';
      return () => { document.body.style.overflow = 'unset'; };
  }, []);

  if (!mounted) return null;

  return createPortal(
    <div className="fixed inset-x-0 top-0 safe-screen z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200 font-sans">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden relative border border-slate-200 animate-in zoom-in-95 duration-300">
        
        <button 
          onClick={onClose}
          className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 p-1 hover:bg-slate-100 rounded-full transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="pt-8 pb-6 px-6 flex flex-col items-center text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-green-100 to-emerald-200 rounded-full flex items-center justify-center mb-4 shadow-inner ring-4 ring-white">
            <ShieldCheck className="w-10 h-10 text-emerald-600" />
          </div>

          <h3 className="text-xl font-extrabold text-slate-800 mb-1">
            Cuenta Vinculada
          </h3>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-wider mb-6">
            Estado de Seguridad
          </p>

          <div className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center gap-3 mb-6">
             <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-blue-500 shadow-sm border border-slate-100">
                 <Mail className="w-5 h-5" />
             </div>
             <div className="flex-1 text-left overflow-hidden">
                 <p className="text-[10px] text-slate-400 font-bold uppercase">Correo Registrado</p>
                 <p className="text-sm font-bold text-slate-700 truncate" title={email || ''}>
                    {email || 'Sin correo'}
                 </p>
             </div>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed text-center px-2">
             Tu progreso está guardado en la nube y vinculado a esta cuenta de Google.
          </p>

          <button 
            onClick={onClose}
            className="mt-6 w-full py-3 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl shadow-lg transition-transform active:scale-95"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
};
