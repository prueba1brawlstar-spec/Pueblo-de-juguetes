import React, { useState, useEffect } from 'react';
import { Landmark, ChevronDown } from 'lucide-react';
import { Toy, Bank } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';
import { ScaleSelector } from './ScaleSelector';

interface CreateBankFormProps {
  toys: Toy[];
  banks: Bank[];
  onAddBank: (bank: Bank) => void;
  onCancel: () => void;
}

const MONEY_SCALES = [
    "Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", 
    "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", 
    "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón",
    "Unvigintillón", "Duovigintillón", "Tresvigintillón", "Cuatrovigintillón", "Quinquevigintillón", "Sexvigintillón", "Septemvigintillón", "Octovigintillón", "Novemvigintillón",
    "Trigintillón", "Untrigintillón", "Duotrigintillón", "Trestrigintillón", "Cuatrotrigintillón", "Quinquetrigintillón", "Sextrigintillón", "Septemtrigintillón", "Octotrigintillón", "Novemtrigintillón",
    "Cuadragintillón", "Uncuadragintillón", "Duocuadragintillón", "Trescuadragintillón", "Cuatrocuadragintillón", "Quinquecuadragintillón", "Sexcuadragintillón", "Septemcuadragintillón", "Octocuadragintillón", "Novemcuadragintillón",
    "Quinquagintillón", "Unquinquagintillón", "Duoquinquagintillón", "Tresquinquagintillón", "Cuatroquinquagintillón", "Quinquequinquagintillón", "Sexquinquagintillón", "Septemquinquagintillón", "Octoquinquagintillón", "Novemquinquagintillón",
    "Sexagintillón", "Unsexagintillón", "Duosexagintillón", "Tresexagintillón", "Cuatrosexagintillón", "Quinquesexagintillón", "Sexsexagintillón", "Septemsexagintillón", "Octosexagintillón", "Novemsexagintillón",
    "Septuagintillón", "Unseptuagintillón", "Duoseptuagintillón", "Treseptuagintillón", "Cuatroseptuagintillón", "Quinquesseptuagintillón", "Sexseptuagintillón", "Septemseptuagintillón", "Octoseptuagintillón", "Novemseptuagintillón",
    "Octogintillón", "Unoctogintillón", "Duooctogintillón", "Tresoctogintillón", "Cuatrooctogintillón", "Quinqueoctogintillón", "Sexoctogintillón", "Septemoctogintillón", "Octooctogintillón", "Novemoctogintillón",
    "Nonagintillón", "Unnonagintillón", "Duononagintillón", "Tresnonagintillón", "Cuatrononagintillón", "Quinquenonagintillón", "Sexnonagintillón", "Septemnonagintillón", "Octononagintillón", "Novemnonagintillón",
    "Centillón"
];

const BANK_ROLES = ["Director", "Gerente", "Asesor", "Cajero", "Vigilante"];

export const CreateBankForm: React.FC<CreateBankFormProps> = ({ toys, banks, onAddBank, onCancel }) => {
  const [newBankName, setNewBankName] = useState('');
  const [newBankOwnerId, setNewBankOwnerId] = useState<string | null>(null);
  const [newBankOwnerPercent, setNewBankOwnerPercent] = useState('70');
  const [funds, setFunds] = useState('');
  const [scale, setScale] = useState(MONEY_SCALES[0]);
  const [showSelector, setShowSelector] = useState(false);
  const [showScaleSelector, setShowScaleSelector] = useState(false);

  // Auto-scale Logic
  useEffect(() => {
      const num = parseFloat(funds);
      if (!isNaN(num) && num >= 1000) {
          const currentIdx = MONEY_SCALES.indexOf(scale);
          if (currentIdx < MONEY_SCALES.length - 1) {
              const nextScale = MONEY_SCALES[currentIdx + 1];
              const nextVal = num / 1000;
              // Format to max 2 decimals to keep it clean (e.g. 1.5)
              setFunds(Math.round(nextVal * 100) / 100 + "");
              setScale(nextScale);
          }
      }
  }, [funds, scale]);

  const getNextBankId = () => { const ids = banks.map(b => parseInt(b.id)).filter(n => !isNaN(n)); const max = ids.length > 0 ? Math.max(...ids) : 999; return (max + 1).toString(); };

  const handleCreate = () => {
    if (!newBankName || !newBankOwnerId || !funds) return;
    const roleSalaries = BANK_ROLES.reduce((acc, role) => ({...acc, [role]: 1000000}), {});
    const newBank: Bank = {
      id: getNextBankId(),
      name: newBankName,
      ownerId: newBankOwnerId,
      ownerPercentage: Math.min(70, Math.max(0, parseFloat(newBankOwnerPercent) || 70)),
      employees: [],
      funds: parseFloat(funds),
      fundsSuffix: scale, 
      roleSalaries,
      lastPayrollDate: Date.now()
    };
    onAddBank(newBank);
  };

  return (
    <FullScreenPage noScroll={true}>
        {showScaleSelector && (
            <ScaleSelector 
                scales={MONEY_SCALES} 
                currentScale={scale} 
                onSelect={(s) => { setScale(s); setShowScaleSelector(false); }} 
                onClose={() => setShowScaleSelector(false)} 
            />
        )}

        <div className="bg-white rounded-2xl shadow-xl p-6 border border-slate-200 w-full max-w-md mx-auto">
            <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2"><Landmark className="w-6 h-6 text-blue-600"/> Fundar Banco</h2>
            <div className="space-y-4">
                <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Nombre</label><input type="text" value={newBankName} onChange={(e) => setNewBankName(e.target.value)} placeholder="Ej. Banco Nacional" className="w-full p-3 bg-white border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"/></div>
                <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Propietario</label><button onClick={() => setShowSelector(true)} className={`w-full p-3 border rounded-xl text-left font-bold text-sm ${newBankOwnerId ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-slate-50 text-slate-400 border-slate-200'}`}>{newBankOwnerId ? toys.find(t => t.id === newBankOwnerId)?.name : 'Seleccionar Dueño'}</button></div>
                
                <div>
                    <label className="text-xs font-bold text-slate-500 uppercase block mb-1">Fondos Iniciales</label>
                    <div className="flex gap-2 w-full">
                        <input type="number" value={funds} onChange={(e) => setFunds(e.target.value)} className="flex-1 min-w-0 p-3 bg-white border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" placeholder="0"/>
                        <button onClick={() => setShowScaleSelector(true)} className="flex-1 min-w-0 p-3 bg-white border border-slate-200 rounded-xl font-bold text-left flex justify-between items-center text-slate-700 hover:bg-slate-100 transition-colors truncate">
                            <span className="truncate">{scale}</span>
                            <ChevronDown className="w-4 h-4 shrink-0 text-slate-400"/>
                        </button>
                    </div>
                </div>

                <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Participación del Dueño (%)</label><input type="number" min="0" max="70" value={newBankOwnerPercent} onChange={(e) => setNewBankOwnerPercent(e.target.value)} placeholder="Max 70%" className="w-full p-3 bg-white border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"/></div>
                <div className="flex gap-3 pt-2"><button onClick={onCancel} className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl">Cancelar</button><button onClick={handleCreate} disabled={!newBankName || !newBankOwnerId || !funds} className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg disabled:opacity-50">Crear</button></div>
            </div>
        </div>
        {showSelector && <ToySelector toys={toys} onSelect={(id) => { setNewBankOwnerId(id); setShowSelector(false); }} onCancel={() => setShowSelector(false)} minAge={18} />}
    </FullScreenPage>
  );
};