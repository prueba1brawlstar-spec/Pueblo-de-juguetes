
import React, { useState, useEffect } from 'react';
import { Landmark, User, Pencil, Save, X, Briefcase, Plus, Settings2, Trash2, ArrowLeft, PieChart, ChevronDown, TrendingUp, TrendingDown, UserMinus, DollarSign, Wallet } from 'lucide-react';
import { Toy, Bank, BankEmployee } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';
import { ScaleSelector } from './ScaleSelector';
import { RoleSelector } from './RoleSelector';
import { NotificationModal, NotificationType } from './NotificationModal';
import { ConfirmationModal } from './ConfirmationModal';

interface BankDetailViewProps {
  bank: Bank;
  toys: Toy[];
  onUpdateBank: (id: string, data: Partial<Bank>) => void;
  onUpdateToy: (id: string, data: Partial<Toy>) => void;
  onBack: () => void;
}

const MONEY_SCALES = [
    "Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", 
    "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", 
    "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón",
    "Unvigintillón", "Duovigintillón", "Tresvigintillón", "Cuatrovigintillón", "Quinquevigintillón", "Sexvigintillón", "Septemvigintillón", "Octovigintillón", "Novemvigintillón",
    "Trigintillón", "Untrigintillón", "Duotrigintillón", "Trestrigintillón", "Cuatrotrigintillón", "Quinquetrigintillón", "Sextrigintillón", "Septemtrigintillón", "Octotrigintillón", "Novemtrigintillón",
    "Cuadragintillón", "Uncuadragintillón", "Duocuadragintillón", "Trescuadragintillón", "Cuatrocuadragintillón", "Quinquecuadragintillón", "Sexcuadragintillón", "Septemcuadragintillón", "Octocuadragintillón", "Novemcuadragintillón",
    "Quinquagintillón", "Unquinquagintillón", "Duoquinquagintillón", "Tresquinquagintillón", "Cuatroquinquagintillón", "Quinquequinquagintillón", "Sexquinquagintillón", "Septemquinquagintillón", "Octoquinquagintillón", "Novemquinquagintillón",
    "Sexagintillón", "Unsexagintillón", "Duosexagintillón", "Tresexagintillón", "Cuatrosexagintillón", "Quinquesexagintillón", "Sexsexagintillón", "Septemsexagintillón", "Octosexagintillón", "Novemsexagintillón",
    "Septuagintillón", "Unseptuagintillón", "Duoseptuagintillón", "Treseptuagintillón", "Cuatroseptuagintillón", "Quinquesseptuagintillón", "Sexseptuagintillón", "Septemseptuagintillón", "Octoseptuagintillón", "Novemseptuagintillón",
    "Octogintillón", "Unoctogintillón", "Duooctogintillón", "Tresoctogintillón", "Cuatrooctogintillón", "Quinqueoctogintillón", "Sexoctogintillón", "Septemoctogintillón", "Octooctogintillón", "Novemoctogintillón",
    "Nonagintillón", "Unnonagintillón", "Duononagintillón", "Tresnonagintillón", "Cuatrononagintillón", "Quinquenonagintillón", "Sexnonagintillón", "Septemnonagintillón", "Octononagintillón", "Novemnonagintillón",
    "Centillón"
];

const formatMoneyWithScale = (amount: number, forceSuffix?: string) => {
    if (forceSuffix) return { amount, suffix: forceSuffix };
    if (amount >= 1000 && amount < 1000000) return { amount: Math.round(amount / 1000), suffix: 'Mil' };
    if (amount < 1000) return { amount: amount, suffix: '' };
    let temp = amount / 1000000;
    let scaleIdx = 0;
    while (temp >= 1000 && scaleIdx < MONEY_SCALES.length - 1) { temp /= 1000; scaleIdx++; }
    return { amount: Math.round(temp * 100) / 100, suffix: MONEY_SCALES[scaleIdx] };
};

export const BankDetailView: React.FC<BankDetailViewProps> = ({ bank, toys, onUpdateBank, onUpdateToy, onBack }) => {
  const [tab, setTab] = useState<'info' | 'clients' | 'settings'>('info');
  const [isEditingFunds, setIsEditingFunds] = useState(false);
  const [editFundsAmount, setEditFundsAmount] = useState('');
  const [editFundsScale, setEditFundsScale] = useState('');
  const [editOwnerPercent, setEditOwnerPercent] = useState('');
  
  const [showEmployeeSelector, setShowEmployeeSelector] = useState(false);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [newEmployeeRole, setNewEmployeeRole] = useState(Object.keys(bank.roleSalaries)[0] || '');
  
  // New Role State
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleSalary, setNewRoleSalary] = useState('');
  const [newRoleScale, setNewRoleScale] = useState('Mil');
  const [showScaleSelector, setShowScaleSelector] = useState(false);
  const [showRoleSelector, setShowRoleSelector] = useState(false);

  // Manage Employee Modal
  const [managingEmployee, setManagingEmployee] = useState<BankEmployee | null>(null);
  const [showFireConfirmation, setShowFireConfirmation] = useState(false);
  const [notification, setNotification] = useState<{show: boolean, type: NotificationType, title: string, message: string}>({ show: false, type: 'info', title: '', message: '' });

  const owner = toys.find(t => t.id === bank.ownerId);
  const clients = toys.filter(t => t.bankAccountId === bank.id);

  // Auto-scale Logic for new role salary
  useEffect(() => {
      const num = parseFloat(newRoleSalary);
      if (!isNaN(num) && num >= 1000) {
          const currentIdx = MONEY_SCALES.indexOf(newRoleScale);
          if (currentIdx < MONEY_SCALES.length - 1) {
              const nextScale = MONEY_SCALES[currentIdx + 1];
              const nextVal = num / 1000;
              setNewRoleSalary(Math.round(nextVal * 100) / 100 + "");
              setNewRoleScale(nextScale);
          }
      }
  }, [newRoleSalary, newRoleScale]);

  const handleUpdateFunds = () => {
      const amount = parseFloat(editFundsAmount);
      const percent = parseFloat(editOwnerPercent);
      if (isNaN(amount)) return;
      onUpdateBank(bank.id, { 
          funds: amount, 
          fundsSuffix: editFundsScale, 
          ownerPercentage: isNaN(percent) ? 70 : Math.min(70, Math.max(0, percent)) 
      });
      setIsEditingFunds(false);
  };

  const handleHire = () => {
      if (!selectedEmployeeId) return;
      const salary = bank.roleSalaries[newEmployeeRole] || 1000000;
      const newEmp: BankEmployee = { id: crypto.randomUUID(), toyId: selectedEmployeeId, role: newEmployeeRole, salary };
      
      const toy = toys.find(t => t.id === selectedEmployeeId);
      if (toy && toy.bankAccountId !== bank.id) { onUpdateToy(toy.id, { bankAccountId: bank.id, accountBalance: 0 }); }
      
      onUpdateBank(bank.id, { employees: [...bank.employees, newEmp] });
      setSelectedEmployeeId(null);
  };

  // --- Role Management ---
  const handleAddRole = () => {
      if (!newRoleName || !newRoleSalary) return;
      let multiplier = 1;
      if (newRoleScale === 'Mil') multiplier = 1000;
      else {
          const idx = MONEY_SCALES.indexOf(newRoleScale);
          if (idx !== -1) multiplier = Math.pow(1000, idx) * 1000000;
      }
      
      const baseSalary = parseFloat(newRoleSalary) * multiplier;
      const updatedRoles = { ...bank.roleSalaries, [newRoleName]: baseSalary };
      onUpdateBank(bank.id, { roleSalaries: updatedRoles });
      setNewRoleName('');
      setNewRoleSalary('');
      setNewRoleScale('Mil');
  };

  const handleDeleteRole = (roleName: string) => {
      const updatedRoles = { ...bank.roleSalaries };
      delete updatedRoles[roleName];
      onUpdateBank(bank.id, { roleSalaries: updatedRoles });
  };

  // --- Employee Management Actions ---
  const handleUpdateSalary = (increment: boolean) => {
      if (!managingEmployee) return;
      const oldSalary = managingEmployee.salary;
      const newSalary = increment ? oldSalary * 1.10 : oldSalary * 0.90;
      
      const updatedEmployees = bank.employees.map(e => e.id === managingEmployee.id ? { ...e, salary: newSalary } : e);
      onUpdateBank(bank.id, { employees: updatedEmployees });
      setManagingEmployee({ ...managingEmployee, salary: newSalary }); // Update modal view
      
      const toyName = toys.find(t => t.id === managingEmployee.toyId)?.name || 'El empleado';
      const { amount, suffix } = formatMoneyWithScale(newSalary);
      
      setNotification({
          show: true,
          type: 'success',
          title: 'Sueldo Actualizado',
          message: `${toyName} ahora gana $${amount} ${suffix}.`
      });
  };

  const handleChangeRole = (newRole: string) => {
      if (!managingEmployee) return;
      const updatedEmployees = bank.employees.map(e => e.id === managingEmployee.id ? { ...e, role: newRole } : e);
      onUpdateBank(bank.id, { employees: updatedEmployees });
      setManagingEmployee({ ...managingEmployee, role: newRole });
      setShowRoleSelector(false);
  };

  const handleFireEmployee = () => {
      if (!managingEmployee) return;
      onUpdateBank(bank.id, { employees: bank.employees.filter(e => e.id !== managingEmployee.id) });
      setManagingEmployee(null);
      setShowFireConfirmation(false);
  };

  return (
    <FullScreenPage>
      <NotificationModal isOpen={notification.show} onClose={() => setNotification({ ...notification, show: false })} type={notification.type} title={notification.title} message={notification.message} />
      
      <ConfirmationModal
        isOpen={showFireConfirmation}
        onClose={() => setShowFireConfirmation(false)}
        onConfirm={handleFireEmployee}
        title="¿Despedir Empleado?"
        message={`Estás a punto de despedir a ${toys.find(t => t.id === managingEmployee?.toyId)?.name}.`}
        confirmText="Sí, Despedir"
        isDangerous={true}
      />

      {showScaleSelector && (
          <ScaleSelector 
              scales={['Mil', ...MONEY_SCALES]} 
              currentScale={isEditingFunds ? editFundsScale : newRoleScale} 
              onSelect={(s) => { 
                  if (isEditingFunds) setEditFundsScale(s);
                  else setNewRoleScale(s); 
                  setShowScaleSelector(false); 
              }} 
              onClose={() => setShowScaleSelector(false)} 
          />
      )}
      
      <div className="max-w-5xl mx-auto px-4 pt-4 md:pt-0 md:mt-8">
         {/* Header */}
         <div className="flex items-center gap-3 mb-6">
            <button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
            <div><h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><Landmark className="w-6 h-6 text-emerald-600" />{bank.name}</h2><p className="text-sm text-slate-500 font-mono">ID: {bank.id}</p></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-emerald-900 text-white rounded-xl p-6 shadow-lg relative overflow-hidden">
                <div className="flex items-center gap-4 relative z-10"><div className="w-16 h-16 bg-emerald-800 rounded-full flex items-center justify-center border-2 border-emerald-400"><User className="w-8 h-8 text-emerald-100" /></div><div><div className="text-xl font-bold">{owner?.name || 'Desconocido'}</div><div className="text-emerald-300 text-sm font-medium">{owner?.family}</div></div></div>
            </div>

            <div className="md:col-span-2 bg-white rounded-xl border border-emerald-100 shadow-sm p-6 flex flex-col justify-center relative">
                <div className="flex items-center justify-between mb-2">
                    <h3 className="text-slate-500 font-bold text-xs uppercase">Fondos Disponibles</h3>
                    {!isEditingFunds ? (
                        <button onClick={() => { setEditFundsAmount(bank.funds.toString()); setEditFundsScale(bank.fundsSuffix || MONEY_SCALES[0]); setEditOwnerPercent(bank.ownerPercentage?.toString() || '70'); setIsEditingFunds(true); }} className="text-slate-300 hover:text-emerald-600"><Pencil className="w-4 h-4" /></button>
                    ) : (
                        <div className="flex gap-2">
                            <button onClick={() => setIsEditingFunds(false)} className="text-red-400 hover:text-red-600"><X className="w-4 h-4" /></button>
                            <button onClick={handleUpdateFunds} className="text-emerald-500 hover:text-emerald-700"><Save className="w-4 h-4" /></button>
                        </div>
                    )}
                </div>
                {isEditingFunds ? (
                    <div className="space-y-3">
                        <div className="flex gap-2 w-full">
                            <input type="number" value={editFundsAmount} onChange={e => setEditFundsAmount(e.target.value)} className="flex-1 min-w-0 p-2 bg-white border border-slate-300 rounded font-bold text-slate-800 outline-none" placeholder="Monto"/>
                            <button onClick={() => setShowScaleSelector(true)} className="flex-1 min-w-0 p-2 bg-white border border-slate-300 rounded font-bold text-left flex justify-between items-center text-sm text-slate-700">
                                <span className="truncate">{editFundsScale}</span>
                                <ChevronDown className="w-4 h-4 shrink-0"/>
                            </button>
                        </div>
                        <div className="flex items-center gap-2"><span className="text-xs font-bold text-slate-500">Dueño (%):</span><input type="number" min="0" max="70" value={editOwnerPercent} onChange={(e) => setEditOwnerPercent(e.target.value)} className="w-20 p-1 bg-white border border-slate-300 rounded font-bold text-slate-800"/></div>
                    </div>
                ) : (
                    <div>
                         <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2">
                            <div className="text-3xl md:text-4xl font-mono font-bold text-emerald-600">COP ${bank.funds.toLocaleString()}</div>
                            <div className="text-lg md:text-xl font-bold text-emerald-400">{bank.fundsSuffix}</div>
                         </div>
                         <div className="text-xs text-slate-400 mt-2 font-medium flex items-center gap-1"><PieChart className="w-3 h-3"/> {bank.ownerPercentage ?? 70}% pertenece al dueño</div>
                    </div>
                )}
            </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mt-8 border-b border-slate-200 overflow-x-auto no-scrollbar">
             <button onClick={() => setTab('info')} className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${tab === 'info' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>Personal</button>
             <button onClick={() => setTab('settings')} className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${tab === 'settings' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>Configurar Cargos</button>
             <button onClick={() => setTab('clients')} className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${tab === 'clients' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>Clientes ({clients.length})</button>
        </div>

        {/* Content */}
        {tab === 'info' && (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mt-6 p-6">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-700">Nómina del Banco</h3>
                    <button onClick={() => setShowEmployeeSelector(true)} className="text-xs bg-emerald-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-emerald-700 transition-colors flex items-center gap-1"><Plus className="w-3 h-3"/> Contratar</button>
                </div>
                <div className="space-y-2">
                    {bank.employees.map(emp => {
                        const t = toys.find(x => x.id === emp.toyId);
                        const { amount, suffix } = formatMoneyWithScale(emp.salary);
                        return (
                            <button 
                                key={emp.id} 
                                onClick={() => setManagingEmployee(emp)}
                                className="w-full flex justify-between items-center p-3 border rounded-lg bg-white hover:bg-slate-50 transition-colors text-left"
                            >
                                <div>
                                    <div className="font-bold text-slate-800 text-sm">{t?.name || 'Desconocido'}</div>
                                    <div className="text-xs text-emerald-600 font-bold">{emp.role}</div>
                                </div>
                                <div className="text-right">
                                    <div className="font-bold text-slate-700 text-xs">${amount} {suffix}</div>
                                </div>
                            </button>
                        );
                    })}
                </div>
            </div>
        )}

        {/* --- CLIENTS TAB --- */}
        {tab === 'clients' && (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mt-6">
                <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
                    <Wallet className="w-4 h-4 text-emerald-600" />
                    <h3 className="text-sm font-bold text-slate-700">Cuentahabientes</h3>
                </div>
                {clients.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-sm">No hay clientes vinculados a este banco.</div>
                ) : (
                    <div className="divide-y divide-slate-100">
                        {clients.map(client => {
                            const { amount, suffix } = formatMoneyWithScale(client.accountBalance || 0);
                            return (
                                <div key={client.id} className="p-4 flex justify-between items-center hover:bg-slate-50">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600 font-bold border border-emerald-100">
                                            <User className="w-4 h-4" />
                                        </div>
                                        <div>
                                            <div className="font-bold text-slate-800 text-sm">{client.name}</div>
                                            <div className="text-xs text-slate-400 font-medium">{client.family}</div>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <div className="font-bold text-emerald-700 text-sm">${amount} {suffix}</div>
                                        <div className="text-[10px] text-slate-400 font-bold uppercase">Saldo</div>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                )}
            </div>
        )}

        {/* --- ROLES SETTINGS TAB (CHARGES) --- */}
        {tab === 'settings' && (
            <div className="space-y-6 mt-6">
                {/* Create Charge Form */}
                <div className="bg-emerald-50 rounded-xl border border-emerald-200 p-4">
                    <h3 className="text-sm font-bold text-emerald-800 mb-3 flex items-center gap-2"><Plus className="w-4 h-4"/> Crear Cargo</h3>
                    <div className="flex flex-col md:flex-row gap-3 items-end">
                        <div className="w-full md:flex-1">
                            <label className="text-[10px] uppercase font-bold text-emerald-600 mb-1 block">Nombre del Cargo</label>
                            <input type="text" value={newRoleName} onChange={e => setNewRoleName(e.target.value)} placeholder="Ej. Tesorero" className="w-full p-2 rounded-lg bg-white border border-emerald-200 text-sm font-bold text-slate-800 focus:ring-2 focus:ring-emerald-400 outline-none" />
                        </div>
                        <div className="w-full md:w-1/2">
                            <label className="text-[10px] uppercase font-bold text-emerald-600 mb-1 block">Sueldo Base</label>
                            <div className="flex gap-2">
                                <div className="relative flex-1">
                                    <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-emerald-400" />
                                    <input type="number" value={newRoleSalary} onChange={e => setNewRoleSalary(e.target.value)} placeholder="0" className="w-full pl-6 pr-2 py-2 bg-white rounded-lg border border-emerald-200 text-sm font-bold text-slate-800 outline-none focus:ring-2 focus:ring-emerald-400" />
                                </div>
                                <button onClick={() => setShowScaleSelector(true)} className="px-3 py-2 bg-white border border-emerald-200 rounded-lg text-xs font-bold text-emerald-700 flex items-center gap-1 hover:bg-emerald-100 transition-colors">
                                    {newRoleScale} <ChevronDown className="w-3 h-3" />
                                </button>
                            </div>
                        </div>
                        <button onClick={handleAddRole} disabled={!newRoleName || !newRoleSalary} className="w-full md:w-auto px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-sm disabled:opacity-50 transition-colors h-[38px]">
                            Añadir
                        </button>
                    </div>
                </div>

                {/* Roles List */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <div className="px-4 py-3 bg-slate-50 border-b border-slate-100">
                        <h3 className="font-bold text-slate-700 text-sm">Cargos Disponibles</h3>
                    </div>
                    {Object.keys(bank.roleSalaries).length === 0 ? (
                        <div className="p-8 text-center text-slate-400 text-sm">No hay cargos definidos.</div>
                    ) : (
                        <div className="divide-y divide-slate-100">
                            {Object.entries(bank.roleSalaries).map(([roleName, salary]) => {
                                const { amount, suffix } = formatMoneyWithScale(salary as number);
                                return (
                                    <div key={roleName} className="flex justify-between items-center p-4 hover:bg-slate-50 transition-colors">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-emerald-100 rounded-lg text-emerald-600"><Briefcase className="w-4 h-4"/></div>
                                            <div>
                                                <div className="font-bold text-slate-800 text-sm">{roleName}</div>
                                                <div className="text-xs text-slate-500 font-mono font-medium">
                                                    ${amount} {suffix}
                                                </div>
                                            </div>
                                        </div>
                                        <button onClick={() => handleDeleteRole(roleName)} className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-all">
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>
            </div>
        )}

        {/* Modals */}
        {showEmployeeSelector && (
            <ToySelector toys={toys} title="Contratar Personal" excludeIds={[bank.ownerId, ...bank.employees.map(e => e.toyId)]} minAge={18} onSelect={(id) => { setSelectedEmployeeId(id); setShowEmployeeSelector(false); }} onCancel={() => setShowEmployeeSelector(false)} />
        )}
        
        {/* ROLE ASSIGNMENT (INITIAL) */}
        {selectedEmployeeId && (
            <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
                <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm p-6 border border-slate-200">
                    <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2"><Briefcase className="w-5 h-5 text-emerald-600"/> Asignar Rol</h3>
                    <button onClick={() => setShowRoleSelector(true)} className="w-full p-3 bg-white border border-slate-300 rounded-lg text-sm font-bold outline-none mb-4 text-left flex justify-between items-center text-slate-700">
                        {newEmployeeRole}
                        <ChevronDown className="w-4 h-4 text-slate-400" />
                    </button>
                    <div className="flex gap-3"><button onClick={() => setSelectedEmployeeId(null)} className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl">Cancelar</button><button onClick={handleHire} className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl">Contratar</button></div>
                </div>
            </div>
        )}
        
        {/* EMPLOYEE MANAGEMENT MODAL */}
        {managingEmployee && (
            <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 border border-slate-200 relative animate-in zoom-in-95">
                    <button onClick={() => setManagingEmployee(null)} className="absolute top-3 right-3 text-slate-400 hover:text-slate-600"><X className="w-5 h-5"/></button>
                    <div className="text-center mb-6">
                        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3 text-slate-500 border border-slate-200"><User className="w-8 h-8"/></div>
                        <h3 className="text-lg font-bold text-slate-800">{toys.find(t => t.id === managingEmployee.toyId)?.name}</h3>
                        <p className="text-sm text-emerald-600 font-bold">{managingEmployee.role}</p>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 mb-6">
                        <p className="text-xs text-slate-400 font-bold uppercase text-center mb-2">Sueldo Actual</p>
                        <div className="text-center">
                            {(() => {
                                const { amount, suffix } = formatMoneyWithScale(managingEmployee.salary);
                                return <div className="text-2xl font-black text-slate-800">${amount} <span className="text-base text-slate-500">{suffix}</span></div>
                            })()}
                        </div>
                        <div className="flex gap-2 mt-3">
                            <button onClick={() => handleUpdateSalary(false)} className="flex-1 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-red-600 hover:bg-red-50 flex items-center justify-center gap-1"><TrendingDown className="w-3 h-3"/> -10%</button>
                            <button onClick={() => handleUpdateSalary(true)} className="flex-1 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-green-600 hover:bg-green-50 flex items-center justify-center gap-1"><TrendingUp className="w-3 h-3"/> +10%</button>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <button onClick={() => setShowRoleSelector(true)} className="w-full py-3 bg-blue-50 text-blue-700 font-bold rounded-xl hover:bg-blue-100 transition-colors flex items-center justify-center gap-2"><Briefcase className="w-4 h-4"/> Cambiar Cargo</button>
                        <button onClick={() => setShowFireConfirmation(true)} className="w-full py-3 bg-white border-2 border-red-100 text-red-500 font-bold rounded-xl hover:bg-red-50 transition-colors flex items-center justify-center gap-2"><UserMinus className="w-4 h-4"/> Despedir / Renunciar</button>
                    </div>
                </div>
            </div>
        )}

        {/* SHARED ROLE SELECTOR */}
        {showRoleSelector && (
            <RoleSelector 
                roles={Object.keys(bank.roleSalaries)}
                currentRole={managingEmployee ? managingEmployee.role : newEmployeeRole}
                onSelect={(role) => { 
                    if (managingEmployee) handleChangeRole(role);
                    else { setNewEmployeeRole(role); setShowRoleSelector(false); }
                }}
                onClose={() => setShowRoleSelector(false)}
            />
        )}
      </div>
    </FullScreenPage>
  );
};
