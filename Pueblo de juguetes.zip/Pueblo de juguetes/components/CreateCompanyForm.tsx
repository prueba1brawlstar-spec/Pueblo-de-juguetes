
import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Factory, ChevronDown, Landmark, Search, Check, X } from 'lucide-react';
import { Toy, Company, Bank } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';
import { ScaleSelector } from './ScaleSelector';

interface CreateCompanyFormProps {
  toys: Toy[];
  banks?: Bank[]; 
  onAddCompany: (company: Company) => void;
  onCancel: () => void;
}

// BankSelector Component using Portal for full app style consistency
const BankSelector = ({ banks, onSelect, onClose }: { banks: Bank[], onSelect: (id: string) => void, onClose: () => void }) => {
    const [search, setSearch] = useState('');
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
        document.body.style.overflow = 'hidden';
        return () => { document.body.style.overflow = 'unset'; };
    }, []);

    if (!mounted) return null;

    const filteredBanks = banks.filter(b => b.name.toLowerCase().includes(search.toLowerCase()));

    return createPortal(
        <div className="fixed inset-x-0 top-0 safe-screen z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200 font-sans">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm border border-slate-200 overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95">
                <div className="p-4 border-b border-slate-100 bg-slate-50 shrink-0">
                    <div className="flex justify-between items-center mb-3">
                        <h3 className="font-bold text-slate-700 text-lg flex items-center gap-2">
                            <Landmark className="w-5 h-5 text-emerald-600" />
                            Seleccionar Banco
                        </h3>
                        <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 hover:bg-slate-200 rounded-full transition-colors"><X className="w-5 h-5" /></button>
                    </div>
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input type="text" autoFocus placeholder="Buscar banco..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full pl-9 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none shadow-sm placeholder:text-slate-400"/>
                    </div>
                </div>
                <div className="overflow-y-auto flex-1 p-2 space-y-1 custom-scrollbar bg-white">
                    {filteredBanks.length === 0 ? (
                        <div className="p-8 text-center text-slate-400 text-sm font-medium">No se encontraron bancos.</div>
                    ) : (
                        filteredBanks.map(bank => (
                            <button key={bank.id} onClick={() => onSelect(bank.id)} className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-emerald-50 transition-colors text-left border border-transparent hover:border-emerald-100 group">
                                <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 border border-emerald-200"><Landmark className="w-4 h-4" /></div>
                                    <span className="font-bold text-sm text-slate-700 group-hover:text-emerald-800 transition-colors">{bank.name}</span>
                                </div>
                                <Check className="w-4 h-4 text-emerald-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                            </button>
                        ))
                    )}
                </div>
            </div>
        </div>,
        document.body
    );
};

const MONEY_SCALES = [
    "Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", 
    "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", 
    "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón",
    "Unvigintillón", "Duovigintillón", "Tresvigintillón", "Cuatrovigintillón", "Quinquevigintillón", "Sexvigintillón", "Septemvigintillón", "Octovigintillón", "Novemvigintillón",
    "Trigintillón", "Untrigintillón", "Duotrigintillón", "Trestrigintillón", "Cuatrotrigintillón", "Quinquetrigintillón", "Sextrigintillón", "Septemtrigintillón", "Octotrigintillón", "Novemtrigintillón",
    "Cuadragintillón", "Uncuadragintillón", "Duocuadragintillón", "Trescuadragintillón", "Cuatrocuadragintillón", "Quinquecuadragintillón", "Sexcuadragintillón", "Septemcuadragintillón", "Octocuadragintillón", "Novemcuadragintillón",
    "Quinquagintillón", "Unquinquagintillón", "Duoquinquagintillón", "Tresquinquagintillón", "Cuatroquinquagintillón", "Quinquequinquagintillón", "Sexquinquagintillón", "Septemquinquagintillón", "Octoquinquagintillón", "Novemquinquagintillón",
    "Sexagintillón", "Unsexagintillón", "Duosexagintillón", "Tresexagintillón", "Cuatrosexagintillón", "Quinquesexagintillón", "Sexsexagintillón", "Septemsexagintillón", "Octosexagintillón", "Novemsexagintillón",
    "Septuagintillón", "Unseptuagintillón", "Duoseptuagintillón", "Treseptuagintillón", "Cuatroseptuagintillón", "Quinquesseptuagintillón", "Sexseptuagintillón", "Septemseptuagintillón", "Octoseptuagintillón", "Novemseptuagintillón",
    "Octogintillón", "Unoctogintillón", "Duooctogintillón", "Tresoctogintillón", "Cuatrooctogintillón", "Quinqueoctogintillón", "Sexoctogintillón", "Septemoctogintillón", "Octooctogintillón", "Novemoctogintillón",
    "Nonagintillón", "Unnonagintillón", "Duononagintillón", "Tresnonagintillón", "Cuatrononagintillón", "Quinquenonagintillón", "Sexnonagintillón", "Septemnonagintillón", "Octononagintillón", "Novemnonagintillón",
    "Centillón"
];

export const CreateCompanyForm: React.FC<CreateCompanyFormProps> = ({ toys, banks = [], onAddCompany, onCancel }) => {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [scale, setScale] = useState(MONEY_SCALES[0]);
  const [ownerId, setOwnerId] = useState<string | null>(null);
  const [desc, setDesc] = useState('');
  const [selectedBankId, setSelectedBankId] = useState<string>('');
  const [showOwnerSelector, setShowOwnerSelector] = useState(false);
  const [showScaleSelector, setShowScaleSelector] = useState(false);
  const [showBankSelector, setShowBankSelector] = useState(false);

  // Auto-scale Logic
  useEffect(() => {
      const num = parseFloat(amount);
      if (!isNaN(num) && num >= 1000) {
          const currentIdx = MONEY_SCALES.indexOf(scale);
          if (currentIdx < MONEY_SCALES.length - 1) {
              const nextScale = MONEY_SCALES[currentIdx + 1];
              const nextVal = num / 1000;
              setAmount(Math.round(nextVal * 100) / 100 + "");
              setScale(nextScale);
          }
      }
  }, [amount, scale]);

  const handleCreate = () => {
      if (!name || !amount || !ownerId || !selectedBankId) return;
      onAddCompany({
          id: crypto.randomUUID(),
          name,
          capitalAmount: parseFloat(amount),
          capitalSuffix: scale,
          description: desc,
          ownerId,
          bankAccountId: selectedBankId,
          createdAt: Date.now(),
          employees: [],
          customRoles: []
      });
  };

  const selectedBankName = banks.find(b => b.id === selectedBankId)?.name || 'Seleccionar Banco';

  return (
    <FullScreenPage noScroll={true}>
        {showScaleSelector && (
            <ScaleSelector 
                scales={MONEY_SCALES} 
                currentScale={scale} 
                onSelect={(s) => { setScale(s); setShowScaleSelector(false); }} 
                onClose={() => setShowScaleSelector(false)} 
            />
        )}
        
        {showBankSelector && (
            <BankSelector 
                banks={banks} 
                onSelect={(id) => { setSelectedBankId(id); setShowBankSelector(false); }} 
                onClose={() => setShowBankSelector(false)} 
            />
        )}

        <div className="bg-white rounded-2xl shadow-xl p-6 border border-slate-200 w-full max-w-md mx-auto">
            <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2"><Factory className="w-6 h-6 text-orange-600"/> Crear Empresa</h2>
            <div className="space-y-4">
                <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Nombre</label><input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej. Juguetes SA" className="w-full p-3 bg-white border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-orange-500"/></div>
                
                <div>
                    <label className="text-xs font-bold text-slate-500 uppercase block mb-1">Capital Inicial</label>
                    <div className="flex gap-2 w-full">
                        <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="flex-1 min-w-0 p-3 bg-white border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-orange-500" placeholder="0"/>
                        <button onClick={() => setShowScaleSelector(true)} className="flex-1 min-w-0 p-3 bg-white border border-slate-200 rounded-xl font-bold text-left flex justify-between items-center text-slate-700 hover:bg-slate-100 transition-colors truncate">
                            <span className="truncate">{scale}</span>
                            <ChevronDown className="w-4 h-4 shrink-0 text-slate-400"/>
                        </button>
                    </div>
                </div>

                <div>
                    <label className="text-xs font-bold text-slate-500 uppercase block mb-1">Vincular a Banco</label>
                    {banks.length === 0 ? (
                        <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-600 font-bold">
                            No hay bancos en el pueblo. Crea un banco primero.
                        </div>
                    ) : (
                        <button onClick={() => setShowBankSelector(true)} className={`w-full p-3 border rounded-xl text-left font-bold text-sm flex justify-between items-center ${selectedBankId ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-white text-slate-400 border-slate-200'}`}>
                            {selectedBankName}
                            <ChevronDown className="w-4 h-4 shrink-0 opacity-50" />
                        </button>
                    )}
                </div>

                <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Dueño</label><button onClick={() => setShowOwnerSelector(true)} className={`w-full p-3 border rounded-xl text-left font-bold text-sm ${ownerId ? 'bg-orange-50 text-orange-700 border-orange-200' : 'bg-slate-50 text-slate-400 border-slate-200'}`}>{ownerId ? toys.find(t => t.id === ownerId)?.name : 'Seleccionar Dueño'}</button></div>
                <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Descripción</label><input type="text" value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="¿Qué hace la empresa?" className="w-full p-3 bg-white border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-orange-500"/></div>
                
                <div className="flex gap-3 pt-2"><button onClick={onCancel} className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl">Cancelar</button><button onClick={handleCreate} disabled={!name || !amount || !ownerId || !selectedBankId} className="flex-1 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-lg disabled:opacity-50">Registrar</button></div>
            </div>
        </div>
        {showOwnerSelector && <ToySelector toys={toys} onSelect={(id) => { setOwnerId(id); setShowOwnerSelector(false); }} onCancel={() => setShowOwnerSelector(false)} minAge={18} />}
    </FullScreenPage>
  );
};
