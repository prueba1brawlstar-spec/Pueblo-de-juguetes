
import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Toy } from '../types';
import { Search, User, Check, AlertCircle, X } from 'lucide-react';

interface ToySelectorProps {
  toys: Toy[];
  onSelect: (toyId: string) => void;
  onCancel: () => void;
  title?: string;
  excludeIds?: string[];
  minAge?: number; // New prop for age restriction
}

export const ToySelector: React.FC<ToySelectorProps> = ({ toys, onSelect, onCancel, title = "Seleccionar Habitante", excludeIds = [], minAge }) => {
  const [search, setSearch] = useState('');
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
      setMounted(true);
      document.body.style.overflow = 'hidden';
      return () => { document.body.style.overflow = 'unset'; };
  }, []);

  const filteredToys = toys.filter(t => {
    const isExcluded = excludeIds.includes(t.id);
    const matchesSearch = t.name.toLowerCase().includes(search.toLowerCase()) || t.family.toLowerCase().includes(search.toLowerCase());
    
    // Age Check: If minAge is defined, toy must have an age AND age >= minAge
    const meetsAge = minAge !== undefined ? (t.age != null && t.age >= minAge) : true;

    return !isExcluded && matchesSearch && meetsAge;
  });

  if (!mounted) return null;

  // Use fixed top-0 with safe-screen height to avoid keyboard push-up
  return createPortal(
    <div className="fixed inset-x-0 top-0 safe-screen z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200 font-sans">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md border border-slate-200 overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-200">
        <div className="p-4 border-b border-slate-100 bg-slate-50 shrink-0">
          <div className="flex justify-between items-center mb-2">
              <h3 className="font-bold text-slate-700 text-lg">{title}</h3>
              <button onClick={onCancel} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5"/></button>
          </div>
          {minAge && (
            <div className="flex items-center gap-1 text-[10px] text-amber-600 font-bold bg-amber-50 w-fit px-2 py-0.5 rounded border border-amber-100 mb-2">
                <AlertCircle className="w-3 h-3" />
                Requisito: +{minAge} Años
            </div>
          )}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              autoFocus
              placeholder="Buscar por nombre o familia..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-3 bg-white border border-slate-300 rounded-xl text-sm font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none shadow-sm placeholder:text-slate-400"
            />
          </div>
        </div>

        <div className="overflow-y-auto flex-1 p-2 space-y-1 custom-scrollbar bg-white">
          {filteredToys.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm">
              {minAge ? 'No hay habitantes mayores de 18 años disponibles.' : 'No se encontraron habitantes disponibles.'}
            </div>
          ) : (
            filteredToys.map(toy => (
              <button
                key={toy.id}
                onClick={() => onSelect(toy.id)}
                className="w-full flex items-center justify-between p-3 hover:bg-blue-50 rounded-lg group transition-colors text-left border border-transparent hover:border-blue-100 active:scale-[0.98]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-blue-200 group-hover:text-blue-600 transition-colors border border-slate-200 shrink-0">
                    <User className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-slate-700 text-sm group-hover:text-blue-700 truncate">{toy.name}</div>
                    <div className="text-xs text-slate-400 font-semibold flex gap-2 items-center">
                        <span className="truncate max-w-[100px]">{toy.family}</span>
                        {toy.age != null && <span className="text-slate-300 whitespace-nowrap">• {toy.age} años</span>}
                    </div>
                  </div>
                </div>
                <Check className="w-4 h-4 text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
              </button>
            ))
          )}
        </div>

        <div className="p-3 border-t border-slate-100 bg-slate-50 shrink-0">
          <button 
            onClick={onCancel}
            className="w-full py-3 font-bold text-sm text-slate-600 bg-white border border-slate-200 hover:bg-slate-100 rounded-xl transition-colors shadow-sm active:scale-95"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
};
