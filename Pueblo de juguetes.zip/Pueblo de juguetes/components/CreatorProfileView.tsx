import React, { useState } from 'react';
import { ArrowLeft, Users, Play, Plus, TrendingUp, Check, X, Film, Hash } from 'lucide-react';
import { SocialProfile, Toy, ContentItem, SocialPlatform } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ScaleSelector } from './ScaleSelector';

interface CreatorProfileViewProps {
  profile: SocialProfile;
  toy: Toy;
  onUpdateProfile: (profile: SocialProfile) => void;
  onBack: () => void;
}

const MONEY_SCALES = [
    "Mil", "Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", 
    "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", 
    "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón"
];

export const CreatorProfileView: React.FC<CreatorProfileViewProps> = ({ profile, toy, onUpdateProfile, onBack }) => {
  const [tab, setTab] = useState<'content' | 'stats'>('content');
  const [showCreateModal, setShowCreateModal] = useState(false);
  
  // Create Content State
  const [newTitle, setNewTitle] = useState('');
  const [newViews, setNewViews] = useState('');
  const [newViewsScale, setNewViewsScale] = useState('Mil');
  const [showViewScaleSelector, setShowViewScaleSelector] = useState(false);

  // Edit Subs State
  const [editSubs, setEditSubs] = useState(false);
  const [subsAmount, setSubsAmount] = useState(profile.followers.toString());
  const [subsScale, setSubsScale] = useState(profile.followersSuffix === '0' ? 'Mil' : profile.followersSuffix);
  const [showSubScaleSelector, setShowSubScaleSelector] = useState(false);

  // Edit Video Stats State
  const [editingContentId, setEditingContentId] = useState<string | null>(null);
  const [tempViewsAmount, setTempViewsAmount] = useState('');
  const [tempViewsScale, setTempViewsScale] = useState('');
  const [showEditViewScaleSelector, setShowEditViewScaleSelector] = useState(false);

  const isVideoPlatform = profile.platform === 'YouTube' || profile.platform === 'TikTok' || profile.platform === 'Twitch';

  const handleCreateContent = () => {
      if (!newTitle) return;
      const amount = parseFloat(newViews) || 0;
      const newItem: ContentItem = {
          id: crypto.randomUUID(),
          title: newTitle,
          views: amount, // Simplified storage, ideally we calculate real number
          viewsSuffix: newViewsScale,
          timestamp: Date.now()
      };
      onUpdateProfile({ ...profile, content: [newItem, ...profile.content] });
      setShowCreateModal(false);
      setNewTitle('');
      setNewViews('');
  };

  const handleSaveSubs = () => {
      const amount = parseFloat(subsAmount) || 0;
      onUpdateProfile({ ...profile, followers: amount, followersSuffix: subsScale });
      setEditSubs(false);
  };

  const startEditContent = (content: ContentItem) => {
      setEditingContentId(content.id);
      setTempViewsAmount(content.views.toString());
      setTempViewsScale(content.viewsSuffix);
  };

  const handleSaveContentStats = () => {
      if (!editingContentId) return;
      
      const oldContent = profile.content.find(c => c.id === editingContentId);
      if (!oldContent) return;

      const newAmount = parseFloat(tempViewsAmount) || 0;
      
      // Simple validation: Ensure it's not a decrease (rough check based on scale index)
      const getScaleIndex = (s: string) => s === '0' ? -1 : MONEY_SCALES.indexOf(s);
      const oldIdx = getScaleIndex(oldContent.viewsSuffix);
      const newIdx = getScaleIndex(tempViewsScale);
      
      let isValid = true;
      if (newIdx < oldIdx) isValid = false;
      else if (newIdx === oldIdx && newAmount < oldContent.views) isValid = false;

      if (!isValid) {
          alert("¡Las vistas no pueden disminuir! Solo aumentar.");
          return;
      }

      const updatedContent = profile.content.map(c => c.id === editingContentId ? { ...c, views: newAmount, viewsSuffix: tempViewsScale } : c);
      onUpdateProfile({ ...profile, content: updatedContent });
      setEditingContentId(null);
  };

  return (
    <FullScreenPage>
      {/* Scale Selectors */}
      {showViewScaleSelector && <ScaleSelector scales={MONEY_SCALES} currentScale={newViewsScale} onSelect={s => { setNewViewsScale(s); setShowViewScaleSelector(false); }} onClose={() => setShowViewScaleSelector(false)} />}
      {showSubScaleSelector && <ScaleSelector scales={MONEY_SCALES} currentScale={subsScale} onSelect={s => { setSubsScale(s); setShowSubScaleSelector(false); }} onClose={() => setShowSubScaleSelector(false)} />}
      {showEditViewScaleSelector && <ScaleSelector scales={MONEY_SCALES} currentScale={tempViewsScale} onSelect={s => { setTempViewsScale(s); setShowEditViewScaleSelector(false); }} onClose={() => setShowEditViewScaleSelector(false)} />}

      <div className="max-w-md mx-auto px-4 pt-4 md:pt-0 md:mt-8">
         {/* Header */}
         <div className="flex items-center gap-3 mb-6">
            <button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
            <div>
                <h2 className="text-xl font-black text-slate-800 truncate">{profile.handle}</h2>
                <p className="text-xs text-slate-500 font-bold">{toy.name}</p>
            </div>
        </div>

        {/* Profile Card */}
        <div className="bg-white rounded-2xl shadow-lg border border-slate-200 p-6 text-center mb-6 relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-2 ${profile.platform === 'YouTube' ? 'bg-red-600' : profile.platform === 'Twitch' ? 'bg-purple-600' : 'bg-blue-500'}`}></div>
            
            <div className="mb-4">
                <div className="text-4xl font-black text-slate-800 flex justify-center items-center gap-1">
                    {profile.followers} <span className="text-lg text-slate-400 font-bold">{profile.followersSuffix}</span>
                </div>
                <div className="text-xs text-slate-400 font-bold uppercase tracking-widest">Seguidores</div>
            </div>

            {editSubs ? (
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 mb-4 animate-in fade-in zoom-in-95">
                    <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Actualizar Cantidad</label>
                    <div className="flex gap-2">
                        <input type="number" value={subsAmount} onChange={e => setSubsAmount(e.target.value)} className="flex-1 min-w-0 p-2 bg-white border border-slate-200 rounded-lg text-sm font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" autoFocus />
                        <button onClick={() => setShowSubScaleSelector(true)} className="px-3 py-2 bg-white border border-slate-200 text-slate-600 rounded-lg text-xs font-bold whitespace-nowrap">{subsScale}</button>
                    </div>
                    <div className="flex gap-2 mt-2">
                        <button onClick={() => setEditSubs(false)} className="flex-1 py-1 text-xs font-bold text-slate-500 bg-white border rounded">Cancelar</button>
                        <button onClick={handleSaveSubs} className="flex-1 py-1 text-xs font-bold text-white bg-slate-800 rounded">Guardar</button>
                    </div>
                </div>
            ) : (
                <button onClick={() => setEditSubs(true)} className="text-xs font-bold text-blue-600 bg-blue-50 px-3 py-1.5 rounded-lg hover:bg-blue-100 transition-colors mb-4">
                    Editar Cifra
                </button>
            )}

            <button onClick={() => setShowCreateModal(true)} className="w-full py-3 bg-slate-800 text-white font-bold rounded-xl shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2">
                <Plus className="w-4 h-4" /> 
                {isVideoPlatform ? 'Subir Video' : 'Nuevo Post'}
            </button>
        </div>

        {/* Content List */}
        <h3 className="font-bold text-slate-700 mb-3 flex items-center gap-2">
            {isVideoPlatform ? <Film className="w-4 h-4"/> : <Hash className="w-4 h-4"/>} 
            Publicaciones Recientes
        </h3>
        
        <div className="space-y-3 pb-20">
            {profile.content.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-sm italic">
                    Aún no has publicado nada.
                </div>
            ) : (
                profile.content.map(content => (
                    <div key={content.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                        <div className="flex justify-between items-start mb-2">
                            <h4 className="font-bold text-slate-800 text-sm leading-tight">{content.title}</h4>
                            {/* Edit Button */}
                            {editingContentId !== content.id && (
                                <button onClick={() => startEditContent(content)} className="text-slate-300 hover:text-blue-500">
                                    <TrendingUp className="w-4 h-4" />
                                </button>
                            )}
                        </div>

                        {editingContentId === content.id ? (
                            <div className="mt-2 bg-green-50 p-2 rounded-lg border border-green-200 animate-in fade-in">
                                <label className="text-[10px] font-bold text-green-700 uppercase block mb-1 flex items-center gap-1">
                                    <TrendingUp className="w-3 h-3"/> Aumentar Vistas
                                </label>
                                <div className="flex gap-2">
                                    <input type="number" value={tempViewsAmount} onChange={e => setTempViewsAmount(e.target.value)} className="flex-1 min-w-0 p-1.5 bg-white border border-green-200 rounded text-sm font-bold text-slate-800 outline-none" />
                                    <button onClick={() => setShowEditViewScaleSelector(true)} className="px-2 bg-white border border-green-200 rounded text-xs font-bold text-green-700">{tempViewsScale}</button>
                                </div>
                                <div className="flex gap-2 mt-2">
                                    <button onClick={() => setEditingContentId(null)} className="flex-1 py-1 text-[10px] font-bold text-slate-500 bg-white border rounded">Cancelar</button>
                                    <button onClick={handleSaveContentStats} className="flex-1 py-1 text-[10px] font-bold text-white bg-green-600 rounded">Actualizar</button>
                                </div>
                            </div>
                        ) : (
                            <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                                <Users className="w-3 h-3" />
                                {content.views} {content.viewsSuffix} Vistas
                            </div>
                        )}
                    </div>
                ))
            )}
        </div>

        {/* Create Modal */}
        {showCreateModal && (
            <div className="fixed inset-0 z-[6000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 border border-slate-200 animate-in zoom-in-95">
                    <h3 className="text-lg font-black text-slate-800 mb-4">
                        {isVideoPlatform ? 'Crear Nuevo Video' : 'Nuevo Post'}
                    </h3>
                    <div className="space-y-4">
                        <div>
                            <label className="text-[10px] uppercase font-bold text-slate-400">Título</label>
                            <input type="text" autoFocus value={newTitle} onChange={e => setNewTitle(e.target.value)} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" placeholder="Ej. Mi viaje a la luna..." />
                        </div>
                        <div>
                            <label className="text-[10px] uppercase font-bold text-slate-400">Vistas Iniciales</label>
                            <div className="flex gap-2">
                                <input type="number" value={newViews} onChange={e => setNewViews(e.target.value)} className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500" placeholder="0" />
                                <button onClick={() => setShowViewScaleSelector(true)} className="px-4 bg-white border border-slate-200 rounded-xl font-bold text-xs text-slate-600 hover:bg-slate-50">{newViewsScale}</button>
                            </div>
                        </div>
                    </div>
                    <div className="flex gap-3 mt-6">
                        <button onClick={() => setShowCreateModal(false)} className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl transition-colors">Cancelar</button>
                        <button onClick={handleCreateContent} disabled={!newTitle} className="flex-1 py-3 bg-slate-800 text-white font-bold rounded-xl shadow-lg disabled:opacity-50">Publicar</button>
                    </div>
                </div>
            </div>
        )}

      </div>
    </FullScreenPage>
  );
};