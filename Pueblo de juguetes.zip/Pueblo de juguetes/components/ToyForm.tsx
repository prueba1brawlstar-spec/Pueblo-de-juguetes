
import React, { useState, useEffect, useRef } from 'react';
import { Toy, ToyType, Gender, Relation, RelationType } from '../types';
import { CarFront, Cat, Ghost, Flower2, Calendar, User, Users, Plus, Save, X, Crown, Footprints, Mars, Venus, Link as LinkIcon, Disc, ArrowLeft } from 'lucide-react';
import { NotificationModal } from './NotificationModal';
import { ToySelector } from './ToySelector';
import { SelectionModal } from './SelectionModal';

interface ToyFormProps {
  toys?: Toy[]; 
  onAddToy: (toy: Omit<Toy, 'id' | 'createdAt'>) => void;
  onUpdateToy?: (id: string, toy: Omit<Toy, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
  editingToy?: Toy | null;
  fixedFamily?: string;
  fixedSubFamily?: string | null;
  isCreatingSubFamily?: boolean; 
}

const MONTHS = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

const RELATIONS_BY_GENDER: Record<Gender, RelationType[]> = {
    male: ['Padre', 'Hijo', 'Hermano', 'Abuelo', 'Nieto', 'Esposo', 'Tío', 'Sobrino', 'Suegro', 'Yerno', 'Cuñado', 'Pareja', 'Bisabuelo', 'Bisnieto', 'Primo'],
    female: ['Madre', 'Hija', 'Hermana', 'Abuela', 'Nieta', 'Esposa', 'Tía', 'Sobrina', 'Suegra', 'Nuera', 'Cuñada', 'Pareja', 'Bisabuela', 'Bisnieta', 'Prima']
};

export const ToyForm: React.FC<ToyFormProps> = ({ toys = [], onAddToy, onUpdateToy, onCancel, editingToy, fixedFamily, fixedSubFamily, isCreatingSubFamily = false }) => {
  const [name, setName] = useState('');
  const [family, setFamily] = useState(fixedFamily || '');
  const [subFamily, setSubFamily] = useState(fixedSubFamily || '');
  const [isSubLeader, setIsSubLeader] = useState(false);
  const [type, setType] = useState<ToyType>(ToyType.ANIMAL);
  const [gender, setGender] = useState<Gender>('male');
  const [age, setAge] = useState('');
  
  const [day, setDay] = useState('');
  const [month, setMonth] = useState(MONTHS[0]); 
  const [year, setYear] = useState('');
  
  const [relations, setRelations] = useState<Relation[]>([]);
  const [showRelationSelector, setShowRelationSelector] = useState(false);
  const [pendingRelationTargetId, setPendingRelationTargetId] = useState<string | null>(null);
  
  const [isMonthPickerOpen, setIsMonthPickerOpen] = useState(false);
  const [errorModal, setErrorModal] = useState<{show: boolean, msg: string}>({show: false, msg: ''});

  useEffect(() => {
      if (isCreatingSubFamily) {
          setIsSubLeader(true); 
          setSubFamily(''); 
      } else if (fixedSubFamily) {
          setSubFamily(fixedSubFamily);
      }
  }, [isCreatingSubFamily, fixedSubFamily]);

  useEffect(() => {
    if (!editingToy && !isCreatingSubFamily && !fixedSubFamily) {
        const draft = localStorage.getItem('toy_form_draft');
        if (draft) {
            try {
                const data = JSON.parse(draft);
                setName(data.name || '');
                if (!fixedFamily) setFamily(data.family || '');
                setType(data.type || ToyType.ANIMAL);
                setGender(data.gender || 'male');
                setAge(data.age || '');
                setDay(data.day || '');
                setMonth(data.month || MONTHS[0]);
                setYear(data.year || '');
                if (!fixedSubFamily) setSubFamily(data.subFamily || '');
            } catch (e) {
                console.error("Error loading draft", e);
            }
        }
    }
  }, [editingToy, fixedFamily, isCreatingSubFamily, fixedSubFamily]);

  useEffect(() => {
    if (!editingToy && !isCreatingSubFamily) {
        const data = { name, family, type, gender, age, day, month, year, subFamily };
        localStorage.setItem('toy_form_draft', JSON.stringify(data));
    }
  }, [name, family, type, gender, age, day, month, year, subFamily, editingToy, isCreatingSubFamily]);

  useEffect(() => {
    if (editingToy) {
      setName(editingToy.name);
      setFamily(editingToy.family);
      setSubFamily(editingToy.subFamily || '');
      setIsSubLeader(editingToy.isSubFamilyLeader || false);
      setType(editingToy.type);
      setGender(editingToy.gender || 'male'); 
      setRelations(editingToy.relations || []);
      
      if (editingToy.age != null) { setAge(editingToy.age.toString()); } else { setAge(''); }
      
      if (editingToy.birthday) {
          const date = new Date(editingToy.birthday);
          if (!isNaN(date.getTime())) {
            setDay(date.getUTCDate().toString());
            setMonth(MONTHS[date.getUTCMonth()]);
            setYear(date.getUTCFullYear().toString());
          }
      } else { 
          setDay(''); 
          setMonth(MONTHS[0]); 
          
          // Auto-calculate year from age if birthday is missing but age exists
          if (editingToy.age != null) {
              const currentYear = new Date().getFullYear();
              setYear((currentYear - editingToy.age).toString());
          } else {
              setYear(''); 
          }
      }

    } else if (fixedFamily) {
      setFamily(fixedFamily);
    }
  }, [editingToy, fixedFamily]);

  const resetForm = () => {
    setName(''); setAge(''); setDay(''); setMonth(MONTHS[0]); setYear(''); setType(ToyType.ANIMAL); setGender('male'); setIsSubLeader(false); setRelations([]);
    if (!fixedSubFamily) setSubFamily('');
    localStorage.removeItem('toy_form_draft');
  };

  const handleAgeChange = (val: string) => {
    setAge(val);
    const parsedAge = parseInt(val, 10);
    if (!isNaN(parsedAge)) {
      const currentYear = new Date().getFullYear();
      setYear((currentYear - parsedAge).toString());
    } else {
        setYear('');
    }
  };

  const handleYearChange = (val: string) => {
    setYear(val);
    const parsedYear = parseInt(val, 10);
    if (!isNaN(parsedYear) && val.length === 4) {
      const currentYear = new Date().getFullYear();
      const calcAge = currentYear - parsedYear;
      if (calcAge >= 0) setAge(calcAge.toString());
    }
  };

  const getMaxDaysForMonth = (monthName: string) => {
    const monthIndex = MONTHS.findIndex(m => m === monthName);
    if (monthIndex === -1) return 31;
    const y = parseInt(year) || new Date().getFullYear();
    return new Date(y, monthIndex + 1, 0).getDate();
  };

  const getMaxDays = () => getMaxDaysForMonth(month);

  const handleMonthSelect = (selectedMonth: string) => {
    const newMaxDays = getMaxDaysForMonth(selectedMonth);
    const currentDayVal = parseInt(day);
    if (!isNaN(currentDayVal) && currentDayVal > newMaxDays) {
      setDay(newMaxDays.toString());
    }
    setMonth(selectedMonth);
    setIsMonthPickerOpen(false);
  };

  const handleRelationTargetSelected = (targetId: string) => {
      setShowRelationSelector(false);
      setPendingRelationTargetId(targetId);
  };

  const handleRelationTypeSelected = (type: RelationType) => {
      if (!pendingRelationTargetId) return;
      const filtered = relations.filter(r => r.toyId !== pendingRelationTargetId);
      const newRel: Relation = { toyId: pendingRelationTargetId, type: type };
      setRelations([...filtered, newRel]);
      setPendingRelationTargetId(null);
  };

  const handleRemoveRelation = (relIndex: number) => {
      const newRels = [...relations];
      newRels.splice(relIndex, 1);
      setRelations(newRels);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const monthIndex = MONTHS.findIndex(m => m === month);
    if (!name || !family) return;
    
    if (isCreatingSubFamily && !subFamily.trim()) {
        setErrorModal({ show: true, msg: 'Debes ingresar un nombre para la Sub-familia.' });
        return;
    }

    let birthday = undefined;
    if (day && year && monthIndex !== -1) {
        const maxDays = getMaxDays();
        if (parseInt(day) > maxDays) {
          setErrorModal({ show: true, msg: `El mes de ${month} solo tiene ${maxDays} días.` });
          return;
        }
        const mStr = (monthIndex + 1).toString().padStart(2, '0');
        const dStr = day.toString().padStart(2, '0');
        birthday = `${year}-${mStr}-${dStr}`;
    }

    const toyData = {
      name, family, subFamily, 
      isSubFamilyLeader: isCreatingSubFamily ? true : isSubLeader,
      type, gender,
      // Fix: Strictly check against empty string to allow '0' as valid age
      age: age !== '' ? parseInt(age, 10) : null, 
      birthday: birthday || null,
      isLeader: editingToy?.isLeader,
      relations: relations 
    };

    if (editingToy && onUpdateToy) {
      onUpdateToy(editingToy.id, toyData);
    } else {
      onAddToy(toyData);
      if (!fixedFamily) setFamily('');
      resetForm();
    }
  };

  const getTypeIcon = (t: ToyType) => {
    switch (t) {
      case ToyType.CARRO: return <CarFront className="w-4 h-4" />;
      case ToyType.ANIMAL: return <Cat className="w-4 h-4" />;
      case ToyType.MONSTRUO: return <Ghost className="w-4 h-4" />;
      case ToyType.PLANTA: return <Flower2 className="w-4 h-4" />;
      case ToyType.DINOSAURIO: return <Footprints className="w-4 h-4" />;
      case ToyType.TAPA: return <Disc className="w-4 h-4" />;
    }
  };

  const relationCandidates = toys.filter(t => {
      if (t.id === editingToy?.id) return false;
      return true;
  });

  const pendingRelationTarget = toys.find(t => t.id === pendingRelationTargetId);
  const availableRelationTypes = RELATIONS_BY_GENDER[gender];

  return (
    <div className={`bg-white w-full max-w-lg mx-auto ${editingToy ? '' : ''}`}>
      
      <NotificationModal isOpen={errorModal.show} onClose={() => setErrorModal({...errorModal, show: false})} type="error" title="Error en Datos" message={errorModal.msg} />

      {/* MONTH SELECTION MODAL */}
      {isMonthPickerOpen && (
          <SelectionModal 
            title="Seleccionar Mes de Nacimiento"
            options={MONTHS}
            selected={month}
            onSelect={(m) => { handleMonthSelect(m); }}
            onClose={() => setIsMonthPickerOpen(false)}
          />
      )}

      <div className="mb-4 pb-2 border-b border-slate-100 flex justify-between items-center sticky top-0 bg-white z-10 pt-2">
        <h2 className={`text-lg font-bold flex items-center gap-2 ${editingToy ? 'text-blue-600' : isCreatingSubFamily ? 'text-purple-600' : 'text-slate-800'}`}>
          {editingToy ? <Save className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
          {editingToy ? 'Editar' : isCreatingSubFamily ? 'Nueva Sub-familia' : fixedSubFamily ? 'Añadir Residente' : 'Añadir Integrante'}
        </h2>
        <button onClick={() => { onCancel(); localStorage.removeItem('toy_form_draft'); }} className="text-xs text-slate-400 hover:text-red-500 font-bold flex items-center gap-1 bg-slate-50 px-3 py-1.5 rounded-lg transition-colors btn-press">
          <X className="w-4 h-4" /> Cancelar
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 pb-6">
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 ml-1 uppercase">Familia</label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400"><Users className="w-4 h-4" /></div>
              <input type="text" value={family} onChange={(e) => !fixedFamily && setFamily(e.target.value)} readOnly={!!fixedFamily} placeholder="Ej. Familia Momia" className={`w-full pl-9 pr-3 py-2.5 border rounded-xl outline-none text-sm font-bold text-slate-700 ${fixedFamily ? 'bg-slate-100 border-slate-200 cursor-not-allowed' : 'bg-slate-50 border-slate-200 focus:ring-2 focus:ring-blue-500'}`} required />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 ml-1 uppercase">{isCreatingSubFamily ? 'Nombre del Líder' : 'Nombre'}</label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400"><User className="w-4 h-4" /></div>
              <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej. Momia roja" className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm font-bold text-slate-800 placeholder:text-slate-300" required />
            </div>
          </div>
        </div>

        {isCreatingSubFamily && (
            <div className="p-3 rounded-xl border bg-purple-50 border-purple-200 transition-colors">
                <label className="text-[10px] font-bold text-purple-600 uppercase mb-1 block flex items-center gap-1">
                    <Crown className="w-3 h-3" />
                    Nombre de Sub-familia
                </label>
                <input 
                    type="text" 
                    value={subFamily} 
                    onChange={(e) => setSubFamily(e.target.value)} 
                    placeholder="Ej. Los Primos (Residentes)" 
                    className="w-full p-2.5 bg-white border border-purple-200 rounded-lg text-sm font-bold outline-none focus:ring-2 focus:ring-purple-400"
                    required
                />
            </div>
        )}
        
        {!isCreatingSubFamily && subFamily && (
             <div className="p-2 bg-purple-50 border border-purple-100 rounded-lg">
                 <p className="text-xs text-purple-600 font-bold flex items-center gap-2"><Crown className="w-4 h-4"/> Miembro de Sub-familia: {subFamily}</p>
             </div>
        )}

        {/* Género & Tipo */}
        <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 ml-1 uppercase">Género</label>
            <div className="flex gap-2">
                <button type="button" onClick={() => { setGender('male'); setRelations([]); }} className={`flex-1 py-2 px-2 rounded-lg border flex items-center justify-center gap-1 transition-all btn-press ${gender === 'male' ? 'bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500 shadow-sm' : 'bg-white border-slate-200 text-slate-400 hover:bg-slate-50'}`}><Mars className="w-4 h-4" /></button>
                <button type="button" onClick={() => { setGender('female'); setRelations([]); }} className={`flex-1 py-2 px-2 rounded-lg border flex items-center justify-center gap-1 transition-all btn-press ${gender === 'female' ? 'bg-pink-50 border-pink-500 text-pink-700 ring-1 ring-pink-500 shadow-sm' : 'bg-white border-slate-200 text-slate-400 hover:bg-slate-50'}`}><Venus className="w-4 h-4" /></button>
            </div>
            </div>

            <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 ml-1 uppercase">Tipo</label>
            <div className="grid grid-cols-3 gap-1">
                {Object.values(ToyType).slice(0,3).map((t) => (<button key={t} type="button" onClick={() => setType(t)} className={`flex items-center justify-center p-2 rounded-lg border transition-all btn-press ${type === t ? 'bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500' : 'bg-white border-slate-200 text-slate-400 hover:bg-slate-50'}`}>{getTypeIcon(t)}</button>))}
                {Object.values(ToyType).slice(3).map((t) => (<button key={t} type="button" onClick={() => setType(t)} className={`flex items-center justify-center p-2 rounded-lg border transition-all btn-press ${type === t ? 'bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500' : 'bg-white border-slate-200 text-slate-400 hover:bg-slate-50'}`}>{getTypeIcon(t)}</button>))}
            </div>
            </div>
        </div>

        {/* --- Sección de Fechas --- */}
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-2">
            <div className="flex items-center gap-2 mb-1">
                <Calendar className="w-4 h-4 text-blue-500" /><span className="text-[10px] font-bold text-slate-500 uppercase">Nacimiento</span>
            </div>
            <div className="grid grid-cols-12 gap-2">
                <div className="col-span-3"><input type="number" inputMode="numeric" min="0" value={age} onChange={(e) => handleAgeChange(e.target.value)} placeholder="Edad" className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-xs font-bold text-center h-9"/></div>
                <div className="col-span-3"><input type="number" inputMode="numeric" min="1" max={getMaxDays()} value={day} onChange={(e) => { const val = parseInt(e.target.value); const max = getMaxDays(); if (e.target.value === '' || (val > 0 && val <= max)) { setDay(e.target.value); } }} placeholder="Día" className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-xs font-bold text-center h-9"/></div>
                
                {/* Month Picker - Uses new SelectionModal via state */}
                <div className="col-span-3 relative">
                    <button type="button" onClick={() => setIsMonthPickerOpen(true)} className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-xs font-bold text-center truncate h-9 btn-press">
                        {month.substring(0,3)}
                    </button>
                </div>
                
                <div className="col-span-3"><input type="number" inputMode="numeric" value={year} onChange={(e) => handleYearChange(e.target.value)} placeholder="Año" className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-xs font-bold text-center h-9"/></div>
            </div>
        </div>

        {/* --- CONNECTIONS SECTION --- */}
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
            <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                    <LinkIcon className="w-4 h-4 text-blue-500" />
                    <span className="text-[10px] font-bold text-slate-500 uppercase">Lazos</span>
                </div>
                <button type="button" onClick={() => setShowRelationSelector(true)} className="text-[10px] bg-white border border-blue-200 text-blue-600 px-2 py-1 rounded-lg font-bold hover:bg-blue-50 flex items-center gap-1 btn-press"><Plus className="w-3 h-3"/> Agregar</button>
            </div>
            
            {relations.length > 0 && (
                <div className="space-y-2">
                    {relations.map((rel, idx) => {
                        const t = toys.find(x => x.id === rel.toyId);
                        return (
                            <div key={idx} className="flex justify-between items-center bg-white p-2 rounded-lg border border-slate-200 shadow-sm">
                                <div className="flex items-center gap-2">
                                    <div className="text-[10px] font-bold bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded uppercase">{rel.type}</div>
                                    <span className="text-xs font-bold text-slate-700 truncate max-w-[150px]">{t?.name}</span>
                                </div>
                                <button type="button" onClick={() => handleRemoveRelation(idx)} className="text-slate-300 hover:text-red-500 btn-press"><X className="w-3 h-3" /></button>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>

        {/* STEP 1: MEMBER SELECTOR */}
        {showRelationSelector && (
            <ToySelector 
                toys={relationCandidates} 
                title="Elegir Integrante" 
                onSelect={handleRelationTargetSelected} 
                onCancel={() => setShowRelationSelector(false)} 
            />
        )}

        {/* STEP 2: RELATION TYPE MODAL (FULL SCREEN MOBILE OPTIMIZED) */}
        {pendingRelationTargetId && (
            <div className="fixed inset-0 z-[10000] bg-slate-50 flex flex-col font-sans animate-in slide-in-from-bottom-4 duration-300">
                {/* Header */}
                <div className="bg-white border-b border-slate-200 p-4 pt-6 shadow-sm shrink-0">
                    <div className="flex items-center gap-3">
                        <button 
                            onClick={() => setPendingRelationTargetId(null)} 
                            className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-full transition-colors active:scale-95 btn-press"
                        >
                            <ArrowLeft className="w-6 h-6" />
                        </button>
                        <div>
                            <h3 className="text-xl font-extrabold text-slate-800 leading-tight">Definir Vínculo</h3>
                            <p className="text-sm text-slate-500 font-medium">Establece la relación manual</p>
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-4 flex flex-col">
                    <div className="text-center mb-8 mt-4 px-4">
                        <p className="text-sm text-slate-400 font-bold uppercase tracking-wider mb-2">Estás editando a</p>
                        <h2 className="text-3xl font-black text-blue-600 mb-4">{name || 'Este Personaje'}</h2>
                        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 inline-block w-full max-w-xs">
                            <p className="text-sm text-slate-500 font-medium mb-1">¿Qué es de...?</p>
                            <p className="text-xl font-bold text-slate-800 truncate">{pendingRelationTarget?.name}</p>
                        </div>
                    </div>

                    <div className="flex-1">
                        <div className="grid grid-cols-2 gap-3 pb-8">
                            {availableRelationTypes.map(type => (
                                <button 
                                    key={type} 
                                    type="button" 
                                    onClick={() => handleRelationTypeSelected(type)} 
                                    className="flex flex-col items-center justify-center p-4 h-24 rounded-2xl border-2 border-slate-200 bg-white hover:border-blue-500 hover:bg-blue-50 text-slate-600 hover:text-blue-700 font-bold transition-all shadow-sm active:scale-95 active:bg-blue-100 active:border-blue-600 btn-press"
                                >
                                    <span className="text-lg uppercase tracking-tight">{type}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        )}

        <button type="submit" className={`w-full font-bold py-3.5 rounded-xl shadow-md active:transform active:scale-[0.99] transition-all flex items-center justify-center gap-2 text-sm btn-press ${editingToy ? 'bg-blue-600 hover:bg-blue-700 text-white' : isCreatingSubFamily ? 'bg-purple-600 hover:bg-purple-700 text-white' : 'bg-slate-800 hover:bg-slate-900 text-white'}`}>
          {editingToy ? <Save className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          <span>{editingToy ? 'Guardar Cambios' : isCreatingSubFamily ? 'Crear Sub-familia' : fixedSubFamily ? 'Registrar Residente' : 'Registrar Integrante'}</span>
        </button>
      </form>
    </div>
  );
};
