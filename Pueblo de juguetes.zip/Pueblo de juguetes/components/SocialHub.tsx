import React, { useState } from 'react';
import { Youtube, Instagram, Twitter, Twitch, ArrowLeft, Hash, Facebook } from 'lucide-react';
import { Toy, SocialProfile, SocialPlatform } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { SocialPlatformView } from './SocialPlatformView';

// Custom TikTok Icon
const TikTokIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
  </svg>
);

interface SocialHubProps {
  toys: Toy[];
  profiles: SocialProfile[];
  onUpdateProfiles: (profiles: SocialProfile[]) => void;
  onBack: () => void;
}

export const SocialHub: React.FC<SocialHubProps> = ({ toys, profiles, onUpdateProfiles, onBack }) => {
  const [selectedPlatform, setSelectedPlatform] = useState<SocialPlatform | null>(null);

  if (selectedPlatform) {
      return (
          <SocialPlatformView 
            platform={selectedPlatform} 
            toys={toys} 
            profiles={profiles} 
            onUpdateProfiles={onUpdateProfiles} 
            onBack={() => setSelectedPlatform(null)} 
          />
      );
  }

  const getPlatformCount = (p: SocialPlatform) => profiles.filter(prof => prof.platform === p).length;

  return (
    <FullScreenPage>
      <div className="max-w-5xl mx-auto px-4 pt-4 md:pt-0 md:mt-8">
        <div className="flex items-center gap-3 mb-8">
            <button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
            <div>
                <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2">
                    <Hash className="w-6 h-6 text-pink-500" /> 
                    Creadores de Contenido
                </h2>
                <p className="text-sm text-slate-500 font-medium">Gestiona influencers y redes sociales</p>
            </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            
            {/* YouTube */}
            <button onClick={() => setSelectedPlatform('YouTube')} className="group bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-lg hover:border-red-200 transition-all flex flex-col items-center text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-red-600"></div>
                <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <Youtube className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-1 group-hover:text-red-600 transition-colors">YouTube</h3>
                <p className="text-xs text-slate-400 font-bold">{getPlatformCount('YouTube')} Canales</p>
            </button>

            {/* TikTok */}
            <button onClick={() => setSelectedPlatform('TikTok')} className="group bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-lg hover:border-slate-400 transition-all flex flex-col items-center text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-black"></div>
                <div className="w-16 h-16 bg-slate-900 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg shadow-cyan-500/20">
                    <TikTokIcon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-1 group-hover:text-black transition-colors">TikTok</h3>
                <p className="text-xs text-slate-400 font-bold">{getPlatformCount('TikTok')} Cuentas</p>
            </button>

            {/* Instagram */}
            <button onClick={() => setSelectedPlatform('Instagram')} className="group bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-lg hover:border-pink-200 transition-all flex flex-col items-center text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 to-pink-500"></div>
                <div className="w-16 h-16 bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform text-white">
                    <Instagram className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-1 group-hover:text-pink-600 transition-colors">Instagram</h3>
                <p className="text-xs text-slate-400 font-bold">{getPlatformCount('Instagram')} Perfiles</p>
            </button>

            {/* Facebook */}
            <button onClick={() => setSelectedPlatform('Facebook' as any)} className="group bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-lg hover:border-blue-600 transition-all flex flex-col items-center text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-blue-600"></div>
                <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <Facebook className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-1 group-hover:text-blue-600 transition-colors">Facebook</h3>
                <p className="text-xs text-slate-400 font-bold">{getPlatformCount('Facebook' as any)} Perfiles</p>
            </button>

            {/* X */}
            <button onClick={() => setSelectedPlatform('X')} className="group bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-lg hover:border-slate-400 transition-all flex flex-col items-center text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-slate-700"></div>
                <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <Twitter className="w-8 h-8 text-white fill-white" />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-1 group-hover:text-black transition-colors">X / Twitter</h3>
                <p className="text-xs text-slate-400 font-bold">{getPlatformCount('X')} Cuentas</p>
            </button>

            {/* Twitch */}
            <button onClick={() => setSelectedPlatform('Twitch')} className="group bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-lg hover:border-purple-300 transition-all flex flex-col items-center text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-purple-600"></div>
                <div className="w-16 h-16 bg-purple-50 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <Twitch className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-1 group-hover:text-purple-600 transition-colors">Twitch</h3>
                <p className="text-xs text-slate-400 font-bold">{getPlatformCount('Twitch')} Canales</p>
            </button>

        </div>
      </div>
    </FullScreenPage>
  );
};