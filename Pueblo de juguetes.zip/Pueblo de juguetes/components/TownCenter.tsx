
import React, { useState } from 'react';
import { Building2, Landmark, Shield, Gavel, ScrollText, ShieldAlert, GraduationCap } from 'lucide-react';
import { Toy, Government, Law, PoliceData, College } from '../types';
import { PresidencyView } from './PresidencyView';
import { PoliceStationView } from './PoliceStationView';
import { LawsView } from './LawsView';
import { CollegeDashboard } from './CollegeDashboard';

interface TownCenterProps {
  toys: Toy[];
  government: Government;
  police: PoliceData; 
  laws: Law[];
  colleges?: College[];
  onUpdateGov: (gov: Government) => void;
  onUpdatePolice: (police: PoliceData) => void;
  onAddLaw: (law: Law) => void;
  onUpdateColleges: (colleges: College[]) => void;
  onToggleFullScreen: (isFull: boolean) => void;
}

export const TownCenter: React.FC<TownCenterProps> = ({ toys, government, police, laws, colleges = [], onUpdateGov, onUpdatePolice, onAddLaw, onUpdateColleges, onToggleFullScreen }) => {
  const [view, setView] = useState<'menu' | 'presidency' | 'laws' | 'police' | 'college'>('menu');

  React.useEffect(() => {
    onToggleFullScreen(view !== 'menu');
  }, [view, onToggleFullScreen]);

  if (view === 'presidency') return <PresidencyView toys={toys} government={government} onUpdateGov={onUpdateGov} onBack={() => setView('menu')} />;
  if (view === 'police') return <PoliceStationView toys={toys} police={police} onUpdatePolice={onUpdatePolice} onBack={() => setView('menu')} />;
  if (view === 'laws') return <LawsView toys={toys} laws={laws} government={government} onAddLaw={onAddLaw} onBack={() => setView('menu')} />;
  if (view === 'college') return <CollegeDashboard toys={toys} colleges={colleges} onUpdateColleges={onUpdateColleges} onBack={() => setView('menu')} />;

  return (
    <div className="space-y-6 mt-8 border-t border-slate-200 pt-8 pb-8">
      <div className="flex items-center gap-2 mb-2"><Building2 className="w-6 h-6 text-slate-700" /><h2 className="text-xl font-bold text-slate-800">Instituciones y Gobierno</h2></div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Presidency Card */}
        <button onClick={() => setView('presidency')} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md hover:border-indigo-300 group transition-all text-left flex flex-col h-full btn-press"><div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><Landmark className="w-6 h-6 text-indigo-600" /></div><h3 className="font-bold text-lg text-slate-800 mb-2 group-hover:text-indigo-700 transition-colors">Presidencia</h3><p className="text-sm text-slate-500 leading-relaxed">Sede del poder ejecutivo. Gestión del líder supremo.</p></button>
        
        {/* College Card */}
        <button onClick={() => setView('college')} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md hover:border-sky-300 group transition-all text-left flex flex-col h-full btn-press"><div className="w-12 h-12 bg-sky-50 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><GraduationCap className="w-6 h-6 text-sky-600" /></div><h3 className="font-bold text-lg text-slate-800 mb-2 group-hover:text-sky-700 transition-colors">Colegio</h3><p className="text-sm text-slate-500 leading-relaxed">Educación municipal. Profesores, cursos y notas.</p></button>

        {/* Laws Card */}
        <button onClick={() => setView('laws')} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md hover:border-amber-300 group transition-all text-left flex flex-col h-full relative overflow-hidden btn-press"><div className="absolute -right-4 -top-4 opacity-5"><Gavel className="w-24 h-24" /></div><div className="w-12 h-12 bg-amber-50 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform relative z-10"><ScrollText className="w-6 h-6 text-amber-600" /></div><h3 className="font-bold text-lg text-slate-800 mb-2 group-hover:text-amber-700 transition-colors relative z-10">Leyes</h3><p className="text-sm text-slate-500 leading-relaxed relative z-10">Constitución oficial y normas de convivencia.</p></button>
        
        {/* Police Station Card */}
        <button onClick={() => setView('police')} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md hover:border-blue-800 group transition-all text-left flex flex-col h-full btn-press"><div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><ShieldAlert className="w-6 h-6 text-blue-800" /></div><h3 className="font-bold text-lg text-slate-800 mb-2 group-hover:text-blue-800 transition-colors">Policía</h3><p className="text-sm text-slate-500 leading-relaxed">Seguridad, oficiales y cárcel municipal.</p></button>
      
      </div>
    </div>
  );
};
