
import React, { useState } from 'react';
import { Search, Briefcase, Check, X } from 'lucide-react';

interface RoleSelectorProps {
  roles: string[];
  currentRole: string;
  onSelect: (role: string) => void;
  onClose: () => void;
  title?: string;
}

export const RoleSelector: React.FC<RoleSelectorProps> = ({ roles, currentRole, onSelect, onClose, title = "Seleccionar Cargo" }) => {
  const [search, setSearch] = useState('');

  const filteredRoles = roles.filter(r => 
    r.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-x-0 top-0 safe-screen z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm border border-slate-200 overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 bg-slate-50 shrink-0">
          <div className="flex justify-between items-center mb-3">
             <h3 className="font-bold text-slate-700 text-lg flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-blue-500" />
                {title}
             </h3>
             <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
                 <X className="w-5 h-5" />
             </button>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              autoFocus
              placeholder="Buscar cargo..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-3 bg-white border border-slate-300 rounded-xl text-sm font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none shadow-sm placeholder:text-slate-400"
            />
          </div>
        </div>

        {/* List */}
        <div className="overflow-y-auto flex-1 p-2 space-y-1 custom-scrollbar bg-white">
          {filteredRoles.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm font-medium">
              No se encontraron cargos.
            </div>
          ) : (
            filteredRoles.map(role => (
              <button
                key={role}
                onClick={() => onSelect(role)}
                className={`w-full flex items-center justify-between p-3 rounded-lg group transition-colors text-left border ${
                    role === currentRole 
                    ? 'bg-blue-50 border-blue-200' 
                    : 'bg-white border-transparent hover:bg-slate-50 hover:border-slate-100'
                }`}
              >
                <span className={`font-bold text-sm ${role === currentRole ? 'text-blue-700' : 'text-slate-600'}`}>
                    {role}
                </span>
                {role === currentRole && <Check className="w-4 h-4 text-blue-600" />}
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
