
import React, { useState, useRef, useEffect } from 'react';
import { Landmark, Crown, User, Building2, Calendar, ArrowLeft, Archive, CheckCircle2, Vote, Users, BarChart3, ChevronRight, Play, Flag, Check, History } from 'lucide-react';
import { Toy, Government } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';
import { ConfirmationModal } from './ConfirmationModal';

interface PresidencyViewProps {
  toys: Toy[];
  government: Government;
  onUpdateGov: (gov: Government) => void;
  onBack: () => void;
}

export const PresidencyView: React.FC<PresidencyViewProps> = ({ toys, government, onUpdateGov, onBack }) => {
  const [activeGovRole, setActiveGovRole] = useState<'presidentId' | 'vicePresidentId' | 'mayorId' | null>(null);
  const [tempTermYear, setTempTermYear] = useState(government.termYear || new Date().getFullYear().toString());
  const prevGov = useRef(government);
  const [flash, setFlash] = useState<{[key: string]: 'green' | 'red' | null}>({});
  
  const [showConfirmFinish, setShowConfirmFinish] = useState(false);
  const [viewState, setViewState] = useState<'dashboard' | 'timeline' | 'election_setup' | 'voting' | 'results'>('dashboard');

  // ELECTION STATE
  const [candidates, setCandidates] = useState<string[]>([]);
  const [voters, setVoters] = useState<Toy[]>([]);
  const [currentVoterIndex, setCurrentVoterIndex] = useState(0);
  const [votes, setVotes] = useState<Record<string, number>>({}); // candidateId -> count
  const [showCandidateSelector, setShowCandidateSelector] = useState(false);

  useEffect(() => {
    const changes: {[key: string]: 'green' | 'red' | null} = {};
    let hasChanges = false;
    
    if (government.presidentId !== prevGov.current.presidentId) { changes.president = government.presidentId ? 'green' : 'red'; hasChanges = true; }
    if (government.vicePresidentId !== prevGov.current.vicePresidentId) { changes.vp = government.vicePresidentId ? 'green' : 'red'; hasChanges = true; }
    if (government.mayorId !== prevGov.current.mayorId) { changes.mayor = government.mayorId ? 'green' : 'red'; hasChanges = true; }

    if (hasChanges) {
        setFlash(changes);
        setTimeout(() => setFlash({}), 1000);
    }
    prevGov.current = government;
  }, [government]);

  const getToyName = (id: string | null) => toys.find(t => t.id === id)?.name || '--- Vacante ---';
  const getToyFamily = (id: string | null) => toys.find(t => t.id === id)?.family || '';
  const handleGovSelect = (toyId: string) => { if (activeGovRole) { onUpdateGov({ ...government, [activeGovRole]: toyId }); setActiveGovRole(null); } };
  const handleYearUpdate = () => { onUpdateGov({ ...government, termYear: tempTermYear }); };

  const handleFinalizeTerm = () => {
      const pastMandate = {
          year: government.termYear,
          presidentId: government.presidentId,
          vicePresidentId: government.vicePresidentId,
          mayorId: government.mayorId
      };
      
      const newHistory = [...(government.history || []), pastMandate];
      const nextYear = (parseInt(government.termYear) + 1).toString();
      
      onUpdateGov({
          ...government,
          history: newHistory,
          presidentId: null,
          vicePresidentId: null,
          mayorId: null,
          termYear: nextYear
      });
      
      setTempTermYear(nextYear);
      setShowConfirmFinish(false);
      setViewState('timeline'); 
  };

  // --- ELECTION LOGIC ---

  const startElectionSetup = () => {
      setCandidates([]);
      setVotes({});
      setViewState('election_setup');
  };

  const addCandidate = (id: string) => {
      if (!candidates.includes(id)) setCandidates([...candidates, id]);
      setShowCandidateSelector(false);
  };

  const removeCandidate = (id: string) => {
      setCandidates(candidates.filter(c => c !== id));
  };

  const startVoting = () => {
      const eligibleVoters = toys.filter(t => t.age != null && t.age >= 18);
      if (eligibleVoters.length === 0) {
          alert("No hay habitantes mayores de 18 años para votar.");
          return;
      }
      setVoters(eligibleVoters);
      setCurrentVoterIndex(0);
      
      // Initialize votes
      const initialVotes: Record<string, number> = {};
      candidates.forEach(c => initialVotes[c] = 0);
      setVotes(initialVotes);
      
      setViewState('voting');
  };

  const castVote = (candidateId: string) => {
      setVotes(prev => ({
          ...prev,
          [candidateId]: (prev[candidateId] || 0) + 1
      }));
      nextVoter();
  };

  const nextVoter = () => {
      if (currentVoterIndex < voters.length - 1) {
          setCurrentVoterIndex(currentVoterIndex + 1);
      } else {
          setViewState('results');
      }
  };

  const simulateRemainingVotes = () => {
      const remaining = voters.length - currentVoterIndex;
      const newVotes = { ...votes };
      for (let i = 0; i < remaining; i++) {
          const randomCand = candidates[Math.floor(Math.random() * candidates.length)];
          newVotes[randomCand] = (newVotes[randomCand] || 0) + 1;
      }
      setVotes(newVotes);
      setViewState('results');
  };

  const declareWinner = () => {
      const winnerId = Object.keys(votes).reduce((a, b) => votes[a] > votes[b] ? a : b);
      onUpdateGov({ ...government, presidentId: winnerId });
      setViewState('dashboard');
  };

  // TS Fix: Ensure values are numbers
  const getTotalVotes = (): number => (Object.values(votes) as number[]).reduce((a, b) => a + b, 0);

  // --- RENDERERS ---

  if (viewState === 'timeline') {
      const sortedHistory = [...(government.history || [])].reverse();
      
      return (
        <FullScreenPage>
            <div className="max-w-xl mx-auto px-4 pt-10 pb-20">
                <div className="flex items-center gap-3 mb-8">
                    <button onClick={() => setViewState('dashboard')} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm btn-press">
                        <ArrowLeft className="w-5 h-5 text-slate-600" />
                    </button>
                    <div>
                        <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2">
                            <History className="w-6 h-6 text-indigo-600" />
                            Anales Históricos
                        </h2>
                        <p className="text-sm text-slate-500 font-medium">Cronología de mandatos anteriores</p>
                    </div>
                </div>

                <div className="relative border-l-2 border-indigo-100 ml-4 space-y-8 pl-6 py-2">
                    {sortedHistory.length === 0 ? (
                        <div className="text-center py-10 text-slate-400">
                            <Archive className="w-12 h-12 mx-auto mb-2 opacity-50" />
                            <p>No hay historia registrada aún.</p>
                        </div>
                    ) : (
                        sortedHistory.map((mandate, idx) => (
                            <div key={idx} className="relative animate-in slide-in-from-right-4 duration-500" style={{ animationDelay: `${idx * 0.1}s` }}>
                                {/* Timeline Connector */}
                                <div className="absolute -left-[33px] top-4 w-4 h-4 bg-indigo-600 rounded-full border-4 border-white shadow-sm z-10"></div>
                                
                                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow">
                                    <div className="flex justify-between items-start mb-4 border-b border-slate-100 pb-3">
                                        <div>
                                            <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider bg-indigo-50 px-2 py-1 rounded">Año {mandate.year}</span>
                                        </div>
                                    </div>

                                    <div className="space-y-3">
                                        {/* President */}
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center shrink-0">
                                                <Crown className="w-5 h-5 text-indigo-600" />
                                            </div>
                                            <div>
                                                <div className="text-sm font-bold text-slate-800">{getToyName(mandate.presidentId)}</div>
                                                <div className="text-[10px] text-slate-400 font-bold uppercase">Presidente</div>
                                            </div>
                                        </div>

                                        {/* VP & Mayor Grid */}
                                        {(mandate.vicePresidentId || mandate.mayorId) && (
                                            <div className="grid grid-cols-2 gap-3 mt-2 bg-slate-50 p-3 rounded-xl">
                                                {mandate.vicePresidentId && (
                                                    <div className="flex items-center gap-2">
                                                        <User className="w-3 h-3 text-slate-400" />
                                                        <div>
                                                            <div className="text-xs font-bold text-slate-700 truncate max-w-[100px]">{getToyName(mandate.vicePresidentId)}</div>
                                                            <div className="text-[9px] text-slate-400 uppercase">Vice</div>
                                                        </div>
                                                    </div>
                                                )}
                                                {mandate.mayorId && (
                                                    <div className="flex items-center gap-2">
                                                        <Building2 className="w-3 h-3 text-emerald-500" />
                                                        <div>
                                                            <div className="text-xs font-bold text-slate-700 truncate max-w-[100px]">{getToyName(mandate.mayorId)}</div>
                                                            <div className="text-[9px] text-emerald-600 uppercase">Alcalde</div>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </FullScreenPage>
      );
  }

  // --- ELECTION SETUP VIEW ---
  if (viewState === 'election_setup') {
      return (
          <FullScreenPage>
              {showCandidateSelector && <ToySelector toys={toys} title="Inscribir Candidato" minAge={25} excludeIds={candidates} onSelect={addCandidate} onCancel={() => setShowCandidateSelector(false)} />}
              <div className="max-w-xl mx-auto px-4 pt-10">
                  <h2 className="text-2xl font-black text-slate-800 mb-2 text-center">Candidaturas Presidenciales</h2>
                  <p className="text-center text-slate-500 mb-8">Inscribe a los aspirantes al trono de juguete.</p>
                  
                  <div className="grid grid-cols-1 gap-3 mb-8">
                      {candidates.map(candId => (
                          <div key={candId} className="bg-white p-4 rounded-xl border border-indigo-100 shadow-sm flex justify-between items-center animate-in slide-in-from-bottom-2">
                              <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 font-bold">
                                      <User className="w-5 h-5"/>
                                  </div>
                                  <div>
                                      <div className="font-bold text-slate-800">{getToyName(candId)}</div>
                                      <div className="text-xs text-indigo-400 font-bold uppercase">Candidato Oficial</div>
                                  </div>
                              </div>
                              <button onClick={() => removeCandidate(candId)} className="text-red-400 hover:text-red-600 px-3 py-1 font-bold text-xs bg-red-50 rounded-lg">Retirar</button>
                          </div>
                      ))}
                      {candidates.length < 3 && (
                          <button onClick={() => setShowCandidateSelector(true)} className="w-full py-4 border-2 border-dashed border-slate-300 rounded-xl text-slate-400 font-bold flex items-center justify-center gap-2 hover:bg-slate-50 hover:border-indigo-300 hover:text-indigo-500 transition-all btn-press">
                              <Users className="w-5 h-5" /> Inscribir Candidato
                          </button>
                      )}
                  </div>

                  <div className="flex gap-3">
                      <button onClick={() => setViewState('dashboard')} className="flex-1 py-4 text-slate-500 font-bold bg-slate-100 rounded-xl">Cancelar</button>
                      <button onClick={startVoting} disabled={candidates.length < 2} className="flex-1 py-4 bg-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-indigo-200 disabled:opacity-50 disabled:shadow-none flex items-center justify-center gap-2">
                          <Vote className="w-5 h-5" /> Iniciar Votación
                      </button>
                  </div>
                  {candidates.length < 2 && <p className="text-center text-xs text-red-400 font-bold mt-4">Se necesitan al menos 2 candidatos.</p>}
              </div>
          </FullScreenPage>
      );
  }

  // --- VOTING VIEW ---
  if (viewState === 'voting') {
      const voter = voters[currentVoterIndex];
      const progress = ((currentVoterIndex) / voters.length) * 100;
      
      return (
          <FullScreenPage noScroll>
              <div className="flex flex-col h-full max-w-md mx-auto w-full py-6">
                  <div className="w-full bg-slate-200 h-2 rounded-full mb-6 overflow-hidden">
                      <div className="bg-indigo-500 h-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
                  </div>
                  
                  <div className="flex-1 flex flex-col items-center justify-center text-center">
                      <div className="mb-8 animate-in zoom-in duration-300 key={voter.id}">
                          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-2">Votante #{currentVoterIndex + 1}</p>
                          <div className="w-24 h-24 bg-white border-4 border-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 shadow-xl">
                              <User className="w-12 h-12 text-slate-300" />
                          </div>
                          <h2 className="text-3xl font-black text-slate-800 leading-tight">{voter.name}</h2>
                          <p className="text-slate-500 font-medium mt-1">¿Quién debe ser Presidente?</p>
                      </div>

                      <div className="grid grid-cols-1 w-full gap-3 px-4">
                          {candidates.map(candId => (
                              <button 
                                  key={candId} 
                                  onClick={() => castVote(candId)}
                                  className="w-full bg-white p-4 rounded-xl border-2 border-slate-100 hover:border-indigo-500 hover:bg-indigo-50 hover:shadow-md transition-all group flex items-center justify-between active:scale-95 btn-press"
                              >
                                  <span className="font-bold text-slate-700 group-hover:text-indigo-700 text-lg">{getToyName(candId)}</span>
                                  <div className="w-6 h-6 rounded-full border-2 border-slate-300 group-hover:border-indigo-500 group-hover:bg-indigo-500 flex items-center justify-center">
                                      <Check className="w-4 h-4 text-white opacity-0 group-hover:opacity-100" />
                                  </div>
                              </button>
                          ))}
                      </div>
                  </div>

                  <div className="mt-8 px-4 w-full">
                      <button onClick={simulateRemainingVotes} className="w-full py-3 text-slate-400 font-bold text-xs uppercase tracking-widest hover:text-indigo-500 transition-colors flex items-center justify-center gap-2">
                          <Play className="w-4 h-4" /> Simular votos restantes ({voters.length - currentVoterIndex})
                      </button>
                  </div>
              </div>
          </FullScreenPage>
      );
  }

  // --- RESULTS VIEW ---
  if (viewState === 'results') {
      const totalVotes = getTotalVotes();
      // Fix: Ensure sort comparison uses numbers explicitly to avoid TS errors
      const sortedResults = Object.entries(votes).sort((a, b) => Number(b[1]) - Number(a[1]));
      
      return (
          <FullScreenPage>
              <div className="max-w-xl mx-auto px-4 pt-10 pb-20">
                  <div className="text-center mb-10">
                      <div className="inline-block p-4 bg-green-100 rounded-full text-green-600 mb-4 shadow-sm animate-bounce">
                          <Flag className="w-8 h-8" />
                      </div>
                      <h2 className="text-3xl font-black text-slate-800 mb-2">Escrutinio Finalizado</h2>
                      <p className="text-slate-500 font-medium">Resultados oficiales de la elección {government.termYear}</p>
                  </div>

                  <div className="space-y-6 mb-10">
                      {sortedResults.map(([candId, val], idx) => {
                          const count = Number(val);
                          // Fix: Ensure division operands are numbers
                          const percentage = totalVotes > 0 ? ((count / totalVotes) * 100).toFixed(1) : '0.0';
                          const isWinner = idx === 0;
                          return (
                              <div key={candId} className={`relative p-5 rounded-2xl border-2 transition-all ${isWinner ? 'bg-yellow-50 border-yellow-400 shadow-lg scale-105 z-10' : 'bg-white border-slate-100'}`}>
                                  {isWinner && <div className="absolute -top-3 -right-3 bg-yellow-400 text-yellow-900 text-xs font-black px-3 py-1 rounded-full shadow-sm uppercase tracking-wider flex items-center gap-1"><Crown className="w-3 h-3"/> Ganador</div>}
                                  
                                  <div className="flex justify-between items-end mb-2">
                                      <div>
                                          <h3 className={`font-bold text-lg ${isWinner ? 'text-slate-900' : 'text-slate-600'}`}>{getToyName(candId)}</h3>
                                          <p className="text-xs font-bold text-slate-400">{count} votos recibidos</p>
                                      </div>
                                      <div className={`text-2xl font-black ${isWinner ? 'text-yellow-600' : 'text-slate-300'}`}>{percentage}%</div>
                                  </div>
                                  
                                  <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden">
                                      <div className={`h-full rounded-full transition-all duration-1000 ease-out ${isWinner ? 'bg-yellow-400' : 'bg-slate-300'}`} style={{ width: `${percentage}%` }}></div>
                                  </div>
                                  
                                  {/* Precise Count Text */}
                                  <div className="mt-2 text-right">
                                      <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-1 rounded-lg">
                                          {count} habitantes votaron por este candidato
                                      </span>
                                  </div>
                              </div>
                          );
                      })}
                  </div>

                  <button onClick={declareWinner} className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl shadow-xl shadow-slate-300 hover:bg-slate-800 transition-all active:scale-95 flex items-center justify-center gap-2 text-lg">
                      <Crown className="w-6 h-6 text-yellow-400" />
                      Investir Presidente
                  </button>
                  <p className="text-center text-xs text-slate-400 mt-4 px-6">
                      El nuevo Presidente será el encargado de designar a su Vicepresidente y Alcalde en el despacho.
                  </p>
              </div>
          </FullScreenPage>
      );
  }

  // --- DASHBOARD VIEW (DEFAULT) ---
  return (
    <FullScreenPage>
        <ConfirmationModal 
            isOpen={showConfirmFinish}
            onClose={() => setShowConfirmFinish(false)}
            onConfirm={handleFinalizeTerm}
            title="¿Finalizar Mandato?"
            message={`Se archivará el gobierno del año ${government.termYear} y se declararán los cargos vacantes para el siguiente periodo. ¿Estás seguro?`}
            confirmText="Finalizar y Archivar"
            isDangerous={false}
        />

        <div className="max-w-5xl mx-auto px-4 pt-4 md:pt-0 md:mt-8 pb-20">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div className="flex items-center gap-3">
                    <button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm shrink-0 btn-press"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
                    <div><h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><Landmark className="w-6 h-6 text-indigo-600" /> Despacho Presidencial</h2><p className="text-sm text-slate-500">Administración del Gobierno</p></div>
                </div>
                
                <div className="flex gap-2">
                    <button onClick={() => setViewState('timeline')} className="px-4 py-2 bg-slate-800 text-white text-xs font-bold rounded-xl hover:bg-slate-700 transition-colors btn-press flex items-center gap-2 shadow-md shadow-slate-200" title="Ver Historial">
                        <Archive className="w-4 h-4 text-indigo-300" /> Anales de la Historia
                    </button>
                    <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-sm flex items-center gap-2 self-start md:self-auto"><Calendar className="w-4 h-4 text-slate-400 ml-2" /><span className="text-xs font-bold text-slate-500 uppercase">Año:</span><input type="text" value={tempTermYear} onChange={(e) => setTempTermYear(e.target.value)} onBlur={handleYearUpdate} className="w-16 p-1 bg-white border border-slate-300 rounded text-sm font-bold text-center text-slate-800 outline-none focus:border-indigo-500"/></div>
                </div>
            </div>

            {/* Empty State / New Era Prompt */}
            {!government.presidentId && !government.vicePresidentId && !government.mayorId && (
                <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl p-8 mb-8 text-white text-center shadow-lg shadow-indigo-200 animate-in slide-in-from-top-4">
                    <Crown className="w-16 h-16 text-yellow-300 mx-auto mb-4 drop-shadow-md" />
                    <h3 className="text-2xl font-black mb-2">El Trono está Vacío</h3>
                    <p className="text-indigo-100 mb-6 max-w-md mx-auto">Es momento de elegir un nuevo líder para el Pueblo de Juguetes.</p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <button onClick={startElectionSetup} className="bg-white text-indigo-600 px-6 py-3 rounded-xl font-bold hover:bg-indigo-50 transition-colors shadow-md active:scale-95 flex items-center justify-center gap-2">
                            <Vote className="w-5 h-5" /> Comicios Electorales
                        </button>
                        <button onClick={() => setActiveGovRole('presidentId')} className="bg-indigo-700 text-indigo-100 px-6 py-3 rounded-xl font-bold hover:bg-indigo-800 transition-colors shadow-inner active:scale-95 flex items-center justify-center gap-2 border border-indigo-600">
                            <User className="w-5 h-5" /> Designación Directa
                        </button>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {/* President Card */}
                <div className={`bg-white rounded-xl shadow-lg border-t-4 border-indigo-600 p-8 flex flex-col items-center text-center transition-all duration-300 ${flash.president === 'green' ? 'animate-flash-green' : flash.president === 'red' ? 'animate-flash-red' : ''}`}>
                    <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center mb-6 ring-4 ring-indigo-100"><Crown className="w-12 h-12 text-indigo-600" /></div>
                    <h3 className="font-bold text-indigo-900 text-xl">Presidente</h3>
                    <p className="text-xs font-bold text-indigo-300 uppercase mb-4 tracking-wider">Mandato {government.termYear}</p>
                    <div className="mb-6 w-full"><div className="text-2xl font-extrabold text-slate-800 truncate">{getToyName(government.presidentId)}</div><div className="text-base text-indigo-500 font-medium">{getToyFamily(government.presidentId)}</div></div>
                    <button onClick={() => setActiveGovRole('presidentId')} className="w-full py-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-sm font-bold transition-colors btn-press">{government.presidentId ? 'Cambiar Líder' : 'Elegir Presidente'}</button>
                </div>

                {/* VP Card */}
                <div className={`bg-white rounded-xl shadow-md border-t-4 border-slate-500 p-8 flex flex-col items-center text-center transition-all duration-300 ${flash.vp === 'green' ? 'animate-flash-green' : flash.vp === 'red' ? 'animate-flash-red' : ''}`}>
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6 ring-4 ring-slate-100"><User className="w-10 h-10 text-slate-600" /></div>
                    <h3 className="font-bold text-slate-700 text-lg">Vicepresidente</h3>
                    <div className="mt-4 mb-6 w-full"><div className="text-xl font-bold text-slate-800 truncate">{getToyName(government.vicePresidentId)}</div><div className="text-sm text-slate-400 font-medium">{getToyFamily(government.vicePresidentId)}</div></div>
                    <button onClick={() => setActiveGovRole('vicePresidentId')} className="w-full py-3 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-xl text-sm font-bold transition-colors btn-press">Asignar Vice</button>
                </div>

                {/* Mayor Card */}
                <div className={`bg-white rounded-xl shadow-md border-t-4 border-emerald-500 p-8 flex flex-col items-center text-center transition-all duration-300 ${flash.mayor === 'green' ? 'animate-flash-green' : flash.mayor === 'red' ? 'animate-flash-red' : ''}`}>
                    <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mb-6 ring-4 ring-emerald-100"><Building2 className="w-10 h-10 text-emerald-600" /></div>
                    <h3 className="font-bold text-emerald-800 text-lg">Alcalde</h3>
                    <div className="mt-4 mb-6 w-full"><div className="text-xl font-bold text-slate-800 truncate">{getToyName(government.mayorId)}</div><div className="text-sm text-emerald-500 font-medium">{getToyFamily(government.mayorId)}</div></div>
                    <button onClick={() => setActiveGovRole('mayorId')} className="w-full py-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl text-sm font-bold transition-colors btn-press">Asignar Alcalde</button>
                </div>
            </div>

            {/* Finalize Button - Only show if government is formed */}
            {(government.presidentId || government.vicePresidentId || government.mayorId) && (
                <button 
                    onClick={() => setShowConfirmFinish(true)}
                    className="w-full py-4 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-2xl shadow-lg transition-all btn-press flex items-center justify-center gap-2 border-2 border-slate-700 hover:border-slate-600 mb-10"
                >
                    <CheckCircle2 className="w-6 h-6 text-green-400" />
                    Inaugurar Nueva Era (Finalizar Mandato)
                </button>
            )}

            {activeGovRole && <ToySelector toys={toys} title={`Seleccionar ${activeGovRole === 'mayorId' ? 'Alcalde' : 'Mandatario'}`} onSelect={handleGovSelect} onCancel={() => setActiveGovRole(null)} minAge={18} />}
        </div>
    </FullScreenPage>
  );
};
