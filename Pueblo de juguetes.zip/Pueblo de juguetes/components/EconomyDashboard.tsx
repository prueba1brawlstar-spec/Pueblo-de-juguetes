import React, { useState, useEffect } from 'react';
import { Landmark, Crown, ArrowLeft, Factory, Plus } from 'lucide-react';
import { Toy, Bank, Company, SocialProfile } from '../types';
import { NotificationModal, NotificationType } from './NotificationModal';
import { MillionairesView } from './MillionairesView';
import { BankDetailView } from './BankDetailView';
import { CompanyDetailView } from './CompanyDetailView';
import { CreateBankForm } from './CreateBankForm';
import { CreateCompanyForm } from './CreateCompanyForm';

interface EconomyDashboardProps {
  toys: Toy[];
  banks: Bank[];
  companies?: Company[];
  socialProfiles?: SocialProfile[];
  onAddBank: (bank: Bank) => void;
  onUpdateBank: (bankId: string, data: Partial<Bank>) => void;
  onAddCompany?: (company: Company) => void;
  onUpdateCompany?: (companyId: string, data: Partial<Company>) => void; 
  onUpdateToy: (id: string, data: Partial<Toy>) => void;
  onUpdateSocialProfiles?: (profiles: SocialProfile[]) => void;
  onToggleFullScreen: (isFull: boolean) => void;
}

export const EconomyDashboard: React.FC<EconomyDashboardProps> = ({ toys, banks, companies = [], socialProfiles = [], onAddBank, onUpdateBank, onAddCompany, onUpdateCompany, onUpdateToy, onUpdateSocialProfiles, onToggleFullScreen }) => {
  const [view, setView] = useState<'dashboard' | 'create_bank' | 'bank_detail' | 'create_company' | 'company_detail' | 'millionaires'>('dashboard');
  const [selectedBankId, setSelectedBankId] = useState<string | null>(null);
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | null>(null);
  const [notification, setNotification] = useState<{show: boolean, type: NotificationType, title: string, message: string}>({ show: false, type: 'info', title: '', message: '' });

  useEffect(() => {
    onToggleFullScreen(view !== 'dashboard');
  }, [view, onToggleFullScreen]);

  if (view === 'millionaires') {
      return <MillionairesView toys={toys} banks={banks} companies={companies} onBack={() => setView('dashboard')} />;
  }

  if (view === 'create_bank') {
      return <CreateBankForm toys={toys} banks={banks} onAddBank={(b) => { onAddBank(b); setView('dashboard'); }} onCancel={() => setView('dashboard')} />;
  }

  if (view === 'create_company' && onAddCompany) {
      // FIX: Passed 'banks={banks}' so the form can detect existing banks
      return <CreateCompanyForm toys={toys} banks={banks} onAddCompany={(c) => { onAddCompany(c); setView('dashboard'); }} onCancel={() => setView('dashboard')} />;
  }

  if (view === 'bank_detail' && selectedBankId) {
      const bank = banks.find(b => b.id === selectedBankId);
      if (bank) return <BankDetailView bank={bank} toys={toys} onUpdateBank={onUpdateBank} onUpdateToy={onUpdateToy} onBack={() => setView('dashboard')} />;
  }

  if (view === 'company_detail' && selectedCompanyId && onUpdateCompany) {
      const comp = companies.find(c => c.id === selectedCompanyId);
      if (comp) return <CompanyDetailView company={comp} toys={toys} onUpdateCompany={onUpdateCompany} onBack={() => setView('dashboard')} />;
  }

  return (
      <div className="space-y-6 mt-8 border-t border-slate-200 pt-8">
      <NotificationModal isOpen={notification.show} onClose={() => setNotification({ ...notification, show: false })} type={notification.type} title={notification.title} message={notification.message} />
      <div className="flex items-center justify-between mb-2"><div className="flex items-center gap-2"><Landmark className="w-6 h-6 text-slate-700" /><h2 className="text-xl font-bold text-slate-800">Economía y Finanzas</h2></div></div>
      
      {/* Top Cards */}
      <div className="grid grid-cols-1 gap-4">
          <button onClick={() => setView('millionaires')} className="w-full bg-gradient-to-r from-yellow-400 to-amber-500 p-6 rounded-2xl shadow-lg shadow-amber-200 text-white flex items-center justify-between group transition-all transform active:scale-95"><div className="flex items-center gap-4"><div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center shadow-inner border border-white/40"><Crown className="w-8 h-8 text-yellow-100 drop-shadow-md" /></div><div className="text-left"><h2 className="text-2xl font-black uppercase tracking-widest drop-shadow-sm">Top Millonarios</h2><p className="text-yellow-100 text-sm font-bold tracking-wide">Ranking de Fortunas</p></div></div><div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center group-hover:bg-white/30 transition-colors"><ArrowLeft className="w-5 h-5 text-white rotate-180" /></div></button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col max-h-[400px]"><div className="bg-slate-100 px-4 py-3 border-b border-slate-200"><h3 className="font-bold text-sm text-slate-600 uppercase tracking-wide">Registro Mercantil</h3></div><div className="flex-1 overflow-y-auto custom-scrollbar p-0">{(banks.length === 0 && companies.length === 0) ? (<div className="p-8 text-center"><p className="text-sm text-slate-400 italic">No hay registros aún.</p></div>) : (<div className="divide-y divide-slate-100">{banks.length > 0 && (<div><div className="bg-emerald-50 px-4 py-2 text-xs font-bold text-emerald-700 uppercase tracking-wider">Bancos del Pueblo</div>{banks.map(bank => (<div key={bank.id} className="flex justify-between items-center px-4 py-3 hover:bg-slate-50"><div className="flex items-center gap-3"><div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-600"><Landmark className="w-4 h-4" /></div><div><div className="font-bold text-slate-700 text-sm">{bank.name}</div></div></div><button onClick={() => { setSelectedBankId(bank.id); setView('bank_detail'); }} className="px-3 py-1.5 bg-white border text-xs font-bold rounded hover:bg-emerald-50 text-slate-600 hover:text-emerald-700 transition-colors active:scale-95">Ver</button></div>))}</div>)}{companies.length > 0 && (<div><div className="bg-orange-50 px-4 py-2 text-xs font-bold text-orange-700 uppercase tracking-wider">Empresas Creadas</div>{companies.map(comp => (<div key={comp.id} className="flex justify-between items-center px-4 py-3 hover:bg-slate-50"><div className="flex items-center gap-3"><div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center text-orange-600"><Factory className="w-4 h-4" /></div><div><div className="font-bold text-slate-700 text-sm">{comp.name}</div></div></div><button onClick={() => { setSelectedCompanyId(comp.id); setView('company_detail'); }} className="px-3 py-1.5 bg-white border text-xs font-bold rounded hover:bg-orange-50 text-slate-600 hover:text-orange-700 transition-colors active:scale-95">Ver</button></div>))}</div>)}</div>)}</div></div>
        
        {/* Increased Text Sizes here */}
        <div className="flex flex-col gap-4">
           <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 flex flex-col justify-center items-center text-center flex-1 transition-all"><div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mb-3 shadow-sm"><Landmark className="w-6 h-6 text-blue-600" /></div><h3 className="font-bold text-slate-800 mb-1 text-lg">Sistema Bancario</h3><p className="text-xs text-slate-500 mb-4 px-2 font-medium">Funda un banco para administrar fortunas.</p><button onClick={() => setView('create_bank')} className="bg-slate-800 hover:bg-slate-900 text-white font-bold py-3 px-8 rounded-xl text-sm flex items-center gap-2 transition-all active:scale-95 shadow-md"><Plus className="w-4 h-4" /> Crear Banco</button></div>
           <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 flex flex-col justify-center items-center text-center flex-1 transition-all"><div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center mb-3 shadow-sm"><Factory className="w-6 h-6 text-orange-600" /></div><h3 className="font-bold text-slate-800 mb-1 text-lg">Sector Empresarial</h3><p className="text-xs text-slate-500 mb-4 px-2 font-medium">Inicia una compañía y genera capital.</p><button onClick={() => setView('create_company')} className="bg-white border-2 border-slate-200 hover:border-orange-400 hover:text-orange-600 text-slate-600 font-bold py-3 px-8 rounded-xl text-sm flex items-center gap-2 transition-all active:scale-95 shadow-sm"><Plus className="w-4 h-4" /> Crear Empresa</button></div>
        </div>
      </div>
    </div>
  );
};