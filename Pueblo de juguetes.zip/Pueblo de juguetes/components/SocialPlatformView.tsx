import React, { useState } from 'react';
import { ArrowLeft, Search, Plus, Trophy, Play, Heart, Users, ExternalLink } from 'lucide-react';
import { Toy, SocialProfile, SocialPlatform, ContentItem } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';
import { CreatorProfileView } from './CreatorProfileView';

interface SocialPlatformViewProps {
  platform: SocialPlatform;
  toys: Toy[];
  profiles: SocialProfile[];
  onUpdateProfiles: (profiles: SocialProfile[]) => void;
  onBack: () => void;
}

export const SocialPlatformView: React.FC<SocialPlatformViewProps> = ({ platform, toys, profiles, onUpdateProfiles, onBack }) => {
  const [view, setView] = useState<'list' | 'profile'>('list');
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null);
  const [showCreatorSelector, setShowCreatorSelector] = useState(false);
  const [search, setSearch] = useState('');

  // Filter profiles for this platform
  const platformProfiles = profiles.filter(p => p.platform === platform);
  
  // Filter for search
  const filteredProfiles = platformProfiles.filter(p => p.handle.toLowerCase().includes(search.toLowerCase()));

  // Get Top Content
  const allContent = platformProfiles.flatMap(p => p.content.map(c => ({ ...c, profileName: p.handle, profileId: p.id })));
  const topContent = allContent.sort((a, b) => {
      // Simplified sort assuming K/M logic not fully parsed here, but we should parse for real top.
      // For now, let's rely on views logic if implemented or just basic sort if numbers are raw.
      return b.views - a.views;
  }).slice(0, 5);

  const getPlatformColor = () => {
      switch(platform) {
          case 'YouTube': return 'text-red-600 bg-red-50 border-red-200';
          case 'TikTok': return 'text-black bg-slate-100 border-slate-300';
          case 'Instagram': return 'text-pink-600 bg-pink-50 border-pink-200';
          case 'Twitch': return 'text-purple-600 bg-purple-50 border-purple-200';
          case 'X': return 'text-slate-800 bg-slate-50 border-slate-300';
          default: return 'text-blue-600 bg-blue-50 border-blue-200';
      }
  };

  const handleCreateProfile = (toyId: string) => {
      const toy = toys.find(t => t.id === toyId);
      if (!toy) return;
      
      // Check if already has profile on this platform
      if (platformProfiles.some(p => p.toyId === toyId)) {
          alert("¡Este habitante ya tiene una cuenta en esta plataforma!");
          return;
      }

      const newProfile: SocialProfile = {
          id: crypto.randomUUID(),
          toyId,
          handle: `@${toy.name.replace(/\s+/g, '').toLowerCase()}`,
          platform,
          followers: 0,
          followersSuffix: '0',
          content: [],
          joinedAt: Date.now()
      };
      
      onUpdateProfiles([...profiles, newProfile]);
      setShowCreatorSelector(false);
      setSelectedProfileId(newProfile.id);
      setView('profile');
  };

  if (view === 'profile' && selectedProfileId) {
      const profile = profiles.find(p => p.id === selectedProfileId);
      if (profile) {
          return <CreatorProfileView 
                    profile={profile} 
                    toy={toys.find(t => t.id === profile.toyId)!} 
                    onUpdateProfile={(updated) => {
                        const newProfiles = profiles.map(p => p.id === updated.id ? updated : p);
                        onUpdateProfiles(newProfiles);
                    }}
                    onBack={() => setView('list')}
                 />;
      }
  }

  return (
    <FullScreenPage>
      <div className="max-w-5xl mx-auto px-4 pt-4 md:pt-0 md:mt-8">
        <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
                <button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
                <div>
                    <h2 className={`text-2xl font-black flex items-center gap-2 ${platform === 'YouTube' ? 'text-red-600' : platform === 'Twitch' ? 'text-purple-600' : platform === 'Instagram' ? 'text-pink-600' : 'text-slate-800'}`}>
                        {platform}
                    </h2>
                    <p className="text-sm text-slate-500 font-bold">{platformProfiles.length} Canales Activos</p>
                </div>
            </div>
            <button onClick={() => setShowCreatorSelector(true)} className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition-transform active:scale-95 ${platform === 'YouTube' ? 'bg-red-600 text-white' : 'bg-slate-800 text-white'}`}>
                <Plus className="w-4 h-4" /> Crear Canal
            </button>
        </div>

        {/* Top Content Section */}
        {topContent.length > 0 && (
            <div className="mb-8">
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-yellow-500" /> Lo más viral
                </h3>
                <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
                    {topContent.map((c) => (
                        <div key={c.id} className="min-w-[200px] bg-white rounded-xl shadow-sm border border-slate-200 p-3 flex flex-col">
                            <div className="h-24 bg-slate-100 rounded-lg mb-2 flex items-center justify-center relative overflow-hidden group">
                                <Play className="w-8 h-8 text-slate-300 group-hover:text-slate-500 transition-colors" />
                            </div>
                            <h4 className="font-bold text-slate-800 text-sm truncate">{c.title}</h4>
                            <p className="text-xs text-slate-400 mb-2 truncate">{c.profileName}</p>
                            <div className="mt-auto flex items-center gap-1 text-xs font-bold text-slate-600">
                                <Users className="w-3 h-3" /> {c.viewsSuffix} Vistas
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        )}

        {/* Search & List */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden min-h-[400px]">
            <div className="p-4 border-b border-slate-100 bg-slate-50">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                        type="text" 
                        placeholder="Buscar canal o usuario..." 
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="w-full pl-9 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-blue-500 transition-shadow"
                    />
                </div>
            </div>
            
            <div className="divide-y divide-slate-100">
                {filteredProfiles.length === 0 ? (
                    <div className="p-10 text-center text-slate-400 text-sm">No se encontraron resultados.</div>
                ) : (
                    filteredProfiles.map(profile => (
                        <button 
                            key={profile.id} 
                            onClick={() => { setSelectedProfileId(profile.id); setView('profile'); }}
                            className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors text-left group"
                        >
                            <div className="flex items-center gap-4">
                                <div className={`w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold shadow-sm ${getPlatformColor()}`}>
                                    {profile.handle[1].toUpperCase()}
                                </div>
                                <div>
                                    <h4 className="font-bold text-slate-800 text-base group-hover:text-blue-600 transition-colors">{profile.handle}</h4>
                                    <p className="text-xs text-slate-400 font-medium">
                                        {profile.followersSuffix} Seguidores • {profile.content.length} {platform === 'X' ? 'Posts' : 'Videos'}
                                    </p>
                                </div>
                            </div>
                            <ExternalLink className="w-4 h-4 text-slate-300 group-hover:text-blue-500" />
                        </button>
                    ))
                )}
            </div>
        </div>

        {showCreatorSelector && (
            <ToySelector 
                toys={toys} 
                title="¿Quién crea el canal?" 
                minAge={10} 
                onSelect={handleCreateProfile} 
                onCancel={() => setShowCreatorSelector(false)} 
            />
        )}
      </div>
    </FullScreenPage>
  );
};