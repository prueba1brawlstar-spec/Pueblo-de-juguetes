
import React, { useState, useEffect } from 'react';
import { Toy, ToyType } from '../types';
import { CarFront, Cat, Ghost, Flower2, Trash2, FileSpreadsheet, MoreVertical, Edit, Eye, Crown, Footprints, Mars, Venus, X, User, Calendar, Users, Sparkles, AlertCircle, Info, Link as LinkIcon, Disc } from 'lucide-react';

interface ToyListProps {
  toys: Toy[];
  onDelete: (id: string) => void;
  onEdit: (toy: Toy) => void;
  showFamilyColumn?: boolean;
  hideActions?: boolean;
}

export const ToyList: React.FC<ToyListProps> = ({ toys, onDelete, onEdit, showFamilyColumn = false, hideActions = false }) => {
  // We use a coordinate system for the menu to avoid overflow clipping issues in tables
  const [menuState, setMenuState] = useState<{id: string, x: number, y: number} | null>(null);
  const [activeTooltipId, setActiveTooltipId] = useState<string | null>(null);
  const [viewToy, setViewToy] = useState<Toy | null>(null);
  
  // Real-time Animation Logic
  const prevToysLength = React.useRef(toys.length);
  const [listAnimation, setListAnimation] = useState<'green' | 'red' | null>(null);

  useEffect(() => {
    if (toys.length > prevToysLength.current) {
        setListAnimation('green');
        setTimeout(() => setListAnimation(null), 1000);
    } else if (toys.length < prevToysLength.current) {
        setListAnimation('red');
        setTimeout(() => setListAnimation(null), 1000);
    }
    prevToysLength.current = toys.length;
  }, [toys.length]);

  useEffect(() => {
    const handleClickOutside = () => {
      setMenuState(null);
      setActiveTooltipId(null);
    };
    if (menuState || activeTooltipId) {
      window.addEventListener('click', handleClickOutside);
      window.addEventListener('scroll', handleClickOutside); // Close on scroll too
    }
    return () => {
        window.removeEventListener('click', handleClickOutside);
        window.removeEventListener('scroll', handleClickOutside);
    };
  }, [menuState, activeTooltipId]);

  const handleMenuClick = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (menuState?.id === id) {
        setMenuState(null);
    } else {
        const rect = (e.currentTarget as HTMLButtonElement).getBoundingClientRect();
        // Calculate position: align right edge of menu with right edge of button, approx 10px down
        setMenuState({
            id,
            x: rect.right, 
            y: rect.bottom + 5
        });
    }
    setActiveTooltipId(null); 
  };
  
  const handleTypeClick = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setActiveTooltipId(activeTooltipId === id ? null : id);
    setMenuState(null); 
  };

  const handleAction = (action: 'delete' | 'edit' | 'open', toy: Toy) => {
    if (action === 'delete') onDelete(toy.id);
    if (action === 'edit') onEdit(toy);
    if (action === 'open') setViewToy(toy);
    setMenuState(null);
  };

  const handleRowClick = (toy: Toy) => {
      if (hideActions) {
          setViewToy(toy);
      }
  };

  if (toys.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-dashed border-slate-300 p-12 text-center h-full flex flex-col items-center justify-center min-h-[150px] shadow-sm">
        <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mb-3">
          <FileSpreadsheet className="w-6 h-6 text-slate-300" />
        </div>
        <h3 className="text-sm font-bold text-slate-700 mb-1">Lista Vacía</h3>
        <p className="text-xs text-slate-400">No hay integrantes en este grupo.</p>
      </div>
    );
  }

  const getTypeIcon = (type: ToyType, size = "w-4 h-4") => {
    const props = { className: size };
    switch (type) {
      case ToyType.CARRO: return <CarFront {...props} className={`${size} text-red-500`} />;
      case ToyType.ANIMAL: return <Cat {...props} className={`${size} text-amber-500`} />;
      case ToyType.MONSTRUO: return <Ghost {...props} className={`${size} text-purple-500`} />;
      case ToyType.PLANTA: return <Flower2 {...props} className={`${size} text-green-500`} />;
      case ToyType.DINOSAURIO: return <Footprints {...props} className={`${size} text-emerald-700`} />;
      case ToyType.TAPA: return <Disc {...props} className={`${size} text-blue-500`} />;
    }
  };

  const isDataIncomplete = (toy: Toy) => toy.age == null || !toy.birthday;

  const formatBirthday = (dateStr?: string | null) => {
     if (!dateStr) return '-';
     // Manually parse YYYY-MM-DD to avoid timezone shifts
     const parts = dateStr.split('-');
     if (parts.length !== 3) return '-';
     const date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
     
     // Format: D/M/YYYY
     const d = date.getDate();
     const m = date.getMonth() + 1;
     const y = date.getFullYear();
     return `${d}/${m}/${y}`;
  };

  return (
    <>
      <div className={`bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col w-full mx-auto transition-all duration-300 ${listAnimation === 'green' ? 'animate-flash-green' : listAnimation === 'red' ? 'animate-flash-red' : ''}`}>
        {!showFamilyColumn && (
            <div className="px-4 py-2 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
            <h3 className="font-bold text-slate-600 text-xs uppercase tracking-wide flex items-center gap-2">
                <Users className="w-3 h-3" /> Integrantes
            </h3>
            <span className="text-[10px] font-bold bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-500">
                {toys.length}
            </span>
            </div>
        )}
        
        <div className="overflow-x-auto custom-scrollbar w-full">
          <table className="min-w-full text-sm text-left border-collapse">
            <thead className="text-[10px] text-slate-400 uppercase bg-white border-b border-slate-100">
              <tr>
                {showFamilyColumn && <th className="px-4 py-3 font-bold">Familia</th>}
                <th className="px-4 py-3 font-bold">Nombre</th>
                <th className="px-2 py-3 font-bold text-center">Tipo</th>
                <th className="px-2 py-3 font-bold text-center">Edad</th>
                <th className="px-2 py-3 font-bold text-center">Cumple</th>
                {!hideActions && <th className="px-2 py-3 font-bold text-center">Acciones</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {toys.map((toy) => (
                <tr 
                    key={toy.id} 
                    onClick={() => handleRowClick(toy)}
                    className={`transition-colors group text-xs sm:text-sm ${toy.isLeader ? 'bg-amber-50/30' : 'hover:bg-slate-50'} ${hideActions ? 'cursor-pointer active:bg-slate-100' : ''}`}
                >
                  {showFamilyColumn && <td className="px-4 py-3 font-bold text-slate-500 truncate max-w-[100px]">{toy.family}</td>}
                  <td className="px-4 py-3 font-bold text-slate-800">
                    <div className="flex flex-col gap-0.5">
                      <div className="flex items-center gap-1.5">
                        {toy.isLeader && <Crown className="w-3 h-3 text-amber-500 fill-amber-500 shrink-0" />}
                        {toy.isSubFamilyLeader && <Crown className="w-3 h-3 text-purple-500 fill-purple-200 shrink-0" />}
                        <span className="truncate max-w-[150px] sm:max-w-xs">{toy.name}</span>
                        {isDataIncomplete(toy) && (
                            <AlertCircle className="w-3 h-3 text-orange-400 shrink-0" />
                        )}
                        {toy.relations && toy.relations.length > 0 && <LinkIcon className="w-3 h-3 text-blue-300 shrink-0" />}
                      </div>
                      {/* Gender Row */}
                      <div className="flex items-center">
                         {toy.gender === 'female' ? <Venus className="w-2.5 h-2.5 text-pink-400" /> : <Mars className="w-2.5 h-2.5 text-blue-400" />}
                      </div>
                    </div>
                  </td>
                  <td className="px-2 py-3 text-center">
                      <div className="inline-flex justify-center">
                          <button onClick={(e) => handleTypeClick(e, toy.id)} className="p-1 rounded hover:bg-slate-100 relative">
                              {getTypeIcon(toy.type)}
                              {activeTooltipId === toy.id && (
                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-2 py-1 bg-slate-800 text-white text-[10px] rounded whitespace-nowrap z-50">
                                    {toy.type}
                                </div>
                              )}
                          </button>
                      </div>
                  </td>
                  <td className="px-2 py-3 text-center text-slate-600 font-mono text-xs">{toy.age != null ? toy.age : '-'}</td>
                  <td className="px-2 py-3 text-center text-slate-500 text-xs font-medium whitespace-nowrap">
                      {formatBirthday(toy.birthday)}
                  </td>
                  {!hideActions && (
                      <td className="px-2 py-3 text-center">
                          <button onClick={(e) => handleMenuClick(e, toy.id)} className={`p-1.5 rounded-md transition-all ${menuState?.id === toy.id ? 'bg-blue-100 text-blue-600' : 'text-slate-300 hover:text-slate-600 hover:bg-slate-100'}`}>
                              <MoreVertical className="w-4 h-4" />
                          </button>
                      </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* FIXED DROPDOWN MENU */}
      {menuState && !hideActions && (
        <div 
            className="fixed bg-white rounded-lg shadow-xl border border-slate-100 z-[9999] overflow-hidden animate-in fade-in zoom-in-95 duration-100 w-32"
            style={{ 
                top: menuState.y, 
                left: menuState.x,
                transform: 'translateX(-100%)' // Align right edge
            }}
        >
            <div className="flex flex-col py-1">
                <button onClick={() => handleAction('open', toys.find(t => t.id === menuState.id)!)} className="px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2">
                    <Eye className="w-3.5 h-3.5 text-blue-500" /> Ver
                </button>
                <button onClick={() => handleAction('edit', toys.find(t => t.id === menuState.id)!)} className="px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2">
                    <Edit className="w-3.5 h-3.5 text-amber-500" /> Editar
                </button>
                <div className="h-px bg-slate-100 my-0.5"></div>
                <button onClick={() => handleAction('delete', toys.find(t => t.id === menuState.id)!)} className="px-3 py-2 text-left text-xs font-medium text-red-600 hover:bg-red-50 flex items-center gap-2">
                    <Trash2 className="w-3.5 h-3.5" /> Eliminar
                </button>
            </div>
        </div>
      )}

      {viewToy && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
           <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden relative border border-slate-200 animate-in zoom-in-95 duration-300">
              <button onClick={() => setViewToy(null)} className="absolute top-3 right-3 z-10 bg-white/20 hover:bg-white/40 text-white rounded-full p-2 transition-all"><X className="w-5 h-5 drop-shadow-md" /></button>
              <div className="bg-gradient-to-br from-blue-600 to-indigo-700 pt-8 pb-16 relative">
                 <div className="absolute top-0 left-0 w-full h-full opacity-10"><Sparkles className="w-full h-full p-10" /></div>
                 <div className="flex flex-col items-center relative z-10">
                    <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-xl ring-4 ring-white/30 mb-3">{getTypeIcon(viewToy.type, "w-12 h-12")}</div>
                    <h2 className="text-2xl font-extrabold text-white text-center px-4 flex items-center gap-2">{viewToy.name}{viewToy.isLeader && <Crown className="w-6 h-6 text-amber-300 fill-amber-300 drop-shadow-sm" />}</h2>
                    <span className="text-blue-100 text-sm font-medium bg-white/10 px-3 py-0.5 rounded-full mt-1 border border-white/20">Identificación Oficial</span>
                 </div>
              </div>
              <div className="px-6 py-6 -mt-10 relative z-10 space-y-4">
                  <div className="bg-white p-4 rounded-xl shadow-lg border border-slate-100 flex items-center gap-4">
                     <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center text-blue-600 shrink-0"><Users className="w-6 h-6" /></div>
                     <div className="overflow-hidden">
                         <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Familia</h4>
                         <p className="text-lg font-bold text-slate-800 truncate">{viewToy.family}</p>
                         {viewToy.subFamily && <p className="text-xs font-bold text-purple-500 flex items-center gap-1"><Crown className="w-3 h-3"/> {viewToy.subFamily}</p>}
                     </div>
                  </div>
                  
                  {isDataIncomplete(viewToy) && (<div className="bg-orange-50 border border-orange-100 rounded-xl p-3 flex flex-col items-center text-center shadow-sm"><Info className="w-6 h-6 text-orange-400 mb-1" /><p className="text-xs font-bold text-orange-600">¡No has puesto la fecha de cumpleaños!</p><p className="text-[10px] text-orange-400">Edita al habitante para completar sus datos.</p></div>)}

                  {viewToy.relations && viewToy.relations.length > 0 && (
                      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                          <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1"><LinkIcon className="w-3 h-3"/> Relaciones</h4>
                          <div className="flex flex-wrap gap-2">
                              {viewToy.relations.map((rel, i) => {
                                  const target = toys.find(t => t.id === rel.toyId);
                                  return (
                                      <div key={i} className="text-xs bg-slate-50 border border-slate-200 px-2 py-1 rounded flex items-center gap-1">
                                          <span className="font-bold text-blue-600">{rel.type}</span> 
                                          <span className="text-slate-500">de {target?.name || '???'}</span>
                                      </div>
                                  )
                              })}
                          </div>
                      </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm"><div className="flex items-center gap-2 mb-1 text-slate-400"><Calendar className="w-4 h-4" /><span className="text-[10px] font-bold uppercase">Edad</span></div><p className="text-lg font-bold text-slate-800">{viewToy.age != null ? `${viewToy.age} Años` : <span className="text-slate-300 text-sm">N/A</span>}</p></div>
                      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm"><div className="flex items-center gap-2 mb-1 text-slate-400"><User className="w-4 h-4" /><span className="text-[10px] font-bold uppercase">Género</span></div><div className="flex items-center gap-1 font-bold text-slate-800">{viewToy.gender === 'female' ? (<>Femenino <Venus className="w-4 h-4 text-pink-500" /></>) : (<>Masculino <Mars className="w-4 h-4 text-blue-500" /></>)}</div></div>
                  </div>
              </div>
              <div className="p-4 border-t border-slate-100 bg-slate-50"><button onClick={() => setViewToy(null)} className="w-full py-3 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl shadow-lg transition-transform active:scale-95">Cerrar Tarjeta</button></div>
           </div>
        </div>
      )}
    </>
  );
};
