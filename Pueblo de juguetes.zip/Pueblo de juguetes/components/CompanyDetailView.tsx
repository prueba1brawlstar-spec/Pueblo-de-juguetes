import React, { useState } from 'react';
import { Factory, User, ArrowLeft, Plus, Trash2, Briefcase, DollarSign, ChevronDown, MoreVertical, X, TrendingUp, TrendingDown, UserMinus } from 'lucide-react';
import { Toy, Company, CompanyEmployee, CompanyRole } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';
import { ScaleSelector } from './ScaleSelector';
import { RoleSelector } from './RoleSelector';

interface CompanyDetailViewProps {
  company: Company;
  toys: Toy[];
  onUpdateCompany: (id: string, data: Partial<Company>) => void;
  onBack: () => void;
}

const MONEY_SCALES = [
    "Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", 
    "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", 
    "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón",
    "Unvigintillón", "Duovigintillón", "Tresvigintillón", "Cuatrovigintillón", "Quinquevigintillón", "Sexvigintillón", "Septemvigintillón", "Octovigintillón", "Novemvigintillón",
    "Trigintillón", "Untrigintillón", "Duotrigintillón", "Trestrigintillón", "Cuatrotrigintillón", "Quinquetrigintillón", "Sextrigintillón", "Septemtrigintillón", "Octotrigintillón", "Novemtrigintillón",
    "Cuadragintillón", "Uncuadragintillón", "Duocuadragintillón", "Trescuadragintillón", "Cuatrocuadragintillón", "Quinquecuadragintillón", "Sexcuadragintillón", "Septemcuadragintillón", "Octocuadragintillón", "Novemcuadragintillón",
    "Quinquagintillón", "Unquinquagintillón", "Duoquinquagintillón", "Tresquinquagintillón", "Cuatroquinquagintillón", "Quinquequinquagintillón", "Sexquinquagintillón", "Septemquinquagintillón", "Octoquinquagintillón", "Novemquinquagintillón",
    "Sexagintillón", "Unsexagintillón", "Duosexagintillón", "Tresexagintillón", "Cuatrosexagintillón", "Quinquesexagintillón", "Sexsexagintillón", "Septemsexagintillón", "Octosexagintillón", "Novemsexagintillón",
    "Septuagintillón", "Unseptuagintillón", "Duoseptuagintillón", "Treseptuagintillón", "Cuatroseptuagintillón", "Quinquesseptuagintillón", "Sexseptuagintillón", "Septemseptuagintillón", "Octoseptuagintillón", "Novemseptuagintillón",
    "Octogintillón", "Unoctogintillón", "Duooctogintillón", "Tresoctogintillón", "Cuatrooctogintillón", "Quinqueoctogintillón", "Sexoctogintillón", "Septemoctogintillón", "Octooctogintillón", "Novemoctogintillón",
    "Nonagintillón", "Unnonagintillón", "Duononagintillón", "Tresnonagintillón", "Cuatrononagintillón", "Quinquenonagintillón", "Sexnonagintillón", "Septemnonagintillón", "Octononagintillón", "Novemnonagintillón",
    "Centillón"
];

const formatMoneyWithScale = (amount: number, forceSuffix?: string) => {
    if (forceSuffix) return { amount, suffix: forceSuffix };
    if (amount >= 1000 && amount < 1000000) return { amount: Math.round(amount / 1000), suffix: 'Mil' };
    if (amount < 1000) return { amount: amount, suffix: '' };
    let temp = amount / 1000000;
    let scaleIdx = 0;
    while (temp >= 1000 && scaleIdx < MONEY_SCALES.length - 1) { temp /= 1000; scaleIdx++; }
    return { amount: Math.round(temp * 100) / 100, suffix: MONEY_SCALES[scaleIdx] };
};

export const CompanyDetailView: React.FC<CompanyDetailViewProps> = ({ company, toys, onUpdateCompany, onBack }) => {
  const [tab, setTab] = useState<'info' | 'roles'>('info');
  const [showEmployeeSelector, setShowEmployeeSelector] = useState(false);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [newEmployeeRole, setNewEmployeeRole] = useState(company.customRoles[0]?.name || '');
  
  // Create Role State
  const [roleName, setRoleName] = useState('');
  const [roleSalary, setRoleSalary] = useState('');
  const [roleScale, setRoleScale] = useState('Mil');
  const [showScaleSelector, setShowScaleSelector] = useState(false);
  const [showRoleSelector, setShowRoleSelector] = useState(false);

  // Manage Employee Modal
  const [managingEmployee, setManagingEmployee] = useState<CompanyEmployee | null>(null);

  const owner = toys.find(t => t.id === company.ownerId);

  const handleHire = () => {
      if (!selectedEmployeeId) return;
      const roleDef = company.customRoles.find(r => r.name === newEmployeeRole);
      let salary = 1000000;
      if (roleDef) {
          let multiplier = 1;
          if (roleDef.salarySuffix === 'Mil') multiplier = 1000;
          else if (roleDef.salarySuffix) {
              const idx = MONEY_SCALES.indexOf(roleDef.salarySuffix);
              if (idx !== -1) multiplier = Math.pow(1000, idx) * 1000000;
          }
          salary = roleDef.baseSalary * multiplier;
      }

      const newEmp: CompanyEmployee = { id: crypto.randomUUID(), toyId: selectedEmployeeId, role: newEmployeeRole, salary };
      onUpdateCompany(company.id, { employees: [...company.employees, newEmp] });
      setSelectedEmployeeId(null);
  };

  const handleAddRole = () => {
      if (!roleName || !roleSalary) return;
      const newRole: CompanyRole = {
          id: crypto.randomUUID(),
          name: roleName,
          baseSalary: parseFloat(roleSalary),
          salarySuffix: roleScale
      };
      onUpdateCompany(company.id, { customRoles: [...company.customRoles, newRole] });
      setRoleName('');
      setRoleSalary('');
      setRoleScale('Mil');
  };

  const handleDeleteRole = (roleId: string) => {
      onUpdateCompany(company.id, { customRoles: company.customRoles.filter(r => r.id !== roleId) });
  };

  // --- Employee Management Actions ---
  const handleUpdateSalary = (increment: boolean) => {
      if (!managingEmployee) return;
      const newSalary = increment ? managingEmployee.salary * 1.10 : managingEmployee.salary * 0.90;
      const updatedEmployees = company.employees.map(e => e.id === managingEmployee.id ? { ...e, salary: newSalary } : e);
      onUpdateCompany(company.id, { employees: updatedEmployees });
      setManagingEmployee({ ...managingEmployee, salary: newSalary }); // Update modal view
  };

  const handleChangeRole = (newRole: string) => {
      if (!managingEmployee) return;
      const updatedEmployees = company.employees.map(e => e.id === managingEmployee.id ? { ...e, role: newRole } : e);
      onUpdateCompany(company.id, { employees: updatedEmployees });
      setManagingEmployee({ ...managingEmployee, role: newRole });
      setShowRoleSelector(false);
  };

  const handleFireEmployee = () => {
      if (!managingEmployee) return;
      onUpdateCompany(company.id, { employees: company.employees.filter(e => e.id !== managingEmployee.id) });
      setManagingEmployee(null);
  };

  return (
    <FullScreenPage>
        {showScaleSelector && (
            <ScaleSelector 
                scales={['Mil', ...MONEY_SCALES]} 
                currentScale={roleScale} 
                onSelect={(s) => { setRoleScale(s); setShowScaleSelector(false); }} 
                onClose={() => setShowScaleSelector(false)} 
            />
        )}
        
        <div className="max-w-5xl mx-auto px-4 pt-4 md:pt-0 md:mt-8">
            <div className="flex items-center gap-3 mb-6">
                <button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
                <div><h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><Factory className="w-6 h-6 text-orange-600" />{company.name}</h2><p className="text-sm text-slate-500 font-mono">{company.description || 'Sin descripción'}</p></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-orange-900 text-white rounded-xl p-6 shadow-lg relative overflow-hidden">
                    <div className="flex items-center gap-4 relative z-10"><div className="w-16 h-16 bg-orange-800 rounded-full flex items-center justify-center border-2 border-orange-400"><User className="w-8 h-8 text-orange-100" /></div><div><div className="text-xl font-bold">{owner?.name || 'Desconocido'}</div><div className="text-orange-300 text-sm font-medium">{owner?.family}</div></div></div>
                </div>
                <div className="md:col-span-2 bg-white rounded-xl border border-orange-100 shadow-sm p-6 flex flex-col justify-center">
                    <h3 className="text-slate-500 font-bold text-xs uppercase mb-1">Capital Social</h3>
                    <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2">
                        {/* Display abbreviated only */}
                        <div className="text-3xl md:text-4xl font-mono font-bold text-orange-600 break-words w-full">COP ${company.capitalAmount.toLocaleString()}</div>
                        <div className="text-lg md:text-xl font-bold text-orange-400 truncate w-full sm:w-auto">{company.capitalSuffix}</div>
                    </div>
                </div>
            </div>

            <div className="flex gap-4 mt-8 border-b border-slate-200 overflow-x-auto no-scrollbar">
                <button onClick={() => setTab('info')} className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${tab === 'info' ? 'border-orange-500 text-orange-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>Empleados ({company.employees.length})</button>
                <button onClick={() => setTab('roles')} className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${tab === 'roles' ? 'border-orange-500 text-orange-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>Configurar Roles</button>
            </div>

            {tab === 'info' && (
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mt-6 p-6">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="font-bold text-slate-700">Personal</h3>
                        <button onClick={() => setShowEmployeeSelector(true)} className="text-xs bg-orange-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-orange-700 transition-colors flex items-center gap-1"><Plus className="w-3 h-3"/> Contratar</button>
                    </div>
                    {company.employees.length === 0 ? (
                        <div className="text-center py-8 text-slate-400 text-sm">No hay empleados.</div>
                    ) : (
                        <div className="space-y-2">
                            {company.employees.map(emp => {
                                const t = toys.find(x => x.id === emp.toyId);
                                const { amount, suffix } = formatMoneyWithScale(emp.salary);
                                return (
                                    <button 
                                        key={emp.id} 
                                        onClick={() => setManagingEmployee(emp)}
                                        className="w-full flex justify-between items-center p-3 border rounded-lg bg-white hover:bg-slate-50 transition-colors text-left"
                                    >
                                        <div>
                                            <div className="font-bold text-slate-800 text-sm">{t?.name || 'Unknown'}</div>
                                            <div className="text-xs text-orange-600 font-bold">{emp.role}</div>
                                        </div>
                                        <div className="text-right">
                                            <div className="font-bold text-slate-700 text-xs">${amount} {suffix}</div>
                                        </div>
                                    </button>
                                );
                            })}
                        </div>
                    )}
                </div>
            )}

            {tab === 'roles' && (
                <div className="space-y-6 mt-6">
                    {/* Add Role Form - Simplified */}
                    <div className="bg-orange-50 rounded-xl border border-orange-200 p-4">
                        <h3 className="text-sm font-bold text-orange-800 mb-3 flex items-center gap-2"><Plus className="w-4 h-4"/> Crear Nuevo Cargo</h3>
                        <div className="flex flex-col md:flex-row gap-3 items-end">
                            <div className="w-full md:flex-1">
                                <label className="text-[10px] uppercase font-bold text-orange-600 mb-1 block">Nombre del Cargo</label>
                                <input type="text" value={roleName} onChange={e => setRoleName(e.target.value)} placeholder="Ej. Gerente General" className="w-full p-2 rounded-lg bg-white border border-orange-200 text-sm font-bold text-slate-800 focus:ring-2 focus:ring-orange-400 outline-none" />
                            </div>
                            <div className="w-full md:w-1/2">
                                <label className="text-[10px] uppercase font-bold text-orange-600 mb-1 block">Sueldo Base</label>
                                <div className="flex gap-2">
                                    <div className="relative flex-1">
                                        <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-orange-400" />
                                        <input type="number" value={roleSalary} onChange={e => setRoleSalary(e.target.value)} placeholder="0" className="w-full pl-6 pr-2 py-2 bg-white rounded-lg border border-orange-200 text-sm font-bold text-slate-800 outline-none focus:ring-2 focus:ring-orange-400" />
                                    </div>
                                    <button onClick={() => setShowScaleSelector(true)} className="px-3 py-2 bg-white border border-orange-200 rounded-lg text-xs font-bold text-orange-700 flex items-center gap-1 hover:bg-orange-100">
                                        {roleScale} <ChevronDown className="w-3 h-3" />
                                    </button>
                                </div>
                            </div>
                            <button onClick={handleAddRole} disabled={!roleName || !roleSalary} className="w-full md:w-auto px-6 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-lg shadow-sm disabled:opacity-50 transition-colors h-[38px]">
                                Añadir
                            </button>
                        </div>
                    </div>

                    {/* Roles List */}
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="px-4 py-3 bg-slate-50 border-b border-slate-100">
                            <h3 className="font-bold text-slate-700 text-sm">Cargos Disponibles</h3>
                        </div>
                        {company.customRoles.length === 0 ? (
                            <div className="p-8 text-center text-slate-400 text-sm">No hay cargos definidos.</div>
                        ) : (
                            <div className="divide-y divide-slate-100">
                                {company.customRoles.map(role => (
                                    <div key={role.id} className="flex justify-between items-center p-4 hover:bg-slate-50 transition-colors">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-orange-100 rounded-lg text-orange-600"><Briefcase className="w-4 h-4"/></div>
                                            <div>
                                                <div className="font-bold text-slate-800 text-sm">{role.name}</div>
                                                <div className="text-xs text-slate-500 font-mono font-medium">
                                                    ${role.baseSalary.toLocaleString()} {role.salarySuffix}
                                                </div>
                                            </div>
                                        </div>
                                        <button onClick={() => handleDeleteRole(role.id)} className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-all">
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* HIRE MODAL */}
            {showEmployeeSelector && <ToySelector toys={toys} title="Contratar Empleado" excludeIds={[company.ownerId, ...company.employees.map(e => e.toyId)]} minAge={18} onSelect={(id) => { setSelectedEmployeeId(id); setShowEmployeeSelector(false); }} onCancel={() => setShowEmployeeSelector(false)} />}
            
            {/* ROLE ASSIGNMENT MODAL (INITIAL HIRE) */}
            {selectedEmployeeId && (
                <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm p-6 border border-slate-200">
                        <h3 className="text-lg font-bold text-slate-800 mb-4">Asignar Cargo</h3>
                        {company.customRoles.length === 0 ? (
                            <div className="text-center mb-4">
                                <p className="text-sm text-red-500 mb-2">¡No hay cargos creados!</p>
                                <p className="text-xs text-slate-500">Primero ve a la pestaña "Configurar Roles" y crea uno.</p>
                            </div>
                        ) : (
                            <button onClick={() => setShowRoleSelector(true)} className="w-full p-3 bg-white border border-slate-300 rounded-lg text-sm font-bold outline-none mb-4 text-left flex justify-between items-center text-slate-700">
                                {newEmployeeRole || 'Seleccionar...'}
                                <ChevronDown className="w-4 h-4 text-slate-400" />
                            </button>
                        )}
                        <div className="flex gap-3">
                            <button onClick={() => setSelectedEmployeeId(null)} className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl">Cancelar</button>
                            {company.customRoles.length > 0 && (
                                <button onClick={handleHire} disabled={!newEmployeeRole} className="flex-1 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-lg disabled:opacity-50">Contratar</button>
                            )}
                        </div>
                    </div>
                </div>
            )}
            
            {/* EMPLOYEE MANAGEMENT MODAL */}
            {managingEmployee && (
                <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 border border-slate-200 relative animate-in zoom-in-95">
                        <button onClick={() => setManagingEmployee(null)} className="absolute top-3 right-3 text-slate-400 hover:text-slate-600"><X className="w-5 h-5"/></button>
                        <div className="text-center mb-6">
                            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3 text-slate-500 border border-slate-200"><User className="w-8 h-8"/></div>
                            <h3 className="text-lg font-bold text-slate-800">{toys.find(t => t.id === managingEmployee.toyId)?.name}</h3>
                            <p className="text-sm text-orange-600 font-bold">{managingEmployee.role}</p>
                        </div>

                        <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 mb-6">
                            <p className="text-xs text-slate-400 font-bold uppercase text-center mb-2">Sueldo Actual</p>
                            <div className="text-center">
                                {(() => {
                                    const { amount, suffix } = formatMoneyWithScale(managingEmployee.salary);
                                    return <div className="text-2xl font-black text-slate-800">${amount} <span className="text-base text-slate-500">{suffix}</span></div>
                                })()}
                            </div>
                            <div className="flex gap-2 mt-3">
                                <button onClick={() => handleUpdateSalary(false)} className="flex-1 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-red-600 hover:bg-red-50 flex items-center justify-center gap-1"><TrendingDown className="w-3 h-3"/> -10%</button>
                                <button onClick={() => handleUpdateSalary(true)} className="flex-1 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-green-600 hover:bg-green-50 flex items-center justify-center gap-1"><TrendingUp className="w-3 h-3"/> +10%</button>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <button onClick={() => setShowRoleSelector(true)} className="w-full py-3 bg-blue-50 text-blue-700 font-bold rounded-xl hover:bg-blue-100 transition-colors flex items-center justify-center gap-2"><Briefcase className="w-4 h-4"/> Cambiar Cargo</button>
                            <button onClick={handleFireEmployee} className="w-full py-3 bg-white border-2 border-red-100 text-red-500 font-bold rounded-xl hover:bg-red-50 transition-colors flex items-center justify-center gap-2"><UserMinus className="w-4 h-4"/> Despedir / Renunciar</button>
                        </div>
                    </div>
                </div>
            )}

            {/* SHARED ROLE SELECTOR */}
            {showRoleSelector && (
                <RoleSelector 
                    roles={company.customRoles.map(r => r.name)}
                    currentRole={managingEmployee ? managingEmployee.role : newEmployeeRole}
                    onSelect={(role) => { 
                        if (managingEmployee) handleChangeRole(role);
                        else { setNewEmployeeRole(role); setShowRoleSelector(false); }
                    }}
                    onClose={() => setShowRoleSelector(false)}
                />
            )}
        </div>
    </FullScreenPage>
  );
};