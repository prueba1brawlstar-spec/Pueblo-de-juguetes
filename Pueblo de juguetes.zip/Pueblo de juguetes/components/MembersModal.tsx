
import React, { useEffect } from 'react';
import { Users, X, ShieldCheck, User } from 'lucide-react';
import { TownMember } from '../types';

interface MembersModalProps {
  members: TownMember[];
  onClose: () => void;
}

export const MembersModal: React.FC<MembersModalProps> = ({ members, onClose }) => {
  useEffect(() => {
    // Prevent body scrolling when modal is open
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, []);

  // Use fixed top-0 safe-screen to respect visual viewport
  return (
    <div className="fixed inset-x-0 top-0 safe-screen z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden flex flex-col max-h-[85vh] border border-slate-200">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="w-5 h-5 text-blue-600" />
            </div>
            <div>
                <h3 className="font-bold text-slate-800 text-lg">Permisos de Edición</h3>
                <p className="text-xs text-slate-500">Personas autorizadas</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        {/* List */}
        <div className="overflow-y-auto flex-1 p-4 space-y-3 custom-scrollbar bg-slate-50/50">
          {members.map((member) => (
            <div key={member.userId} className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center border ${member.role === 'admin' ? 'bg-purple-50 border-purple-200 text-purple-600' : 'bg-slate-50 border-slate-200 text-slate-500'}`}>
                        {member.role === 'admin' ? <ShieldCheck className="w-5 h-5" /> : <User className="w-5 h-5" />}
                    </div>
                    <div>
                        <div className="font-bold text-slate-800 text-sm">{member.name}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                           Unido: {new Date(member.joinedAt).toLocaleDateString()}
                        </div>
                    </div>
                </div>
                {member.role === 'admin' && (
                    <span className="bg-purple-100 text-purple-700 text-[10px] font-bold px-2 py-1 rounded-lg uppercase tracking-wider">
                        Admin
                    </span>
                )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
