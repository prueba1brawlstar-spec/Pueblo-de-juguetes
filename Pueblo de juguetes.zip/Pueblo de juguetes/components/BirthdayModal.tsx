
import React from 'react';
import { PartyPopper, Cake, X, Sparkles } from 'lucide-react';

interface Birthday {
  id: string;
  name: string;
  newAge: number;
}

interface BirthdayModalProps {
  birthdays: Birthday[];
  onClose: () => void;
}

export const BirthdayModal: React.FC<BirthdayModalProps> = ({ birthdays, onClose }) => {
  if (birthdays.length === 0) return null;

  return (
    <div className="fixed inset-x-0 top-0 safe-screen z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-in fade-in duration-500">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden relative border-4 border-pink-200 animate-in zoom-in-95 duration-500">
        
        {/* Confetti Background Effect (CSS only representation) */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-0 left-1/4 w-2 h-2 bg-red-400 rounded-full animate-bounce delay-100"></div>
            <div className="absolute top-10 right-1/4 w-3 h-3 bg-blue-400 rounded-full animate-bounce delay-300"></div>
            <div className="absolute top-5 left-1/2 w-2 h-2 bg-yellow-400 rounded-full animate-bounce delay-700"></div>
        </div>

        <div className="bg-gradient-to-b from-pink-50 to-white p-8 text-center relative z-10">
          <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-xl ring-4 ring-pink-100">
            <Cake className="w-12 h-12 text-pink-500" />
          </div>
          
          <h2 className="text-3xl font-extrabold text-slate-800 mb-2 flex items-center justify-center gap-2">
            <PartyPopper className="w-8 h-8 text-yellow-500" />
            ¡Feliz Cumpleaños!
          </h2>
          
          <p className="text-slate-500 mb-6 font-medium">
            ¡Hoy es un día especial en el pueblo!
          </p>

          <div className="space-y-3 mb-8">
            {birthdays.map((b) => (
              <div key={b.id} className="bg-white p-4 rounded-2xl border-2 border-pink-100 shadow-sm flex items-center justify-between">
                <div className="text-left">
                    <span className="block font-bold text-slate-800 text-lg">{b.name}</span>
                    <span className="text-xs text-pink-400 font-bold uppercase tracking-wider">¡Subió de nivel!</span>
                </div>
                <div className="flex flex-col items-center justify-center bg-pink-50 w-12 h-12 rounded-xl border border-pink-200">
                    <span className="text-xl font-extrabold text-pink-600">{b.newAge}</span>
                    <span className="text-[8px] font-bold text-pink-400">AÑOS</span>
                </div>
              </div>
            ))}
          </div>

          <button 
            onClick={onClose}
            className="w-full py-4 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-extrabold rounded-2xl shadow-lg shadow-pink-200 transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <Sparkles className="w-5 h-5" />
            ¡A Celebrar!
          </button>
        </div>
      </div>
    </div>
  );
};
