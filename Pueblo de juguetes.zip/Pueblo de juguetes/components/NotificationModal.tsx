
import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { CheckCircle2, AlertTriangle, Info, X, Copy } from 'lucide-react';

export type NotificationType = 'success' | 'error' | 'info';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: NotificationType;
  title: string;
  message: string;
  copyText?: string; 
}

export const NotificationModal: React.FC<NotificationModalProps> = ({ 
  isOpen, onClose, type, title, message, copyText 
}) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
      setMounted(true);
  }, []);

  if (!isOpen || !mounted) return null;

  const getIcon = () => {
    switch (type) {
      case 'success': return <CheckCircle2 className="w-12 h-12 text-green-500" />;
      case 'error': return <AlertTriangle className="w-12 h-12 text-red-500" />;
      case 'info': return <Info className="w-12 h-12 text-blue-500" />;
    }
  };

  const handleCopy = () => {
    if (copyText) {
      navigator.clipboard.writeText(copyText);
    }
  };

  // Portal to body ensures this sits on top of everything (z-[10001])
  // Use safe-screen to respect viewport height and prevent keyboard push-up
  return createPortal(
    <div className="fixed inset-x-0 top-0 safe-screen z-[10001] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200 font-sans">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden relative border border-slate-200 animate-in zoom-in-95 duration-300">
        
        <button 
          onClick={onClose}
          className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 p-1 hover:bg-slate-100 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 flex flex-col items-center text-center">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${
            type === 'success' ? 'bg-green-100' : type === 'error' ? 'bg-red-100' : 'bg-blue-100'
          }`}>
            {getIcon()}
          </div>

          <h3 className="text-xl font-extrabold text-slate-800 mb-2 leading-tight">
            {title}
          </h3>
          
          <div className="text-sm text-slate-500 leading-relaxed mb-6 whitespace-pre-line">
            {message}
          </div>

          {copyText && (
            <div className="w-full mb-6">
                <div className="bg-slate-100 p-3 rounded-xl border border-slate-200 flex items-center justify-between gap-2">
                    <code className="text-xs font-mono font-bold text-slate-600 truncate flex-1 text-left">
                        {copyText}
                    </code>
                    <button 
                        onClick={handleCopy}
                        className="p-1.5 bg-white border border-slate-200 rounded-lg hover:text-blue-600 hover:border-blue-300 transition-colors shadow-sm"
                        title="Copiar ID"
                    >
                        <Copy className="w-4 h-4" />
                    </button>
                </div>
                <p className="text-[10px] text-slate-400 mt-1 uppercase font-bold tracking-wide">
                    Guarda este ID para volver a entrar
                </p>
            </div>
          )}

          <button 
            onClick={onClose}
            className={`w-full py-3 rounded-xl font-bold shadow-lg transition-transform active:scale-95 text-white ${
                type === 'success' ? 'bg-green-600 hover:bg-green-700 shadow-green-200' : 
                type === 'error' ? 'bg-red-600 hover:bg-red-700 shadow-red-200' : 
                'bg-blue-600 hover:bg-blue-700 shadow-blue-200'
            }`}
          >
            Entendido
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
};
