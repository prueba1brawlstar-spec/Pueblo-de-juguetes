
import React, { useState, useLayoutEffect, useEffect } from 'react';
import { Toy } from '../types';
import { Users, Plus, ChevronRight, Search, AlertCircle, ArrowDownWideNarrow, ArrowUpNarrowWide } from 'lucide-react';

interface FamilyGridProps {
  toys: Toy[];
  onSelectFamily: (familyName: string) => void;
  onCreateFamily: () => void;
}

export const FamilyGrid: React.FC<FamilyGridProps> = ({ toys, onSelectFamily, onCreateFamily }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'countDesc'>('name');

  // Restore scroll position
  useLayoutEffect(() => {
      const container = document.getElementById('full-screen-page-content');
      const savedScroll = sessionStorage.getItem('familyGridScroll');
      
      if (container && savedScroll) {
          container.scrollTop = parseInt(savedScroll);
      }
  }, []);

  // Save scroll position on scroll event continuously
  useEffect(() => {
      const container = document.getElementById('full-screen-page-content');
      const handleScroll = () => {
          if (container) {
              sessionStorage.setItem('familyGridScroll', container.scrollTop.toString());
          }
      };

      if (container) {
          container.addEventListener('scroll', handleScroll, { passive: true });
      }

      return () => {
          if (container) {
              container.removeEventListener('scroll', handleScroll);
          }
      };
  }, []);

  // Group toys by family
  const families = React.useMemo(() => {
    const grouped: Record<string, Toy[]> = {};
    toys.forEach(toy => {
      if (!grouped[toy.family]) grouped[toy.family] = [];
      grouped[toy.family].push(toy);
    });
    return Object.entries(grouped);
  }, [toys]);

  // Filter & Sort
  const filteredFamilies = families
    .filter(([name]) => name.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => {
        if (sortBy === 'countDesc') {
            return b[1].length - a[1].length;
        }
        return a[0].localeCompare(b[0]);
    });

  const hasIncompleteData = (members: Toy[]) => {
      return members.some(m => m.age == null || !m.birthday);
  };

  return (
    <div className="space-y-6 animate-enter-view">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-xl font-bold text-slate-800">Familias del Pueblo</h2>
        
        <div className="flex gap-2 w-full md:w-auto">
            {/* Sort Button */}
            <button 
                onClick={() => setSortBy(prev => prev === 'name' ? 'countDesc' : 'name')}
                className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-2 active:scale-95 ${sortBy === 'countDesc' ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-white text-slate-500 border-slate-200'}`}
            >
                {sortBy === 'countDesc' ? <ArrowDownWideNarrow className="w-4 h-4"/> : <ArrowUpNarrowWide className="w-4 h-4"/>}
                {sortBy === 'countDesc' ? 'Mayor a Menor' : 'Alfabético'}
            </button>

            {/* Family Search */}
            <div className="relative flex-1 md:w-64">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="w-4 h-4 text-slate-400" />
                </div>
                <input
                    type="text"
                    placeholder="Buscar familia..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Create Card (Minimalist) */}
        <button
          onClick={onCreateFamily}
          className="flex flex-col items-center justify-center p-6 bg-white border border-dashed border-slate-300 rounded-xl hover:border-blue-400 hover:bg-blue-50/50 transition-all group min-h-[100px] active:scale-95"
        >
          <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform group-hover:bg-blue-100">
            <Plus className="w-5 h-5 text-slate-400 group-hover:text-blue-600" />
          </div>
          <span className="font-bold text-slate-600 text-sm group-hover:text-blue-700">Crear Familia</span>
        </button>

        {/* Family Cards (Minimalist) */}
        {filteredFamilies.map(([familyName, members]) => (
          <button
            key={familyName}
            onClick={() => onSelectFamily(familyName)}
            className="flex items-center justify-between bg-white p-5 rounded-xl shadow-sm border border-slate-200 hover:shadow-md hover:border-blue-300 transition-all group relative overflow-hidden active:scale-95"
          >
            {hasIncompleteData(members) && (
                <div className="absolute top-2 right-2">
                    <span className="flex h-3 w-3 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-orange-500 border border-white"></span>
                    </span>
                </div>
            )}
            
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-50 rounded-lg group-hover:bg-blue-100 transition-colors">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
              <div className="text-left">
                <h3 className="font-bold text-base text-slate-800 break-words leading-tight mb-0.5">
                  {familyName}
                </h3>
                <span className="text-xs font-semibold text-slate-400">
                  {members.length} {members.length === 1 ? 'Miembro' : 'Miembros'}
                </span>
              </div>
            </div>
            
            <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-500 transition-colors" />
          </button>
        ))}

        {filteredFamilies.length === 0 && (
          <div className="col-span-full py-8 text-center text-slate-400 text-sm">
            No se encontraron familias con ese nombre.
          </div>
        )}
      </div>
    </div>
  );
};
