
import React, { useLayoutEffect, useState, useEffect } from 'react';
import { createPortal } from 'react-dom';

interface FullScreenPageProps {
  children: React.ReactNode;
  noScroll?: boolean; 
}

export const FullScreenPage: React.FC<FullScreenPageProps> = ({ children, noScroll = false }) => {
  const [mounted, setMounted] = useState(false);

  useLayoutEffect(() => {
    setMounted(true);
    
    // Force scroll to top SYNCHRONOUSLY before paint
    const timer = setTimeout(() => {
        const pageElement = document.getElementById('full-screen-page-content');
        if (pageElement) {
            pageElement.scrollTop = 0;
        }
    }, 0);

    return () => {
      clearTimeout(timer);
    };
  }, []);

  if (!mounted) return null;

  // Use the safe-screen class defined in index.html which uses --viewport-height
  return createPortal(
    <div 
        className="fixed inset-x-0 top-0 safe-screen z-[9999] bg-slate-50 w-full flex flex-col font-sans overscroll-none touch-pan-y"
    >
      <div 
        id="full-screen-page-content"
        className={`flex-1 w-full overflow-x-hidden ${
          noScroll 
            ? 'flex items-center justify-center p-4' 
            : 'overflow-y-auto custom-scrollbar scroll-smooth'     
        }`}
      >
        <div className={`w-full mx-auto bg-slate-50 min-h-full ${
            noScroll 
                ? 'max-w-md w-full' 
                : 'max-w-5xl px-4 pt-6 md:pt-10 pb-40 md:pb-24'
        }`}>
          {children}
        </div>
      </div>
    </div>,
    document.body
  );
};
