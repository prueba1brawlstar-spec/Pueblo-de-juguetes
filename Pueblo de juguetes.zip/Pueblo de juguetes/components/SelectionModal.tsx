import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { X, Search, Check, Filter } from 'lucide-react';

interface SelectionModalProps {
  title: string;
  options: string[];
  selected: string;
  onSelect: (value: string) => void;
  onClose: () => void;
  allowClear?: boolean; // To allow selecting "All" (empty string)
  clearLabel?: string;
}

export const SelectionModal: React.FC<SelectionModalProps> = ({ 
  title, 
  options, 
  selected, 
  onSelect, 
  onClose,
  allowClear = false,
  clearLabel = "Todos"
}) => {
  const [mounted, setMounted] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    setMounted(true);
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = 'unset'; };
  }, []);

  if (!mounted) return null;

  const filteredOptions = options.filter(opt => 
    opt.toLowerCase().includes(search.toLowerCase())
  );

  return createPortal(
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200 font-sans">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xs border border-slate-200 overflow-hidden flex flex-col max-h-[60vh] animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 bg-slate-50 shrink-0">
          <div className="flex justify-between items-center mb-3">
             <h3 className="font-bold text-slate-700 text-sm flex items-center gap-2">
                <Filter className="w-4 h-4 text-blue-500" />
                {title}
             </h3>
             <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 hover:bg-slate-200 rounded-full transition-colors">
                 <X className="w-4 h-4" />
             </button>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <input 
              type="text" 
              autoFocus
              placeholder="Buscar..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none shadow-sm placeholder:text-slate-400"
            />
          </div>
        </div>

        {/* Options List */}
        <div className="overflow-y-auto flex-1 p-2 space-y-1 custom-scrollbar bg-white">
          {allowClear && (
             <button
                onClick={() => { onSelect(''); onClose(); }}
                className={`w-full flex items-center justify-between p-3 rounded-lg transition-colors text-left border ${
                    selected === '' 
                    ? 'bg-blue-50 border-blue-200' 
                    : 'bg-white border-transparent hover:bg-slate-50 hover:border-slate-100'
                }`}
              >
                <span className={`font-bold text-xs ${selected === '' ? 'text-blue-700' : 'text-slate-500 italic'}`}>
                    {clearLabel}
                </span>
                {selected === '' && <Check className="w-3.5 h-3.5 text-blue-600" />}
              </button>
          )}

          {filteredOptions.length === 0 ? (
            <div className="p-6 text-center text-slate-400 text-xs font-medium">
              Sin resultados.
            </div>
          ) : (
            filteredOptions.map(opt => (
              <button
                key={opt}
                onClick={() => { onSelect(opt); onClose(); }}
                className={`w-full flex items-center justify-between p-3 rounded-lg transition-colors text-left border ${
                    selected === opt 
                    ? 'bg-blue-50 border-blue-200' 
                    : 'bg-white border-transparent hover:bg-slate-50 hover:border-slate-100'
                }`}
              >
                <span className={`font-bold text-xs ${selected === opt ? 'text-blue-700' : 'text-slate-600'}`}>
                    {opt}
                </span>
                {selected === opt && <Check className="w-3.5 h-3.5 text-blue-600" />}
              </button>
            ))
          )}
        </div>
      </div>
    </div>,
    document.body
  );
};