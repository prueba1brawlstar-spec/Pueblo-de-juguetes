
import React, { useState, useEffect } from 'react';
import { Castle, Users, Clock } from 'lucide-react';

interface HeaderProps {
  count: number;
  actions?: React.ReactNode;
}

export const Header: React.FC<HeaderProps> = ({ count, actions }) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    // Update every second to keep minute synced, but display is HH:MM
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Format Date: "Jueves, 25 de Diciembre"
  const dateStr = currentTime.toLocaleDateString('es-ES', { 
    weekday: 'long', 
    day: 'numeric', 
    month: 'long' 
  });
  // Capitalize first letter
  const formattedDate = dateStr.charAt(0).toUpperCase() + dateStr.slice(1);

  // Format Time: "6:01 PM"
  const timeStr = currentTime.toLocaleTimeString('es-ES', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });

  return (
    <header className="bg-white/90 backdrop-blur-lg sticky top-0 z-20 border-b border-blue-100 shadow-sm transition-all duration-300">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
        
        {/* Left Side: Brand & Time */}
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <div className="p-2 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg shadow-blue-200 shrink-0">
            <Castle className="w-6 h-6 text-white" />
          </div>
          
          <div className="flex flex-col min-w-0">
            <h1 className="text-lg md:text-xl font-extrabold text-slate-800 tracking-tight leading-none truncate">
              Pueblo de Juguetes
            </h1>
            
            {/* Optimized Date Display: Stacked on mobile, row on desktop if space */}
            <div className="flex flex-col md:flex-row md:items-center md:gap-2 mt-0.5">
               <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wide leading-tight">
                 {formattedDate}
               </span>
               <span className="hidden md:inline text-blue-300">•</span>
               <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-blue-400 md:hidden" />
                  <span className="text-[11px] font-mono font-bold text-slate-600 bg-slate-100 px-1.5 rounded-md leading-tight">
                    {timeStr}
                  </span>
               </div>
            </div>
          </div>
        </div>

        {/* Right Side: Actions & Stats */}
        <div className="flex items-center gap-2 md:gap-4 shrink-0 pl-2">
          
          {/* Population Counter */}
          <div className="flex flex-col items-end md:items-center md:flex-row md:gap-2 bg-blue-50/50 px-2 md:px-3 py-1 md:py-1.5 rounded-lg border border-blue-100">
             <div className="flex items-center gap-1">
               <Users className="w-3.5 h-3.5 text-blue-600" />
               <span className="text-sm font-black text-blue-700">{count}</span>
             </div>
             <span className="text-[9px] font-bold text-blue-400 uppercase hidden md:inline">Habitantes</span>
          </div>

          {/* Action Button (Contextual) */}
          {actions && (
            <div className="flex items-center">
              {actions}
            </div>
          )}

        </div>
      </div>
    </header>
  );
};
