import React, { useState } from 'react';
import { Shield, ArrowLeft, BadgeAlert, ShieldCheck, Plus, User, FileWarning, Lock, Unlock } from 'lucide-react';
import { Toy, PoliceData, CrimeRecord } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';
import { NotificationModal, NotificationType } from './NotificationModal';

interface PoliceStationViewProps {
  toys: Toy[];
  police: PoliceData;
  onUpdatePolice: (police: PoliceData) => void;
  onBack: () => void;
}

const MONEY_SCALES = [
    "Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", 
    "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", 
    "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón"
];

export const PoliceStationView: React.FC<PoliceStationViewProps> = ({ toys, police, onUpdatePolice, onBack }) => {
  const [subView, setSubView] = useState<'main' | 'records' | 'arrest'>('main');
  const [selectorMode, setSelectorMode] = useState<'commissioner' | 'officer' | 'prisoner_select' | null>(null);
  const [arrestForm, setArrestForm] = useState<{ toyId: string | null, crime: string, bailAmount: string, bailScale: string, days: string }>({ toyId: null, crime: '', bailAmount: '', bailScale: 'Mil', days: '' });
  const [notification, setNotification] = useState<{show: boolean, type: NotificationType, title: string, message: string}>({show: false, type: 'info', title: '', message: ''});

  const getToyName = (id: string | null) => toys.find(t => t.id === id)?.name || 'Desconocido';
  const getToyFamily = (id: string | null) => toys.find(t => t.id === id)?.family || '';

  const handlePoliceSelect = (toyId: string) => {
      if (selectorMode === 'commissioner') {
          onUpdatePolice({ ...police, commissionerId: toyId });
          setNotification({ show: true, type: 'success', title: 'Nuevo Comisario', message: 'Se ha asignado un nuevo jefe de policía.' });
          setSelectorMode(null);
      } else if (selectorMode === 'officer') {
          if (!police.officers.includes(toyId)) onUpdatePolice({ ...police, officers: [...police.officers, toyId] });
          setSelectorMode(null);
      } else if (selectorMode === 'prisoner_select') {
          setArrestForm({ ...arrestForm, toyId });
          setSubView('arrest');
          setSelectorMode(null);
      }
  };

  const handleConfirmArrest = () => {
      if (!arrestForm.toyId || !arrestForm.crime) return;
      let bailVal = parseFloat(arrestForm.bailAmount) || 0;
      let multiplier = 1;
      if (arrestForm.bailScale === 'Mil') multiplier = 1000;
      else { const idx = MONEY_SCALES.indexOf(arrestForm.bailScale); if (idx !== -1) multiplier = Math.pow(1000, idx) * 1000000; }
      const finalBail = bailVal * multiplier;

      const newRecord: CrimeRecord = { id: crypto.randomUUID(), criminalId: arrestForm.toyId, crime: arrestForm.crime, bailAmount: finalBail, sentenceDays: parseInt(arrestForm.days) || 0, timestamp: Date.now(), active: true };
      const updatedPrisoners = police.prisoners.includes(arrestForm.toyId) ? police.prisoners : [...police.prisoners, arrestForm.toyId];
      const updatedRecords = [...(police.records || []), newRecord];

      onUpdatePolice({ ...police, prisoners: updatedPrisoners, records: updatedRecords });
      setNotification({ show: true, type: 'info', title: 'Arresto Procesado', message: 'El habitante ha sido encarcelado y se han actualizado sus antecedentes.' });
      setSubView('main');
      setArrestForm({ toyId: null, crime: '', bailAmount: '', bailScale: 'Mil', days: '' });
  };

  const handleRemoveOfficer = (id: string) => onUpdatePolice({ ...police, officers: police.officers.filter(o => o !== id) });
  const handleReleasePrisoner = (id: string) => {
      onUpdatePolice({ ...police, prisoners: police.prisoners.filter(p => p !== id) });
      setNotification({ show: true, type: 'success', title: 'Libertad Concedida', message: 'El prisionero ha sido liberado.' });
  };

  if (subView === 'arrest') {
      const criminal = toys.find(t => t.id === arrestForm.toyId);
      return (
        <FullScreenPage>
            <div className="max-w-md mx-auto min-h-screen flex flex-col justify-center p-4">
                <div className="bg-white rounded-2xl shadow-2xl p-6 border-2 border-red-100">
                    <h2 className="text-xl font-black text-red-700 uppercase tracking-wider mb-1 flex items-center gap-2"><BadgeAlert className="w-6 h-6"/> Orden de Arresto</h2>
                    <p className="text-sm text-slate-500 mb-6 font-bold">Procesando detención de: {criminal?.name}</p>
                    <div className="space-y-4">
                        <div><label className="text-[10px] font-black text-slate-400 uppercase">Causa</label><input type="text" autoFocus value={arrestForm.crime} onChange={e => setArrestForm({...arrestForm, crime: e.target.value})} placeholder="Ej. Robo de galletas" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-red-500" /></div>
                        <div><label className="text-[10px] font-black text-slate-400 uppercase">Días</label><input type="number" value={arrestForm.days} onChange={e => setArrestForm({...arrestForm, days: e.target.value})} placeholder="0" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-red-500" /></div>
                        <div><label className="text-[10px] font-black text-slate-400 uppercase">Fianza</label><div className="flex gap-2"><input type="number" value={arrestForm.bailAmount} onChange={e => setArrestForm({...arrestForm, bailAmount: e.target.value})} placeholder="Cantidad" className="w-2/3 p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-red-500" /><select value={arrestForm.bailScale} onChange={e => setArrestForm({...arrestForm, bailScale: e.target.value})} className="w-1/3 p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs text-slate-800 outline-none"><option value="Mil">Mil</option>{MONEY_SCALES.map(s => <option key={s} value={s}>{s}</option>)}</select></div></div>
                    </div>
                    <div className="flex gap-3 mt-8"><button onClick={() => setSubView('main')} className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl">Cancelar</button><button onClick={handleConfirmArrest} disabled={!arrestForm.crime} className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-lg disabled:opacity-50">Confirmar</button></div>
                </div>
            </div>
        </FullScreenPage>
      );
  }

  if (subView === 'records') {
      return (
        <FullScreenPage>
            <div className="max-w-5xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6"><button onClick={() => setSubView('main')} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button><div><h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><FileWarning className="w-6 h-6 text-slate-700" /> Archivo Criminal</h2><p className="text-sm text-slate-500">Historial de Delitos</p></div></div>
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    {police.records?.length === 0 ? <div className="p-10 text-center text-slate-400"><ShieldCheck className="w-12 h-12 mx-auto mb-2 text-green-500 opacity-50"/><p>No hay antecedentes penales registrados.</p></div> : <div className="divide-y divide-slate-100">{police.records?.slice().reverse().map(rec => (<div key={rec.id} className="p-4 flex items-start gap-4"><div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center shrink-0 border border-slate-200 text-slate-400"><User className="w-5 h-5"/></div><div className="flex-1"><div className="flex justify-between items-start"><h4 className="font-bold text-slate-800 text-sm">{getToyName(rec.criminalId)}</h4><span className="text-[10px] text-slate-400 font-mono">{new Date(rec.timestamp).toLocaleDateString()}</span></div><div className="text-red-600 text-xs font-bold uppercase tracking-wide mt-0.5">{rec.crime}</div><div className="flex gap-4 mt-2 text-xs text-slate-500"><span className="flex items-center gap-1"><Lock className="w-3 h-3"/> {rec.sentenceDays} Días</span><span className="flex items-center gap-1"><Unlock className="w-3 h-3"/> Fianza: ${rec.bailAmount.toLocaleString()}</span></div></div></div>))}</div>}
                </div>
            </div>
        </FullScreenPage>
      );
  }

  return (
    <FullScreenPage>
        <NotificationModal isOpen={notification.show} onClose={() => setNotification({ ...notification, show: false })} type={notification.type} title={notification.title} message={notification.message} />
        <div className="max-w-5xl mx-auto px-4 py-8">
            <div className="flex items-center gap-3 mb-6"><button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button><div><h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><Shield className="w-6 h-6 text-blue-800" /> Estación de Policía</h2><p className="text-sm text-slate-500">Seguridad y Justicia</p></div></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-slate-800 text-white rounded-xl p-6 shadow-xl relative overflow-hidden flex flex-col items-center text-center">
                    <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[radial-gradient(circle,rgba(59,130,246,0.5)_0%,rgba(0,0,0,0)_100%)]"></div>
                    <div className="w-20 h-20 bg-slate-700 rounded-full flex items-center justify-center mb-4 ring-4 ring-slate-600 z-10"><BadgeAlert className="w-10 h-10 text-blue-400" /></div>
                    <h3 className="font-bold text-blue-200 text-lg uppercase tracking-widest mb-1">Comisario</h3>
                    <div className="mb-6 w-full z-10"><div className="text-2xl font-extrabold text-white truncate">{getToyName(police.commissionerId)}</div><div className="text-sm text-slate-400 font-medium">{getToyFamily(police.commissionerId)}</div></div>
                    <button onClick={() => setSelectorMode('commissioner')} className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold uppercase tracking-wide transition-colors z-10">Nombrar Jefe</button>
                </div>
                <div className="md:col-span-2 space-y-4">
                    <div className="bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
                        <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center"><h3 className="font-bold text-slate-700 flex items-center gap-2"><ShieldCheck className="w-5 h-5 text-blue-600" /> Cuerpo Policial ({police.officers.length})</h3><button onClick={() => setSelectorMode('officer')} className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-blue-700 transition-colors flex items-center gap-1"><Plus className="w-3 h-3"/> Reclutar</button></div>
                        <div className="p-2 overflow-y-auto max-h-40 custom-scrollbar">{police.officers.length === 0 ? <p className="text-center text-slate-400 py-4 text-sm italic">No hay oficiales activos.</p> : police.officers.map(offId => (<div key={offId} className="flex justify-between items-center p-2 hover:bg-slate-50 rounded-lg"><div className="flex items-center gap-3"><div className="w-8 h-8 bg-blue-50 rounded-full flex items-center justify-center text-blue-600"><User className="w-4 h-4"/></div><div className="font-bold text-slate-800 text-sm">{getToyName(offId)}</div></div><button onClick={() => handleRemoveOfficer(offId)} className="text-xs text-red-400 hover:text-red-600 font-bold px-2 py-1">Despedir</button></div>))}</div>
                    </div>
                    <button onClick={() => setSubView('records')} className="w-full bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-colors border border-slate-200"><FileWarning className="w-5 h-5" /> Ver Antecedentes Penales</button>
                </div>
                <div className="md:col-span-3 bg-red-50 rounded-xl border border-red-100 shadow-sm p-6 relative overflow-hidden">
                    <div className="absolute -right-6 -top-6 text-red-100 opacity-50"><Lock className="w-32 h-32" /></div>
                    <div className="flex justify-between items-center mb-4 relative z-10"><h3 className="font-bold text-red-800 flex items-center gap-2"><Lock className="w-5 h-5" /> Cárcel Municipal ({police.prisoners.length})</h3><button onClick={() => setSelectorMode('prisoner_select')} className="bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-4 py-2 rounded-lg shadow-sm shadow-red-200">Arrestar Habitante</button></div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 relative z-10">{police.prisoners.length === 0 ? <div className="col-span-full text-center py-6 text-red-300 font-bold text-sm">Celdas vacías. ¡El pueblo es seguro!</div> : police.prisoners.map(prisId => { const activeCrime = police.records?.slice().reverse().find(r => r.criminalId === prisId && r.active); return (<div key={prisId} className="bg-white p-3 rounded-lg border-l-4 border-red-500 shadow-sm flex justify-between items-center group"><div><div className="font-bold text-slate-800 text-sm">{getToyName(prisId)}</div><div className="text-[10px] text-red-500 font-bold uppercase truncate max-w-[120px]">{activeCrime ? activeCrime.crime : 'Detenido'}</div></div><button onClick={() => handleReleasePrisoner(prisId)} className="p-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-full" title="Liberar"><Unlock className="w-4 h-4"/></button></div>); })}</div>
                </div>
            </div>
            {selectorMode && <ToySelector toys={toys} title={selectorMode === 'commissioner' ? 'Nombrar Comisario' : selectorMode === 'officer' ? 'Reclutar Oficial' : 'Seleccionar Detenido'} minAge={selectorMode === 'prisoner_select' ? undefined : 18} excludeIds={selectorMode === 'officer' ? police.officers : selectorMode === 'prisoner_select' ? police.prisoners : []} onSelect={handlePoliceSelect} onCancel={() => setSelectorMode(null)} />}
        </div>
    </FullScreenPage>
  );
};
