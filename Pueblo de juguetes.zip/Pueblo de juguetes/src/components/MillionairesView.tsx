import React from 'react';
import { Crown, ArrowLeft, Coins } from 'lucide-react';
import { Toy, Bank, Company } from '../types';
import { FullScreenPage } from './FullScreenPage';

interface MillionairesViewProps {
  toys: Toy[];
  banks: Bank[];
  companies: Company[];
  onBack: () => void;
}

const MONEY_SCALES = [
    "Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", 
    "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", 
    "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón"
];

const formatMoneyWithScale = (amount: number) => {
    if (amount >= 1000 && amount < 1000000) {
        return { amount: Math.round(amount / 1000), suffix: 'Mil' };
    }
    if (amount < 1000) return { amount: amount, suffix: '' };
    
    let temp = amount / 1000000;
    let scaleIdx = 0;
    while (temp >= 1000 && scaleIdx < MONEY_SCALES.length - 1) {
        temp /= 1000;
        scaleIdx++;
    }
    return { amount: Math.round(temp * 100) / 100, suffix: MONEY_SCALES[scaleIdx] };
};

export const MillionairesView: React.FC<MillionairesViewProps> = ({ toys, banks, companies, onBack }) => {
  const calculateWealth = (toyId: string) => {
      let totalWealth = 0;
      const toy = toys.find(t => t.id === toyId);
      if (toy?.accountBalance) totalWealth += toy.accountBalance;

      const myBanks = banks.filter(b => b.ownerId === toyId);
      myBanks.forEach(b => {
           const idx = MONEY_SCALES.indexOf(b.fundsSuffix || MONEY_SCALES[0]);
           const multiplier = Math.pow(1000, idx) * 1000000;
           const rawFunds = b.funds * multiplier;
           const ownership = (b.ownerPercentage ?? 100) / 100;
           totalWealth += (rawFunds * ownership);
      });

      const myCompanies = companies.filter(c => c.ownerId === toyId);
      myCompanies.forEach(c => {
           const idx = MONEY_SCALES.indexOf(c.capitalSuffix);
           const multiplier = Math.pow(1000, idx) * 1000000;
           totalWealth += (c.capitalAmount * multiplier);
      });

      return totalWealth;
  };

  const getMillionaires = () => {
      const wealthMap = toys.map(t => ({
          ...t,
          wealth: calculateWealth(t.id)
      }));
      return wealthMap.sort((a, b) => b.wealth - a.wealth).filter(t => t.wealth > 0).slice(0, 10);
  };

  const millionaires = getMillionaires();

  return (
    <FullScreenPage>
        <div className="max-w-xl mx-auto px-4 py-8">
            <div className="bg-white rounded-2xl shadow-xl border-4 border-yellow-300 overflow-hidden relative">
                <div className="absolute top-2 right-2 opacity-20"><Coins className="w-24 h-24 text-yellow-500" /></div>
                <div className="bg-gradient-to-br from-yellow-400 via-orange-500 to-amber-600 p-8 text-white text-center relative z-10">
                        <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner border border-white/40">
                        <Crown className="w-8 h-8 text-yellow-100 drop-shadow-md" />
                        </div>
                        <h2 className="text-3xl font-black uppercase tracking-widest drop-shadow-md">Top Forbes</h2>
                        <p className="text-yellow-100 text-sm font-bold tracking-wide mt-1">Los Magnates del Pueblo</p>
                </div>
                <div className="divide-y divide-slate-100 bg-white">
                    {millionaires.length === 0 ? (
                        <div className="p-10 text-center text-slate-400">
                            <Coins className="w-12 h-12 mx-auto mb-2 opacity-50" />
                            No hay fortunas registradas aún.
                        </div>
                    ) : (
                        millionaires.map((m, index) => {
                            const { amount, suffix } = formatMoneyWithScale(m.wealth);
                            return (
                                <div key={m.id} className={`p-4 flex items-center gap-4 transition-colors ${index < 3 ? 'bg-yellow-50/50' : 'hover:bg-slate-50'}`}>
                                    <div className={`w-10 h-10 flex items-center justify-center font-black rounded-full shadow-sm shrink-0 ${index === 0 ? 'bg-yellow-400 text-white ring-4 ring-yellow-200' : index === 1 ? 'bg-slate-300 text-white ring-4 ring-slate-100' : index === 2 ? 'bg-amber-600 text-white ring-4 ring-amber-200' : 'text-slate-400 bg-slate-100'}`}>
                                        {index + 1}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="font-bold text-slate-800 truncate">{m.name}</div>
                                        <div className="text-[10px] text-slate-400 uppercase font-bold truncate">{m.family}</div>
                                    </div>
                                    <div className="text-right shrink-0">
                                        <div className="font-extrabold text-emerald-600 text-base">COP ${amount.toLocaleString()}</div>
                                        <div className="text-[10px] font-bold text-emerald-400 uppercase">{suffix}</div>
                                    </div>
                                </div>
                            );
                        })
                    )}
                </div>
                <button onClick={onBack} className="w-full py-4 bg-slate-50 text-slate-500 font-bold hover:bg-slate-100 transition-colors border-t border-slate-100 uppercase text-xs tracking-wider">Volver a Finanzas</button>
            </div>
        </div>
    </FullScreenPage>
  );
};
