import React, { useState } from 'react';
import { Landmark } from 'lucide-react';
import { Toy, Bank } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';

interface CreateBankFormProps {
  toys: Toy[];
  banks: Bank[];
  onAddBank: (bank: Bank) => void;
  onCancel: () => void;
}

const MONEY_SCALES = ["Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón"];
const BANK_ROLES = ["Director", "Gerente", "Asesor", "Cajero", "Vigilante"];

export const CreateBankForm: React.FC<CreateBankFormProps> = ({ toys, banks, onAddBank, onCancel }) => {
  const [newBankName, setNewBankName] = useState('');
  const [newBankOwnerId, setNewBankOwnerId] = useState<string | null>(null);
  const [newBankOwnerPercent, setNewBankOwnerPercent] = useState('70');
  const [showSelector, setShowSelector] = useState(false);

  const getNextBankId = () => { const ids = banks.map(b => parseInt(b.id)).filter(n => !isNaN(n)); const max = ids.length > 0 ? Math.max(...ids) : 999; return (max + 1).toString(); };

  const handleCreate = () => {
    if (!newBankName || !newBankOwnerId) return;
    const roleSalaries = BANK_ROLES.reduce((acc, role) => ({...acc, [role]: 1000000}), {});
    const newBank: Bank = {
      id: getNextBankId(),
      name: newBankName,
      ownerId: newBankOwnerId,
      ownerPercentage: Math.min(70, Math.max(0, parseFloat(newBankOwnerPercent) || 70)),
      employees: [],
      funds: 1000,
      fundsSuffix: MONEY_SCALES[0], 
      roleSalaries,
      lastPayrollDate: Date.now()
    };
    onAddBank(newBank);
  };

  return (
    <FullScreenPage>
        <div className="max-w-md mx-auto pt-10 p-4">
            <div className="bg-white rounded-2xl shadow-xl p-6 border border-slate-200">
                <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2"><Landmark className="w-6 h-6 text-blue-600"/> Fundar Banco</h2>
                <div className="space-y-4">
                    <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Nombre</label><input type="text" value={newBankName} onChange={(e) => setNewBankName(e.target.value)} placeholder="Ej. Banco Nacional" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"/></div>
                    <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Propietario</label><button onClick={() => setShowSelector(true)} className={`w-full p-3 border rounded-xl text-left font-bold text-sm ${newBankOwnerId ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-slate-50 text-slate-400 border-slate-200'}`}>{newBankOwnerId ? toys.find(t => t.id === newBankOwnerId)?.name : 'Seleccionar Dueño'}</button></div>
                    <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Participación del Dueño (%)</label><input type="number" min="0" max="70" value={newBankOwnerPercent} onChange={(e) => setNewBankOwnerPercent(e.target.value)} placeholder="Max 70%" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"/></div>
                    <div className="flex gap-3 pt-2"><button onClick={onCancel} className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl">Cancelar</button><button onClick={handleCreate} disabled={!newBankName || !newBankOwnerId} className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg disabled:opacity-50">Crear</button></div>
                </div>
            </div>
        </div>
        {showSelector && <ToySelector toys={toys} onSelect={(id) => { setNewBankOwnerId(id); setShowSelector(false); }} onCancel={() => setShowSelector(false)} minAge={18} />}
    </FullScreenPage>
  );
};
