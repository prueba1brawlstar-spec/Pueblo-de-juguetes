import React, { useState } from 'react';
import { Factory, User, ArrowLeft, Plus, Trash2, Briefcase } from 'lucide-react';
import { Toy, Company, CompanyEmployee } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';

interface CompanyDetailViewProps {
  company: Company;
  toys: Toy[];
  onUpdateCompany: (id: string, data: Partial<Company>) => void;
  onBack: () => void;
}

const MONEY_SCALES = ["Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón"];

const formatMoneyWithScale = (amount: number) => {
    if (amount >= 1000 && amount < 1000000) return { amount: Math.round(amount / 1000), suffix: 'Mil' };
    if (amount < 1000) return { amount: amount, suffix: '' };
    let temp = amount / 1000000;
    let scaleIdx = 0;
    while (temp >= 1000 && scaleIdx < MONEY_SCALES.length - 1) { temp /= 1000; scaleIdx++; }
    return { amount: Math.round(temp * 100) / 100, suffix: MONEY_SCALES[scaleIdx] };
};

export const CompanyDetailView: React.FC<CompanyDetailViewProps> = ({ company, toys, onUpdateCompany, onBack }) => {
  const [tab, setTab] = useState<'info' | 'roles'>('info');
  const [showEmployeeSelector, setShowEmployeeSelector] = useState(false);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [newEmployeeRole, setNewEmployeeRole] = useState(company.customRoles[0]?.name || '');

  const owner = toys.find(t => t.id === company.ownerId);

  const handleHire = () => {
      if (!selectedEmployeeId) return;
      const roleDef = company.customRoles.find(r => r.name === newEmployeeRole);
      const salary = roleDef ? roleDef.baseSalary : 1000000;
      const newEmp: CompanyEmployee = { id: crypto.randomUUID(), toyId: selectedEmployeeId, role: newEmployeeRole, salary };
      onUpdateCompany(company.id, { employees: [...company.employees, newEmp] });
      setSelectedEmployeeId(null);
  };

  return (
    <FullScreenPage>
        <div className="max-w-5xl mx-auto px-4 py-8">
            <div className="flex items-center gap-3 mb-6">
                <button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
                <div><h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><Factory className="w-6 h-6 text-orange-600" />{company.name}</h2><p className="text-sm text-slate-500 font-mono">{company.description || 'Sin descripción'}</p></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-orange-900 text-white rounded-xl p-6 shadow-lg relative overflow-hidden">
                    <div className="flex items-center gap-4 relative z-10"><div className="w-16 h-16 bg-orange-800 rounded-full flex items-center justify-center border-2 border-orange-400"><User className="w-8 h-8 text-orange-100" /></div><div><div className="text-xl font-bold">{owner?.name || 'Desconocido'}</div><div className="text-orange-300 text-sm font-medium">{owner?.family}</div></div></div>
                </div>
                <div className="md:col-span-2 bg-white rounded-xl border border-orange-100 shadow-sm p-6 flex flex-col justify-center">
                    <h3 className="text-slate-500 font-bold text-xs uppercase mb-1">Capital Social</h3>
                    <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2">
                        <div className="text-3xl md:text-4xl font-mono font-bold text-orange-600">COP ${company.capitalAmount.toLocaleString()}</div>
                        <div className="text-lg md:text-xl font-bold text-orange-400">{company.capitalSuffix}</div>
                    </div>
                </div>
            </div>

            <div className="flex gap-4 mt-8 border-b border-slate-200 overflow-x-auto no-scrollbar">
                <button onClick={() => setTab('info')} className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${tab === 'info' ? 'border-orange-500 text-orange-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>Empleados ({company.employees.length})</button>
                <button onClick={() => setTab('roles')} className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${tab === 'roles' ? 'border-orange-500 text-orange-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>Roles & Salarios</button>
            </div>

            {tab === 'info' && (
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mt-6 p-6">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="font-bold text-slate-700">Personal</h3>
                        <button onClick={() => setShowEmployeeSelector(true)} className="text-xs bg-orange-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-orange-700 transition-colors flex items-center gap-1"><Plus className="w-3 h-3"/> Contratar</button>
                    </div>
                    <div className="space-y-2">
                        {company.employees.map(emp => {
                            const t = toys.find(x => x.id === emp.toyId);
                            const { amount, suffix } = formatMoneyWithScale(emp.salary);
                            return (
                                <div key={emp.id} className="flex justify-between items-center p-3 border rounded-lg bg-white">
                                    <div><div className="font-bold text-slate-800 text-sm">{t?.name || 'Unknown'}</div><div className="text-xs text-orange-600 font-bold">{emp.role}</div></div>
                                    <div className="flex items-center gap-3"><div className="text-right"><div className="font-bold text-slate-700 text-xs">${amount} {suffix}</div></div><button onClick={() => onUpdateCompany(company.id, { employees: company.employees.filter(e => e.id !== emp.id) })} className="text-red-400 hover:text-red-600"><Trash2 className="w-4 h-4"/></button></div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {showEmployeeSelector && <ToySelector toys={toys} title="Contratar Empleado" excludeIds={[company.ownerId, ...company.employees.map(e => e.toyId)]} minAge={18} onSelect={(id) => { setSelectedEmployeeId(id); setShowEmployeeSelector(false); }} onCancel={() => setShowEmployeeSelector(false)} />}
            {selectedEmployeeId && (
                <div className="fixed inset-0 z-[6000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm p-6 border border-slate-200">
                        <h3 className="text-lg font-bold text-slate-800 mb-4">Asignar Cargo</h3>
                        <select value={newEmployeeRole} onChange={(e) => setNewEmployeeRole(e.target.value)} className="w-full p-3 bg-white border border-slate-300 rounded-lg text-sm font-bold outline-none mb-4">
                            {company.customRoles.map(r => <option key={r.id} value={r.name}>{r.name}</option>)}
                        </select>
                        <div className="flex gap-3"><button onClick={() => setSelectedEmployeeId(null)} className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl">Cancelar</button><button onClick={handleHire} className="flex-1 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-lg">Contratar</button></div>
                    </div>
                </div>
            )}
        </div>
    </FullScreenPage>
  );
};
