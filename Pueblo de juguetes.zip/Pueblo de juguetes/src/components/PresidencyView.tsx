import React, { useState, useRef, useEffect } from 'react';
import { Landmark, Crown, User, Building2, Calendar, ArrowLeft } from 'lucide-react';
import { Toy, Government } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';

interface PresidencyViewProps {
  toys: Toy[];
  government: Government;
  onUpdateGov: (gov: Government) => void;
  onBack: () => void;
}

export const PresidencyView: React.FC<PresidencyViewProps> = ({ toys, government, onUpdateGov, onBack }) => {
  const [activeGovRole, setActiveGovRole] = useState<'presidentId' | 'vicePresidentId' | 'mayorId' | null>(null);
  const [tempTermYear, setTempTermYear] = useState(government.termYear || new Date().getFullYear().toString());
  const prevGov = useRef(government);
  const [flash, setFlash] = useState<{[key: string]: 'green' | 'red' | null}>({});

  useEffect(() => {
    const changes: {[key: string]: 'green' | 'red' | null} = {};
    let hasChanges = false;
    
    if (government.presidentId !== prevGov.current.presidentId) { changes.president = government.presidentId ? 'green' : 'red'; hasChanges = true; }
    if (government.vicePresidentId !== prevGov.current.vicePresidentId) { changes.vp = government.vicePresidentId ? 'green' : 'red'; hasChanges = true; }
    if (government.mayorId !== prevGov.current.mayorId) { changes.mayor = government.mayorId ? 'green' : 'red'; hasChanges = true; }

    if (hasChanges) {
        setFlash(changes);
        setTimeout(() => setFlash({}), 1000);
    }
    prevGov.current = government;
  }, [government]);

  const getToyName = (id: string | null) => toys.find(t => t.id === id)?.name || '--- Vacante ---';
  const getToyFamily = (id: string | null) => toys.find(t => t.id === id)?.family || '';
  const handleGovSelect = (toyId: string) => { if (activeGovRole) { onUpdateGov({ ...government, [activeGovRole]: toyId }); setActiveGovRole(null); } };
  const handleYearUpdate = () => { onUpdateGov({ ...government, termYear: tempTermYear }); };

  return (
    <FullScreenPage>
        <div className="max-w-5xl mx-auto px-4 py-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div className="flex items-center gap-3">
                    <button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm shrink-0"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
                    <div><h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><Landmark className="w-6 h-6 text-indigo-600" /> Despacho Presidencial</h2><p className="text-sm text-slate-500">Administración del Gobierno</p></div>
                </div>
                <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-sm flex items-center gap-2 self-start md:self-auto"><Calendar className="w-4 h-4 text-slate-400 ml-2" /><span className="text-xs font-bold text-slate-500 uppercase">Año:</span><input type="text" value={tempTermYear} onChange={(e) => setTempTermYear(e.target.value)} onBlur={handleYearUpdate} className="w-16 p-1 bg-white border border-slate-300 rounded text-sm font-bold text-center text-slate-800 outline-none focus:border-indigo-500"/></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* President Card */}
                <div className={`bg-white rounded-xl shadow-lg border-t-4 border-indigo-600 p-8 flex flex-col items-center text-center transition-all duration-300 ${flash.president === 'green' ? 'animate-flash-green' : flash.president === 'red' ? 'animate-flash-red' : ''}`}>
                    <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center mb-6 ring-4 ring-indigo-100"><Crown className="w-12 h-12 text-indigo-600" /></div>
                    <h3 className="font-bold text-indigo-900 text-xl">Presidente</h3>
                    <p className="text-xs font-bold text-indigo-300 uppercase mb-4 tracking-wider">Mandato {government.termYear}</p>
                    <div className="mb-6 w-full"><div className="text-2xl font-extrabold text-slate-800 truncate">{getToyName(government.presidentId)}</div><div className="text-base text-indigo-500 font-medium">{getToyFamily(government.presidentId)}</div></div>
                    <button onClick={() => setActiveGovRole('presidentId')} className="w-full py-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-sm font-bold transition-colors">{government.presidentId ? 'Cambiar Líder' : 'Elegir Presidente'}</button>
                </div>

                {/* VP Card */}
                <div className={`bg-white rounded-xl shadow-md border-t-4 border-slate-500 p-8 flex flex-col items-center text-center transition-all duration-300 ${flash.vp === 'green' ? 'animate-flash-green' : flash.vp === 'red' ? 'animate-flash-red' : ''}`}>
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6 ring-4 ring-slate-100"><User className="w-10 h-10 text-slate-600" /></div>
                    <h3 className="font-bold text-slate-700 text-lg">Vicepresidente</h3>
                    <div className="mt-4 mb-6 w-full"><div className="text-xl font-bold text-slate-800 truncate">{getToyName(government.vicePresidentId)}</div><div className="text-sm text-slate-400 font-medium">{getToyFamily(government.vicePresidentId)}</div></div>
                    <button onClick={() => setActiveGovRole('vicePresidentId')} className="w-full py-3 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-xl text-sm font-bold transition-colors">Asignar Vice</button>
                </div>

                {/* Mayor Card */}
                <div className={`bg-white rounded-xl shadow-md border-t-4 border-emerald-500 p-8 flex flex-col items-center text-center transition-all duration-300 ${flash.mayor === 'green' ? 'animate-flash-green' : flash.mayor === 'red' ? 'animate-flash-red' : ''}`}>
                    <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mb-6 ring-4 ring-emerald-100"><Building2 className="w-10 h-10 text-emerald-600" /></div>
                    <h3 className="font-bold text-emerald-800 text-lg">Alcalde</h3>
                    <div className="mt-4 mb-6 w-full"><div className="text-xl font-bold text-slate-800 truncate">{getToyName(government.mayorId)}</div><div className="text-sm text-emerald-500 font-medium">{getToyFamily(government.mayorId)}</div></div>
                    <button onClick={() => setActiveGovRole('mayorId')} className="w-full py-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl text-sm font-bold transition-colors">Asignar Alcalde</button>
                </div>
            </div>
            {activeGovRole && <ToySelector toys={toys} title={`Seleccionar ${activeGovRole === 'mayorId' ? 'Alcalde' : 'Mandatario'}`} onSelect={handleGovSelect} onCancel={() => setActiveGovRole(null)} minAge={18} />}
        </div>
    </FullScreenPage>
  );
};
