import React, { useState } from 'react';
import { Gavel, ScrollText, ArrowLeft, BookOpen, Crown } from 'lucide-react';
import { Toy, Government, Law } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';
import { NotificationModal, NotificationType } from './NotificationModal';

interface LawsViewProps {
  toys: Toy[];
  laws: Law[];
  government: Government;
  onAddLaw: (law: Law) => void;
  onBack: () => void;
}

export const LawsView: React.FC<LawsViewProps> = ({ toys, laws, government, onAddLaw, onBack }) => {
  const [subView, setSubView] = useState<'create' | 'list'>('create');
  const [newLawTitle, setNewLawTitle] = useState('');
  const [newLawDesc, setNewLawDesc] = useState('');
  const [newLawCreator, setNewLawCreator] = useState<string | null>(null);
  const [showLawCreatorSelector, setShowLawCreatorSelector] = useState(false);
  const [notification, setNotification] = useState<{show: boolean, type: NotificationType, title: string, message: string}>({show: false, type: 'info', title: '', message: ''});

  const getToyName = (id: string | null) => toys.find(t => t.id === id)?.name || 'Desconocido';
  const getOfficialRole = (id: string) => { if (id === government.presidentId) return 'Presidente'; if (id === government.vicePresidentId) return 'Vicepresidente'; if (id === government.mayorId) return 'Alcalde'; return 'Funcionario'; };
  const getGovernmentOfficials = () => toys.filter(t => [government.presidentId, government.vicePresidentId, government.mayorId].includes(t.id));

  const handleCreateLaw = () => {
     if (!newLawTitle || !newLawDesc || !newLawCreator) return;
     onAddLaw({ id: crypto.randomUUID(), title: newLawTitle, description: newLawDesc, creatorId: newLawCreator, createdAt: Date.now() });
     setNewLawTitle(''); setNewLawDesc(''); setNewLawCreator(null);
     setNotification({ show: true, type: 'success', title: 'Ley Promulgada', message: `"${newLawTitle}" ha sido añadida al libro oficial de leyes.` });
  };

  const handleShowCreatorSelector = () => {
      if (getGovernmentOfficials().length > 0) setShowLawCreatorSelector(true);
      else setNotification({ show: true, type: 'error', title: 'Gobierno Ausente', message: '¡No hay gobierno formado! Asigna un mandatario primero.' });
  };

  if (subView === 'list') {
      return (
        <FullScreenPage>
            <div className="max-w-5xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6"><button onClick={() => setSubView('create')} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button><div><h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><BookOpen className="w-6 h-6 text-amber-600" /> Leyes Vigentes</h2><p className="text-sm text-slate-500">Constitución Oficial</p></div></div>
                <div className="grid grid-cols-1 gap-4">{laws.length === 0 ? <div className="text-center py-20 bg-white rounded-xl border border-dashed border-slate-300"><ScrollText className="w-16 h-16 mx-auto text-slate-300 mb-4" /><h4 className="text-xl font-bold text-slate-400">Sin Leyes Vigentes</h4></div> : laws.slice().reverse().map(law => (<div key={law.id} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden"><div className="absolute top-0 left-0 w-1.5 h-full bg-amber-400"></div><div className="flex justify-between items-start mb-3"><h4 className="font-serif text-2xl text-slate-800 font-bold">{law.title}</h4><Gavel className="w-5 h-5 text-amber-200" /></div><p className="text-slate-600 text-lg font-light leading-relaxed italic border-l-2 border-slate-100 pl-4 mb-4 font-serif">"{law.description}"</p><div className="flex items-center justify-between text-xs pt-3 border-t border-slate-50"><div className="flex items-center gap-2 text-slate-500"><Crown className="w-4 h-4 text-amber-500" /><span className="font-bold">{getToyName(law.creatorId)}</span><span className="bg-slate-100 px-2 py-0.5 rounded text-[10px] uppercase font-bold text-slate-400">{getOfficialRole(law.creatorId)}</span></div><span className="text-slate-400 font-mono">{new Date(law.createdAt).toLocaleDateString()}</span></div></div>))}</div>
            </div>
        </FullScreenPage>
      );
  }

  return (
    <FullScreenPage>
        <NotificationModal isOpen={notification.show} onClose={() => setNotification({ ...notification, show: false })} type={notification.type} title={notification.title} message={notification.message} />
        <div className="max-w-5xl mx-auto px-4 py-8">
            <div className="flex items-center gap-3 mb-6"><button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button><div><h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><Gavel className="w-6 h-6 text-amber-600" /> Promulgar Leyes</h2><p className="text-sm text-slate-500">Poder Legislativo</p></div></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <div className="bg-white rounded-2xl p-8 border border-slate-100 shadow-xl">
                        <h3 className="font-light text-2xl text-slate-800 mb-6 flex items-center gap-2 border-b border-slate-100 pb-4"><ScrollText className="w-6 h-6 text-amber-500" /> Nueva Legislación</h3>
                        <div className="space-y-6">
                            <div><label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-2">Título Oficial</label><input type="text" placeholder="Ej. Ley de Comercio Justo" value={newLawTitle} onChange={(e) => setNewLawTitle(e.target.value)} className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl text-lg font-light text-slate-800 placeholder:text-slate-300 focus:ring-0 focus:border-amber-400 outline-none transition-colors font-serif"/></div>
                            <div><label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-2">Decreto</label><textarea placeholder="Escriba aquí el contenido de la ley..." rows={6} value={newLawDesc} onChange={(e) => setNewLawDesc(e.target.value)} className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl text-lg font-light text-slate-800 placeholder:text-slate-300 focus:ring-0 focus:border-amber-400 outline-none resize-none transition-colors font-serif"/></div>
                            <div><label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-2">Firmado Por</label><button onClick={handleShowCreatorSelector} className={`w-full p-4 text-base font-medium rounded-xl border text-left flex items-center justify-between transition-all ${newLawCreator ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-white border-slate-200 text-slate-400 hover:border-amber-300'}`}>{newLawCreator ? getToyName(newLawCreator) : 'Seleccionar Autoridad'}<Crown className={`w-5 h-5 ${newLawCreator ? 'text-amber-500' : 'text-slate-300'}`} /></button></div>
                            <button onClick={handleCreateLaw} disabled={!newLawTitle || !newLawDesc || !newLawCreator} className="w-full py-4 bg-amber-600 hover:bg-amber-700 text-white font-medium rounded-xl text-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg active:scale-95 mt-4">Promulgar y Publicar</button>
                        </div>
                    </div>
                </div>
                <div className="lg:col-span-1"><button onClick={() => setSubView('list')} className="w-full h-full min-h-[200px] bg-amber-50 rounded-2xl border-2 border-dashed border-amber-200 hover:border-amber-400 hover:bg-amber-100 transition-all group flex flex-col items-center justify-center text-center p-6 cursor-pointer"><BookOpen className="w-16 h-16 text-amber-300 group-hover:text-amber-500 mb-4 transition-colors" /><h3 className="text-xl font-bold text-amber-800 group-hover:text-amber-900">Ver Libro de Leyes</h3><p className="text-sm text-amber-600 mt-2 font-medium">Consultar las {laws.length} leyes vigentes del pueblo.</p></button></div>
            </div>
            {showLawCreatorSelector && <ToySelector toys={getGovernmentOfficials()} title="Seleccionar Autoridad (Solo Gobierno)" onSelect={(id) => { setNewLawCreator(id); setShowLawCreatorSelector(false); }} onCancel={() => setShowLawCreatorSelector(false)} />}
        </div>
    </FullScreenPage>
  );
};
