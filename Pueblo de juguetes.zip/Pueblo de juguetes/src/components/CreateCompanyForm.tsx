import React, { useState } from 'react';
import { Factory, ChevronDown, Check, X } from 'lucide-react';
import { Toy, Company } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';

interface CreateCompanyFormProps {
  toys: Toy[];
  onAddCompany: (company: Company) => void;
  onCancel: () => void;
}

const MONEY_SCALES = ["Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón"];

export const CreateCompanyForm: React.FC<CreateCompanyFormProps> = ({ toys, onAddCompany, onCancel }) => {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [scale, setScale] = useState(MONEY_SCALES[0]);
  const [ownerId, setOwnerId] = useState<string | null>(null);
  const [desc, setDesc] = useState('');
  const [showSelector, setShowSelector] = useState(false);
  const [showScaleSelector, setShowScaleSelector] = useState(false);

  const handleCreate = () => {
      if (!name || !amount || !ownerId) return;
      onAddCompany({
          id: crypto.randomUUID(),
          name,
          capitalAmount: parseFloat(amount),
          capitalSuffix: scale,
          description: desc,
          ownerId,
          createdAt: Date.now(),
          employees: [],
          customRoles: []
      });
  };

  return (
    <FullScreenPage>
        {showScaleSelector && (
            <div className="fixed inset-0 z-[6000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
                <div className="bg-white rounded-xl w-full max-w-[85vw] overflow-hidden flex flex-col max-h-[60vh]">
                    <div className="p-4 border-b flex justify-between"><h3 className="font-bold">Escala</h3><button onClick={() => setShowScaleSelector(false)}><X/></button></div>
                    <div className="overflow-y-auto p-2">{MONEY_SCALES.map(s => <button key={s} onClick={() => { setScale(s); setShowScaleSelector(false); }} className="w-full text-left p-3 hover:bg-slate-50 font-bold">{s}</button>)}</div>
                </div>
            </div>
        )}
        <div className="max-w-md mx-auto pt-10 p-4">
            <div className="bg-white rounded-2xl shadow-xl p-6 border border-slate-200">
                <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2"><Factory className="w-6 h-6 text-orange-600"/> Crear Empresa</h2>
                <div className="space-y-4">
                    <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Nombre</label><input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej. Juguetes SA" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-orange-500"/></div>
                    <div>
                        <label className="text-xs font-bold text-slate-500 uppercase block mb-1">Capital Inicial</label>
                        <div className="flex gap-2">
                            <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="flex-1 p-3 bg-slate-50 border rounded-xl font-bold"/>
                            <button onClick={() => setShowScaleSelector(true)} className="flex-1 p-3 bg-slate-50 border rounded-xl font-bold text-left flex justify-between items-center"><span>{scale}</span><ChevronDown className="w-4 h-4"/></button>
                        </div>
                    </div>
                    <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Dueño</label><button onClick={() => setShowSelector(true)} className={`w-full p-3 border rounded-xl text-left font-bold text-sm ${ownerId ? 'bg-orange-50 text-orange-700 border-orange-200' : 'bg-slate-50 text-slate-400 border-slate-200'}`}>{ownerId ? toys.find(t => t.id === ownerId)?.name : 'Seleccionar Dueño'}</button></div>
                    <div><label className="text-xs font-bold text-slate-500 uppercase block mb-1">Descripción</label><input type="text" value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="¿Qué hace la empresa?" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-orange-500"/></div>
                    <div className="flex gap-3 pt-2"><button onClick={onCancel} className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl">Cancelar</button><button onClick={handleCreate} disabled={!name || !amount || !ownerId} className="flex-1 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-lg disabled:opacity-50">Registrar</button></div>
                </div>
            </div>
        </div>
        {showSelector && <ToySelector toys={toys} onSelect={(id) => { setOwnerId(id); setShowSelector(false); }} onCancel={() => setShowSelector(false)} minAge={18} />}
    </FullScreenPage>
  );
};
