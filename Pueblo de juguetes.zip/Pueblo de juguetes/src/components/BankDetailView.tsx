import React, { useState } from 'react';
import { Landmark, User, Pencil, Save, X, Briefcase, Plus, Settings2, Trash2, ArrowLeft, PieChart } from 'lucide-react';
import { Toy, Bank, BankEmployee } from '../types';
import { FullScreenPage } from './FullScreenPage';
import { ToySelector } from './ToySelector';

interface BankDetailViewProps {
  bank: Bank;
  toys: Toy[];
  onUpdateBank: (id: string, data: Partial<Bank>) => void;
  onUpdateToy: (id: string, data: Partial<Toy>) => void;
  onBack: () => void;
}

const MONEY_SCALES = ["Millón", "Billón", "Trillón", "Cuatrillón", "Quintillón", "Sextillón", "Septillón", "Octillón", "Nonillón", "Decillón", "Undecillón", "Duodecillón", "Tredecillón", "Cuatrodecillón", "Quindecillón", "Sexdecillón", "Septendecillón", "Octodecillón", "Novendecillón", "Vigintillón"];
const BANK_ROLES = ["Director", "Gerente", "Asesor", "Cajero", "Vigilante"];

const formatMoneyWithScale = (amount: number) => {
    if (amount >= 1000 && amount < 1000000) return { amount: Math.round(amount / 1000), suffix: 'Mil' };
    if (amount < 1000) return { amount: amount, suffix: '' };
    let temp = amount / 1000000;
    let scaleIdx = 0;
    while (temp >= 1000 && scaleIdx < MONEY_SCALES.length - 1) { temp /= 1000; scaleIdx++; }
    return { amount: Math.round(temp * 100) / 100, suffix: MONEY_SCALES[scaleIdx] };
};

export const BankDetailView: React.FC<BankDetailViewProps> = ({ bank, toys, onUpdateBank, onUpdateToy, onBack }) => {
  const [tab, setTab] = useState<'info' | 'clients' | 'settings'>('info');
  const [isEditingFunds, setIsEditingFunds] = useState(false);
  const [editFundsAmount, setEditFundsAmount] = useState('');
  const [editFundsScale, setEditFundsScale] = useState('');
  const [editOwnerPercent, setEditOwnerPercent] = useState('');
  
  const [showEmployeeSelector, setShowEmployeeSelector] = useState(false);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [newEmployeeRole, setNewEmployeeRole] = useState(BANK_ROLES[3]);

  const owner = toys.find(t => t.id === bank.ownerId);
  const clients = toys.filter(t => t.bankAccountId === bank.id);

  const handleUpdateFunds = () => {
      const amount = parseFloat(editFundsAmount);
      const percent = parseFloat(editOwnerPercent);
      if (isNaN(amount)) return;
      onUpdateBank(bank.id, { 
          funds: amount, 
          fundsSuffix: editFundsScale, 
          ownerPercentage: isNaN(percent) ? 70 : Math.min(70, Math.max(0, percent)) 
      });
      setIsEditingFunds(false);
  };

  const handleHire = () => {
      if (!selectedEmployeeId) return;
      const salary = bank.roleSalaries[newEmployeeRole] || 1000000;
      const newEmp: BankEmployee = { id: crypto.randomUUID(), toyId: selectedEmployeeId, role: newEmployeeRole, salary };
      
      const toy = toys.find(t => t.id === selectedEmployeeId);
      if (toy && toy.bankAccountId !== bank.id) { onUpdateToy(toy.id, { bankAccountId: bank.id, accountBalance: 0 }); }
      
      onUpdateBank(bank.id, { employees: [...bank.employees, newEmp] });
      setSelectedEmployeeId(null);
  };

  return (
    <FullScreenPage>
      <div className="max-w-5xl mx-auto px-4 py-8">
         {/* Header */}
         <div className="flex items-center gap-3 mb-6">
            <button onClick={onBack} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
            <div><h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><Landmark className="w-6 h-6 text-emerald-600" />{bank.name}</h2><p className="text-sm text-slate-500 font-mono">ID: {bank.id}</p></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-emerald-900 text-white rounded-xl p-6 shadow-lg relative overflow-hidden">
                <div className="flex items-center gap-4 relative z-10"><div className="w-16 h-16 bg-emerald-800 rounded-full flex items-center justify-center border-2 border-emerald-400"><User className="w-8 h-8 text-emerald-100" /></div><div><div className="text-xl font-bold">{owner?.name || 'Desconocido'}</div><div className="text-emerald-300 text-sm font-medium">{owner?.family}</div></div></div>
            </div>

            <div className="md:col-span-2 bg-white rounded-xl border border-emerald-100 shadow-sm p-6 flex flex-col justify-center relative">
                <div className="flex items-center justify-between mb-2">
                    <h3 className="text-slate-500 font-bold text-xs uppercase">Fondos Disponibles</h3>
                    {!isEditingFunds ? (
                        <button onClick={() => { setEditFundsAmount(bank.funds.toString()); setEditFundsScale(bank.fundsSuffix || MONEY_SCALES[0]); setEditOwnerPercent(bank.ownerPercentage?.toString() || '70'); setIsEditingFunds(true); }} className="text-slate-300 hover:text-emerald-600"><Pencil className="w-4 h-4" /></button>
                    ) : (
                        <div className="flex gap-2">
                            <button onClick={() => setIsEditingFunds(false)} className="text-red-400 hover:text-red-600"><X className="w-4 h-4" /></button>
                            <button onClick={handleUpdateFunds} className="text-emerald-500 hover:text-emerald-700"><Save className="w-4 h-4" /></button>
                        </div>
                    )}
                </div>
                {isEditingFunds ? (
                    <div className="space-y-3">
                        <div className="flex gap-2">
                            <input type="number" value={editFundsAmount} onChange={e => setEditFundsAmount(e.target.value)} className="w-1/2 p-2 border rounded font-bold"/>
                            <select value={editFundsScale} onChange={e => setEditFundsScale(e.target.value)} className="w-1/2 p-2 border rounded font-bold"><option value="Mil">Mil</option>{MONEY_SCALES.map(s => <option key={s} value={s}>{s}</option>)}</select>
                        </div>
                        <div className="flex items-center gap-2"><span className="text-xs font-bold text-slate-500">Dueño (%):</span><input type="number" min="0" max="70" value={editOwnerPercent} onChange={(e) => setEditOwnerPercent(e.target.value)} className="w-20 p-1 border rounded font-bold"/></div>
                    </div>
                ) : (
                    <div>
                         <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2">
                            <div className="text-3xl md:text-4xl font-mono font-bold text-emerald-600">COP ${bank.funds.toLocaleString()}</div>
                            <div className="text-lg md:text-xl font-bold text-emerald-400">{bank.fundsSuffix}</div>
                         </div>
                         <div className="text-xs text-slate-400 mt-2 font-medium flex items-center gap-1"><PieChart className="w-3 h-3"/> {bank.ownerPercentage ?? 70}% pertenece al dueño</div>
                    </div>
                )}
            </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mt-8 border-b border-slate-200 overflow-x-auto no-scrollbar">
             <button onClick={() => setTab('info')} className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${tab === 'info' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>Personal</button>
             <button onClick={() => setTab('settings')} className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${tab === 'settings' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>Configurar Cargos</button>
             <button onClick={() => setTab('clients')} className={`pb-3 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${tab === 'clients' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>Clientes ({clients.length})</button>
        </div>

        {/* Content */}
        {tab === 'info' && (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mt-6 p-6">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-700">Nómina del Banco</h3>
                    <button onClick={() => setShowEmployeeSelector(true)} className="text-xs bg-emerald-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-emerald-700 transition-colors flex items-center gap-1"><Plus className="w-3 h-3"/> Contratar</button>
                </div>
                <div className="space-y-2">
                    {bank.employees.map(emp => {
                        const t = toys.find(x => x.id === emp.toyId);
                        const { amount, suffix } = formatMoneyWithScale(emp.salary);
                        return (
                            <div key={emp.id} className="flex justify-between items-center p-3 border rounded-lg bg-white">
                                <div><div className="font-bold text-slate-800 text-sm">{t?.name || 'Desconocido'}</div><div className="text-xs text-emerald-600 font-bold">{emp.role}</div></div>
                                <div className="flex items-center gap-3"><div className="text-right"><div className="font-bold text-slate-700 text-xs">${amount} {suffix}</div></div><button onClick={() => onUpdateBank(bank.id, { employees: bank.employees.filter(e => e.id !== emp.id) })} className="text-red-400 hover:text-red-600"><Trash2 className="w-4 h-4"/></button></div>
                            </div>
                        );
                    })}
                </div>
            </div>
        )}

        {/* Modals */}
        {showEmployeeSelector && (
            <ToySelector toys={toys} title="Contratar Personal" excludeIds={[bank.ownerId, ...bank.employees.map(e => e.toyId)]} minAge={18} onSelect={(id) => { setSelectedEmployeeId(id); setShowEmployeeSelector(false); }} onCancel={() => setShowEmployeeSelector(false)} />
        )}
        {selectedEmployeeId && (
            <div className="fixed inset-0 z-[6000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
                <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm p-6 border border-slate-200">
                    <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2"><Briefcase className="w-5 h-5 text-emerald-600"/> Asignar Rol</h3>
                    <select value={newEmployeeRole} onChange={(e) => setNewEmployeeRole(e.target.value)} className="w-full p-3 bg-white border border-slate-300 rounded-lg text-sm font-bold mb-4">{BANK_ROLES.map(r => <option key={r} value={r}>{r}</option>)}</select>
                    <div className="flex gap-3"><button onClick={() => setSelectedEmployeeId(null)} className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-xl">Cancelar</button><button onClick={handleHire} className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl">Contratar</button></div>
                </div>
            </div>
        )}
      </div>
    </FullScreenPage>
  );
};
