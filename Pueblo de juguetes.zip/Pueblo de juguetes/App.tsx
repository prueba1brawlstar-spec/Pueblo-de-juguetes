
import React, { useState, useEffect, useLayoutEffect, useRef } from 'react';
import { db, auth, googleProvider } from './firebase';
import { signInWithPopup } from 'firebase/auth';
import { collection, addDoc, onSnapshot, doc, updateDoc, query, where, arrayUnion, arrayRemove, setDoc, getDoc } from 'firebase/firestore';
import { Header } from './components/Header';
import { ToyForm } from './components/ToyForm';
import { ToyList } from './components/ToyList';
import { FamilyGrid } from './components/FamilyGrid';
import { EconomyDashboard } from './components/EconomyDashboard';
import { TownCenter } from './components/TownCenter';
import { MembersModal } from './components/MembersModal'; 
import { NotificationModal, NotificationType } from './components/NotificationModal';
import { BirthdayModal } from './components/BirthdayModal';
import { SettingsModal } from './components/SettingsModal'; 
import { SocialHub } from './components/SocialHub';
import { FullScreenPage } from './components/FullScreenPage'; 
import { SelectionModal } from './components/SelectionModal'; 
import { ConfirmationModal } from './components/ConfirmationModal';
import { Toy, TownData, HistoryLog, TownMember, JoinRequest, Company, Bank, PoliceData, SocialProfile, Relation, RelationType, Gender, ToyType, College } from './types';
import { ArrowLeft, Plus, BarChart3, Search, AlertTriangle, ArrowUpDown, ArrowDownWideNarrow, ArrowUpNarrowWide, Castle, CheckCircle2, Clock, ShieldCheck, XCircle, History, Loader2, RefreshCw, LogOut, ChevronRight, MapPin, Lock, Unlock, UserPlus, UserCheck, UserX, Users, Crown, Home, Mail, Settings, LogIn, Hash, Filter, Calendar, PartyPopper, ChevronDown } from 'lucide-react';

// --- RELATIONSHIP LOGIC HELPERS ---

const getGenderedRole = (role: string, gender: Gender): RelationType => {
    const map: Record<string, { male: RelationType, female: RelationType }> = {
        'Padre': { male: 'Padre', female: 'Madre' },
        'Madre': { male: 'Padre', female: 'Madre' },
        'Hijo': { male: 'Hijo', female: 'Hija' },
        'Hija': { male: 'Hijo', female: 'Hija' },
        'Hermano': { male: 'Hermano', female: 'Hermana' },
        'Hermana': { male: 'Hermano', female: 'Hermana' },
        'Abuelo': { male: 'Abuelo', female: 'Abuela' },
        'Abuela': { male: 'Abuelo', female: 'Abuela' },
        'Nieto': { male: 'Nieto', female: 'Nieta' },
        'Nieta': { male: 'Nieto', female: 'Nieta' },
        'Esposo': { male: 'Esposo', female: 'Esposa' },
        'Esposa': { male: 'Esposo', female: 'Esposa' },
        'Tío': { male: 'Tío', female: 'Tía' },
        'Tía': { male: 'Tío', female: 'Tía' },
        'Sobrino': { male: 'Sobrino', female: 'Sobrina' },
        'Sobrina': { male: 'Sobrino', female: 'Sobrina' },
        'Suegro': { male: 'Suegro', female: 'Suegra' },
        'Suegra': { male: 'Suegro', female: 'Suegra' },
        'Yerno': { male: 'Yerno', female: 'Nuera' },
        'Nuera': { male: 'Yerno', female: 'Nuera' },
        'Cuñado': { male: 'Cuñado', female: 'Cuñada' },
        'Cuñada': { male: 'Cuñado', female: 'Cuñada' },
        'Pareja': { male: 'Pareja', female: 'Pareja' },
        'Bisabuelo': { male: 'Bisabuelo', female: 'Bisabuela' },
        'Bisabuela': { male: 'Bisabuelo', female: 'Bisabuela' },
        'Bisnieto': { male: 'Bisnieto', female: 'Bisnieta' },
        'Bisnieta': { male: 'Bisnieto', female: 'Bisnieta' },
        'Primo': { male: 'Primo', female: 'Prima' },
        'Prima': { male: 'Primo', female: 'Prima' },
    };

    for (const key in map) {
        if (key === role || map[key].male === role || map[key].female === role) {
            return gender === 'male' ? map[key].male : map[key].female;
        }
    }
    return 'Pareja'; 
};

// Returns what TARGET calls ME, given I call TARGET 'role'
const getReciprocalType = (myRoleToTarget: RelationType, myGender: Gender, targetGender: Gender): RelationType => {
    // Normalize role first
    const role = getGenderedRole(myRoleToTarget, targetGender); 

    switch (role) {
        case 'Padre': case 'Madre': return myGender === 'male' ? 'Hijo' : 'Hija';
        case 'Hijo': case 'Hija': return myGender === 'male' ? 'Padre' : 'Madre';
        case 'Hermano': case 'Hermana': return myGender === 'male' ? 'Hermano' : 'Hermana';
        case 'Esposo': case 'Esposa': return myGender === 'male' ? 'Esposo' : 'Esposa';
        case 'Pareja': return 'Pareja';
        case 'Abuelo': case 'Abuela': return myGender === 'male' ? 'Nieto' : 'Nieta';
        case 'Nieto': case 'Nieta': return myGender === 'male' ? 'Abuelo' : 'Abuela';
        case 'Tío': case 'Tía': return myGender === 'male' ? 'Sobrino' : 'Sobrina';
        case 'Sobrino': case 'Sobrina': return myGender === 'male' ? 'Tío' : 'Tía';
        case 'Suegro': case 'Suegra': return myGender === 'male' ? 'Yerno' : 'Nuera';
        case 'Yerno': case 'Nuera': return myGender === 'male' ? 'Suegro' : 'Suegra';
        case 'Cuñado': case 'Cuñada': return myGender === 'male' ? 'Cuñado' : 'Cuñada';
        case 'Bisabuelo': case 'Bisabuela': return myGender === 'male' ? 'Bisnieto' : 'Bisnieta';
        case 'Bisnieto': case 'Bisnieta': return myGender === 'male' ? 'Bisabuelo' : 'Bisabuela';
        case 'Primo': case 'Prima': return myGender === 'male' ? 'Primo' : 'Prima';
        default: return 'Pareja';
    }
};

const MONTHS = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

function App() {
  const [myUserId, setMyUserId] = useState<string>('');
  const [myUserName, setMyUserName] = useState<string>('');
  const [linkedEmail, setLinkedEmail] = useState<string | null>(null);

  const [currentTownId, setCurrentTownId] = useState<string | null>(localStorage.getItem('current_town_id'));
  const [viewMode, setViewMode] = useState<'landing' | 'joining_name' | 'joining_wait' | 'pending' | 'approved' | 'rejected' | 'admin'>('landing');
  const [townData, setTownData] = useState<TownData | null>(null);
  const [isLoading, setIsLoading] = useState(!!localStorage.getItem('current_town_id'));
  const [publicTowns, setPublicTowns] = useState<(TownData & { id: string })[]>([]);
  
  const [pendingAction, setPendingAction] = useState<{ type: 'create' | 'join', townId?: string, townName?: string } | null>(null);
  const [inputName, setInputName] = useState(''); 
  const [isCreationAllowed, setIsCreationAllowed] = useState(true);
  const [requestName, setRequestName] = useState('Pueblo Juguetes');
  const [pendingRequests, setPendingRequests] = useState<{id: string, data: TownData}[]>([]);

  // View Routing
  const [appView, setAppView] = useState<'home' | 'stats' | 'families' | 'family_detail' | 'social'>('home'); 
  const [selectedFamily, setSelectedFamily] = useState<string | null>(null);
  const [isCreatingFamily, setIsCreatingFamily] = useState(false);
  const [isCreatingSubFamily, setIsCreatingSubFamily] = useState(false);
  const [targetSubFamily, setTargetSubFamily] = useState<string | null>(null);

  const [isAddingMember, setIsAddingMember] = useState(false);
  const [editingToy, setEditingToy] = useState<Toy | null>(null);
  
  // New: Confirmation Modal State
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  
  const [showMembers, setShowMembers] = useState(false); 
  const [showSettingsModal, setShowSettingsModal] = useState(false); 
  const [showJoinRequests, setShowJoinRequests] = useState(false);

  // Stats Filters
  const [statsSearch, setStatsSearch] = useState('');
  const [statsSort, setStatsSort] = useState<'az' | 'ageDesc' | 'ageAsc'>('az');
  const [statsMonth, setStatsMonth] = useState<string>('');
  const [statsType, setStatsType] = useState<ToyType | ''>('');
  const [showMonthSelector, setShowMonthSelector] = useState(false);
  const [showTypeSelector, setShowTypeSelector] = useState(false);

  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showAuthInvite, setShowAuthInvite] = useState(false);

  // Global Viewport Management
  useEffect(() => {
    const handleResize = () => {
      // Calculate real visual viewport height
      const height = window.visualViewport ? window.visualViewport.height : window.innerHeight;
      // Set CSS variable for use in all components
      document.documentElement.style.setProperty('--viewport-height', `${height}px`);
    };

    // Initial set
    handleResize();

    // Listeners
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', handleResize);
    }
    window.addEventListener('resize', handleResize);

    return () => {
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', handleResize);
      }
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // --- STRICT SCROLL PERSISTENCE ---
  const mainContainerRef = useRef<HTMLDivElement>(null);
  const scrollPositions = useRef<Record<string, number>>({});

  // Initialize Scroll Restoration to Manual to prevent browser interference
  useEffect(() => {
      if ('scrollRestoration' in window.history) {
          window.history.scrollRestoration = 'manual';
      }
  }, []);

  const handleSetAppView = (newView: typeof appView) => {
      if (appView !== newView) {
          // Save current scroll position before switching
          if (mainContainerRef.current) {
              scrollPositions.current[appView] = mainContainerRef.current.scrollTop;
          }
      }
      setAppView(newView);
  };

  useLayoutEffect(() => {
      // Restore scroll position after view renders
      if (mainContainerRef.current) {
          const savedPosition = scrollPositions.current[appView] || 0;
          mainContainerRef.current.scrollTop = savedPosition;
      }
  }, [appView]);

  // --- SYSTEM BACK BUTTON HANDLING ---
  const navigateTo = (view: typeof appView, payload: any = {}) => {
      const state = { view, ...payload };
      window.history.pushState(state, '', '');
      if (view === 'family_detail' && payload.family) {
          setSelectedFamily(payload.family);
      }
      handleSetAppView(view);
  };

  useEffect(() => {
      const handlePopState = (event: PopStateEvent) => {
          const state = event.state;
          
          if (isAddingMember || editingToy || isCreatingFamily || showSettingsModal || showMembers) {
              setIsAddingMember(false);
              setEditingToy(null);
              setIsCreatingFamily(false);
              setShowSettingsModal(false);
              setShowMembers(false);
              return; 
          }

          if (!state || !state.view || state.view === 'home') {
              handleSetAppView('home');
              setSelectedFamily(null); // Explicitly clear selected family
          } else if (state.view === 'families') {
              handleSetAppView('families');
              setSelectedFamily(null); // Explicitly clear selected family when going back to grid
          } else if (state.view === 'stats') {
              handleSetAppView('stats');
          } else if (state.view === 'social') {
              handleSetAppView('social');
          } else if (state.view === 'family_detail' && state.family) {
              setSelectedFamily(state.family);
              handleSetAppView('family_detail');
          }
      };

      window.addEventListener('popstate', handlePopState);
      return () => window.removeEventListener('popstate', handlePopState);
  }, [isAddingMember, editingToy, isCreatingFamily, showSettingsModal, showMembers]);

  const navToStats = () => navigateTo('stats');
  const navToFamilies = () => navigateTo('families');
  const navToSocial = () => navigateTo('social');
  const navToFamilyDetail = (family: string) => navigateTo('family_detail', { family });
  const navGoHome = () => {
      if (window.history.length > 1) {
          window.history.back();
      } else {
          handleSetAppView('home');
      }
  };

  const [notification, setNotification] = useState<{
    show: boolean;
    type: NotificationType;
    title: string;
    message: string;
    copyText?: string;
  }>({ show: false, type: 'info', title: '', message: '' });

  const [celebratingToys, setCelebratingToys] = useState<{id: string, name: string, newAge: number}[]>([]);

  const showNotification = (type: NotificationType, title: string, message: string, copyText?: string) => {
    setNotification({ show: true, type, title, message, copyText });
  };

  useEffect(() => {
    let storedId = localStorage.getItem('user_device_id');
    if (!storedId) {
        storedId = crypto.randomUUID();
        localStorage.setItem('user_device_id', storedId);
    }
    setMyUserId(storedId);
    checkAuthStatus(storedId);

    const storedName = localStorage.getItem('user_display_name');
    if (storedName) {
        setMyUserName(storedName);
        setInputName(storedName); 
    }
  }, []);

  const checkAuthStatus = async (userId: string) => {
      const q = query(collection(db, "user_mappings"), where("internalId", "==", userId));
      try {
          const unsub = onSnapshot(q, (snap) => {
              if (!snap.empty) {
                  setLinkedEmail(snap.docs[0].data().email);
                  setShowAuthInvite(false); 
              } else {
                  setLinkedEmail(null);
              }
          });
          return () => unsub();
      } catch (e) {
          console.error("Auth check failed", e);
      }
  };

  useEffect(() => {
      if (viewMode === 'approved' && !linkedEmail) {
          const hasSeen = sessionStorage.getItem('has_seen_auth_invite');
          if (!hasSeen) {
             setShowAuthInvite(true);
             sessionStorage.setItem('has_seen_auth_invite', 'true');
          }
      }
  }, [viewMode, linkedEmail]);

  const handleLogin = async () => {
      try {
          const result = await signInWithPopup(auth, googleProvider);
          const user = result.user;
          const docRef = doc(db, "user_mappings", user.uid);
          const docSnap = await getDoc(docRef);
          
          if (docSnap.exists()) {
             const storedInternalId = docSnap.data().internalId;
             if (storedInternalId !== myUserId) {
                 localStorage.setItem('user_device_id', storedInternalId);
                 setMyUserId(storedInternalId);
                 setLinkedEmail(user.email);
                 showNotification('success', 'Sesión Recuperada', `Hola de nuevo, ${user.displayName || 'Viajero'}.`);
                 window.location.reload();
             } else {
                 setLinkedEmail(user.email);
                 showNotification('info', 'Sesión Actualizada', 'Ya estabas usando esta cuenta.');
             }
          } else {
             await setDoc(docRef, {
                 internalId: myUserId,
                 email: user.email,
                 linkedAt: Date.now()
             });
             setLinkedEmail(user.email);
             showNotification('success', 'Cuenta Vinculada', 'Tu progreso ahora está respaldado.');
          }
      } catch (error) {
          console.error(error);
          showNotification('error', 'Error de Acceso', 'No se pudo iniciar sesión con Google.');
      }
  };

  const handleLinkAccount = async () => {
      try {
          const result = await signInWithPopup(auth, googleProvider);
          const user = result.user;
          const docRef = doc(db, "user_mappings", user.uid);
          const docSnap = await getDoc(docRef);
          
          if (docSnap.exists()) {
             const existingId = docSnap.data().internalId;
             if (existingId !== myUserId) {
                 showNotification('error', 'Cuenta Ocupada', 'Esta cuenta de Google ya está vinculada a otro usuario.');
                 return;
             }
             await updateDoc(docRef, { email: user.email });
          } else {
             await setDoc(docRef, {
                 internalId: myUserId,
                 email: user.email,
                 linkedAt: Date.now()
             });
          }
          setLinkedEmail(user.email);
          setShowAuthInvite(false);
          showNotification('success', 'Cuenta Vinculada', `Tu progreso ahora está seguro con ${user.email}`);
      } catch (error) {
          console.error(error);
          showNotification('error', 'Error de Vinculación', 'No se pudo conectar con Google.');
      }
  };

  useEffect(() => {
    const unsub = onSnapshot(doc(db, "settings", "config"), (docSnapshot) => {
        if (docSnapshot.exists()) {
            setIsCreationAllowed(docSnapshot.data().allowCreation !== false);
        } else {
            setIsCreationAllowed(true);
        }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (viewMode === 'landing' && !isLoading) {
      const q = query(collection(db, "towns"), where("status", "==", "aprobado"));
      const unsub = onSnapshot(q, (snapshot) => {
        const towns = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        } as TownData & { id: string }));
        towns.sort((a, b) => b.createdAt - a.createdAt);
        setPublicTowns(towns);
      });
      return () => unsub();
    }
  }, [viewMode, isLoading]);

  useEffect(() => {
    if (!currentTownId) {
      if (viewMode !== 'admin' && viewMode !== 'joining_name') {
          setViewMode('landing');
          setIsLoading(false);
      }
      return;
    }
    if (!myUserId) return; 

    setIsLoading(true);
    
    const unsub = onSnapshot(doc(db, "towns", currentTownId), (docSnapshot) => {
      if (docSnapshot.exists()) {
        const data = docSnapshot.data() as TownData;
        setTownData(data);
        const isMember = data.members?.some(m => m.userId === myUserId);
        const isWaiting = data.joinRequests?.some(r => r.userId === myUserId);
        if (isMember) {
            if (data.status === 'aprobado') {
                setViewMode('approved');
                if (data.toys) {
                    checkBirthdays(data.toys, currentTownId);
                    fixRelationData(data.toys, currentTownId); 
                }
                checkAutomaticPayroll(data, currentTownId);
            } else if (data.status === 'rechazado') {
                setViewMode('rejected');
            } else {
                setViewMode('pending'); 
            }
        } else if (isWaiting) {
            setViewMode('joining_wait'); 
        }
      } else {
        handleResetSession();
        showNotification('error', 'Pueblo no encontrado', 'El pueblo ha sido eliminado.');
      }
      setIsLoading(false);
    }, (error) => {
      console.error("Error fetching town:", error);
      setIsLoading(false);
    });
    return () => unsub();
  }, [currentTownId, myUserId]); 

  // --- 1. CORE RELATIONSHIP HELPERS ---

  const addRelation = (toyList: Toy[], sourceId: string, targetId: string, type: RelationType) => {
      const sourceIndex = toyList.findIndex(t => t.id === sourceId);
      if (sourceIndex === -1) return toyList;
      
      const sourceToy = toyList[sourceIndex];
      const existingRel = sourceToy.relations?.find(r => r.toyId === targetId);
      
      if (existingRel && existingRel.type === type) return toyList;

      const otherRels = sourceToy.relations?.filter(r => r.toyId !== targetId) || [];
      const newRels = [...otherRels, { toyId: targetId, type }];
      
      const newList = [...toyList];
      newList[sourceIndex] = { ...sourceToy, relations: newRels };
      return newList;
  };

  const applyManualRelations = (primaryToy: Toy, newRelations: Relation[], allToys: Toy[]): Toy[] => {
      let currentToys = [...allToys];
      const primaryIndex = currentToys.findIndex(t => t.id === primaryToy.id);
      if (primaryIndex === -1) { 
          currentToys.push({ ...primaryToy, relations: newRelations }); 
      } else { 
          currentToys[primaryIndex] = { ...primaryToy, relations: newRelations }; 
      }

      newRelations.forEach(rel => {
          const target = currentToys.find(t => t.id === rel.toyId);
          if (target) {
              const reciprocalRole = getReciprocalType(rel.type, target.gender, primaryToy.gender);
              currentToys = addRelation(currentToys, target.id, primaryToy.id, reciprocalRole);
          }
      });

      return currentToys;
  };

  const fixRelationData = async (toys: Toy[], townId: string) => {
      let currentToys = [...toys];
      let needsUpdate = false;

      currentToys = currentToys.map(toy => {
          if (!toy.relations) return toy;
          let changed = false;
          const fixedRels = toy.relations.map(r => {
              const correct = getGenderedRole(r.type, toy.gender);
              if (correct !== r.type) { changed = true; return { ...r, type: correct }; }
              return r;
          });
          if (changed) { needsUpdate = true; return { ...toy, relations: fixedRels }; }
          return toy;
      });

      if (needsUpdate) {
          try {
              const townRef = doc(db, "towns", townId);
              await updateDoc(townRef, { toys: currentToys });
          } catch (e) {
              console.error("Error updating relations", e);
          }
      }
  };

  const checkBirthdays = async (toys: Toy[], townId: string) => {
      if (!toys) return;
      const today = new Date();
      const updates: { id: string, newAge: number, name: string }[] = [];
      const updatedToys = [...toys];
      let hasUpdates = false;
      
      toys.forEach((toy, index) => {
          if (!toy.birthday) return; 
          const birthDate = new Date(toy.birthday);
          if (isNaN(birthDate.getTime())) return;
          
          let age = today.getFullYear() - birthDate.getFullYear();
          const m = today.getMonth() - birthDate.getMonth();
          if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
              age--;
          }
          
          // Logic: Update if stored age is null or less than calculated age
          if (toy.age == null || age > toy.age) {
              updates.push({ id: toy.id, newAge: age, name: toy.name });
              updatedToys[index] = { ...toy, age: age };
              hasUpdates = true;
          }
      });

      if (hasUpdates) {
          setCelebratingToys(prev => {
              // Ensure we don't show duplicate notifications for the same session
              const newCelebrations = updates.filter(u => !prev.some(p => p.id === u.id));
              return [...prev, ...newCelebrations];
          });
          try {
              const townRef = doc(db, "towns", townId);
              await updateDoc(townRef, { toys: updatedToys });
          } catch (e) {
              console.error("Error updating ages:", e);
          }
      }
  };

  const checkAutomaticPayroll = async (data: TownData, townId: string) => {
      if (!data || !data.banks) return;
      const ONE_MONTH_MS = 30 * 24 * 60 * 60 * 1000;
      const now = Date.now();
      const updatedBanks: Bank[] = [];
      let updatedToys = data.toys ? [...data.toys] : [];
      let hasUpdates = false;
      let totalPaidLog = 0;
      data.banks.forEach(bank => {
          if (!bank.lastPayrollDate || (now - bank.lastPayrollDate) > ONE_MONTH_MS) {
              let bankTotalPaid = 0;
              if (bank.employees) {
                  bank.employees.forEach(emp => {
                      const toyIndex = updatedToys.findIndex(t => t.id === emp.toyId);
                      if (toyIndex !== -1) {
                          const toy = updatedToys[toyIndex];
                          if (toy.bankAccountId === bank.id) {
                              const currentBalance = toy.accountBalance || 0;
                              updatedToys[toyIndex] = {
                                  ...toy,
                                  accountBalance: currentBalance + emp.salary
                              };
                              bankTotalPaid += emp.salary;
                          }
                      }
                  });
              }
              updatedBanks.push({
                  ...bank,
                  funds: bank.funds - bankTotalPaid,
                  lastPayrollDate: now
              });
              if (bankTotalPaid > 0) {
                  totalPaidLog += bankTotalPaid;
              }
              hasUpdates = true;
          } else {
              updatedBanks.push(bank);
          }
      });
      if (hasUpdates) {
          try {
              const townRef = doc(db, "towns", townId);
              await updateDoc(townRef, { 
                  banks: updatedBanks,
                  toys: updatedToys,
                  history: arrayUnion({
                    id: crypto.randomUUID(),
                    action: 'update',
                    description: `Nómina Automática: Se han pagado COP $${totalPaidLog.toLocaleString()} en salarios.`,
                    timestamp: Date.now(),
                    author: 'Sistema'
                  })
              });
              if(totalPaidLog > 0) {
                  showNotification('success', '¡Día de Pago!', 'Se ha depositado la nómina mensual automáticamente en las cuentas de los empleados.');
              }
          } catch (e) {
              console.error("Error processing payroll", e);
          }
      }
  };

  useEffect(() => {
    if (viewMode === 'admin') {
      const q = query(collection(db, "towns"), where("status", "==", "pendiente"));
      const unsub = onSnapshot(q, (snapshot) => {
         const requests = snapshot.docs.map(d => ({
            id: d.id,
            data: d.data() as TownData
         }));
         setPendingRequests(requests);
      });
      return () => unsub();
    }
  }, [viewMode]);

  const initiateCreateTown = () => { setPendingAction({ type: 'create' }); setViewMode('joining_name'); };
  const initiateJoinTown = (townId: string, townName: string) => { setPendingAction({ type: 'join', townId, townName }); setViewMode('joining_name'); };
  const handleConfirmIdentity = async () => {
      if (!inputName.trim() || !myUserId) return;
      localStorage.setItem('user_display_name', inputName);
      setMyUserName(inputName);
      if (pendingAction?.type === 'create') await executeCreateTown(inputName);
      else if (pendingAction?.type === 'join' && pendingAction.townId) await executeJoinRequest(pendingAction.townId, inputName);
  };
  const executeCreateTown = async (userName: string) => {
    if (!requestName.trim()) return;
    if (!isCreationAllowed) { showNotification('error', 'Creación Bloqueada', 'El administrador ha deshabilitado la creación.'); return; }
    const creatorMember: TownMember = { userId: myUserId, name: userName, role: 'admin', joinedAt: Date.now() };
    const currentYear = new Date().getFullYear().toString();
    const newTown: TownData = {
      name: requestName, status: 'pendiente', createdAt: Date.now(), members: [creatorMember], joinRequests: [], toys: [], banks: [], companies: [], government: { presidentId: null, vicePresidentId: null, mayorId: null, termYear: currentYear, history: [] }, police: { commissionerId: null, officers: [], prisoners: [], records: [] }, laws: [], socialProfiles: [],
      history: [{ id: crypto.randomUUID(), action: 'create', description: `${userName} ha fundado el pueblo.`, timestamp: Date.now(), author: userName }]
    };
    try { const docRef = await addDoc(collection(db, "towns"), newTown); localStorage.setItem('current_town_id', docRef.id); setCurrentTownId(docRef.id); setIsLoading(true); } catch (e) { showNotification('error', 'Error', 'No se pudo crear el pueblo.'); }
  };
  const executeJoinRequest = async (townId: string, userName: string) => {
      try { const request: JoinRequest = { userId: myUserId, name: userName, timestamp: Date.now() }; await updateDoc(doc(db, "towns", townId), { joinRequests: arrayUnion(request), history: arrayUnion({ id: crypto.randomUUID(), action: 'join', description: `${userName} ha solicitado permisos de edición.`, timestamp: Date.now(), author: userName }) }); localStorage.setItem('current_town_id', townId); setCurrentTownId(townId); setIsLoading(true); } catch (e) { showNotification('error', 'Error', 'No se pudo enviar la solicitud.'); }
  };
  const handleResetSession = () => { localStorage.removeItem('current_town_id'); setCurrentTownId(null); setTownData(null); setViewMode('landing'); setPendingAction(null); setIsLoading(false); };
  const handleApproveMember = async (req: JoinRequest) => { if (!currentTownId || !townData) return; const newMember: TownMember = { userId: req.userId, name: req.name, role: 'member', joinedAt: Date.now() }; try { await updateDoc(doc(db, "towns", currentTownId), { joinRequests: arrayRemove(req), members: arrayUnion(newMember), history: arrayUnion({ id: crypto.randomUUID(), action: 'update', description: `${myUserName} (Admin) ha concedido permisos a ${req.name}.`, timestamp: Date.now(), author: myUserName }) }); showNotification('success', 'Permiso Concedido', `${req.name} ahora puede editar el pueblo.`); } catch (e) { console.error(e); } };
  const handleRejectMember = async (req: JoinRequest) => { if (!currentTownId) return; try { await updateDoc(doc(db, "towns", currentTownId), { joinRequests: arrayRemove(req), history: arrayUnion({ id: crypto.randomUUID(), action: 'update', description: `${myUserName} (Admin) ha rechazado la solicitud de ${req.name}.`, timestamp: Date.now(), author: myUserName }) }); } catch (e) { console.error(e); } };
  const handleUpdateTownData = async (field: keyof TownData, newData: any, logMsg: string, logActionType: HistoryLog['action'] = 'update') => { if (!currentTownId) return; const fullLogMsg = `${myUserName} ${logMsg}`; await updateDoc(doc(db, "towns", currentTownId), { [field]: newData, history: arrayUnion({ id: crypto.randomUUID(), action: logActionType, description: fullLogMsg, timestamp: Date.now(), author: myUserName }) }); };

  const addToy = (newToyData: Omit<Toy, 'id' | 'createdAt'>) => {
    if (!townData) return;
    const familyExists = townData.toys.some(t => t.family === newToyData.family);
    const newId = crypto.randomUUID();
    const newToy: Toy = { ...newToyData, id: newId, createdAt: Date.now(), isLeader: !familyExists && !newToyData.isSubFamilyLeader, bankAccountId: null, accountBalance: 0, relations: newToyData.relations || [] };
    
    // Manual Relations Only
    const newToysList = applyManualRelations(newToy, newToy.relations || [], townData.toys);
    
    handleUpdateTownData('toys', newToysList, `ha registrado a: ${newToy.name}`, 'create');
    if (isCreatingFamily) { 
        navToFamilyDetail(newToy.family);
        setIsCreatingFamily(false); 
    }
    if (isAddingMember || isCreatingSubFamily) { setIsAddingMember(false); setIsCreatingSubFamily(false); setTargetSubFamily(null); }
  };

  const updateToy = (id: string, updatedData: Partial<Toy>) => { 
      if (!townData) return;
      const currentToy = townData.toys.find(t => t.id === id);
      if (!currentToy) return;
      const mergedToy = { ...currentToy, ...updatedData };
      
      let newToysList = [...townData.toys];
      if (updatedData.relations || (updatedData.gender && updatedData.gender !== currentToy.gender)) { 
          // Use manual applier for relations/gender changes
          newToysList = applyManualRelations(mergedToy, mergedToy.relations || [], townData.toys); 
      } else {
          // Simple update
          newToysList = townData.toys.map(toy => toy.id === id ? mergedToy : toy);
      }
      
      handleUpdateTownData('toys', newToysList, `ha actualizado a: ${updatedData.name || 'un habitante'}`); 
      setEditingToy(null); 
  };

  const confirmDelete = () => { if (!confirmDeleteId || !townData) return; const toyToDelete = townData.toys.find(t => t.id === confirmDeleteId); const newToysList = townData.toys.filter((toy) => toy.id !== confirmDeleteId); handleUpdateTownData('toys', newToysList, `ha eliminado a: ${toyToDelete?.name}`, 'delete'); const remainingFamilyMembers = newToysList.filter(t => t.family === toyToDelete?.family); if (selectedFamily && remainingFamilyMembers.length === 0) { setSelectedFamily(null); handleSetAppView('home'); } if (editingToy?.id === confirmDeleteId) setEditingToy(null); setConfirmDeleteId(null); };
  
  const getFilteredGlobalToys = () => {
    if (!townData) return [];
    let result = [...townData.toys];
    if (statsSearch) { const term = statsSearch.toLowerCase(); result = result.filter(t => t.name.toLowerCase().includes(term) || t.family.toLowerCase().includes(term)); }
    if (statsMonth) {
        result = result.filter(t => {
            if (!t.birthday) return false;
            const parts = t.birthday.split('-');
            if (parts.length === 3) {
                const mIndex = parseInt(parts[1]) - 1;
                return MONTHS[mIndex] === statsMonth;
            }
            return false;
        });
    }
    if (statsType) {
        result = result.filter(t => t.type === statsType);
    }
    result.sort((a, b) => { 
        const ageA = a.age ?? -1; 
        const ageB = b.age ?? -1; 
        if (statsSort === 'ageDesc') return ageB - ageA; 
        if (statsSort === 'ageAsc') return ageA - ageB; 
        // Improved Alphabetical Sorting: Use localeCompare for correct handling of special chars and natural order
        return a.name.localeCompare(b.name, 'es', { sensitivity: 'base' });
    });
    return result;
  };
  
  const currentFamilyToys = (townData && selectedFamily) ? townData.toys.filter(t => t.family === selectedFamily) : [];
  const mainFamilyMembers = currentFamilyToys.filter(t => !t.subFamily).sort((a, b) => a.name.localeCompare(b.name, 'es', { sensitivity: 'base' }));
  const subFamiliesGrouped = currentFamilyToys.reduce((groups, toy) => { if (toy.subFamily) { if (!groups[toy.subFamily]) groups[toy.subFamily] = []; groups[toy.subFamily].push(toy); } return groups; }, {} as Record<string, Toy[]>);
  const isAdmin = townData?.members?.find(m => m.userId === myUserId)?.role === 'admin';

  if (isLoading) return <div className="min-h-screen flex items-center justify-center bg-slate-50"><Loader2 className="w-10 h-10 animate-spin text-blue-500"/></div>;
  if (viewMode === 'joining_name') return ( <div className="fixed inset-x-0 top-0 safe-screen bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-sans"><div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl p-6 border-2 border-blue-100 animate-in zoom-in-95 duration-300"><h3 className="text-xl font-extrabold text-slate-800 mb-2 text-center">Identifícate</h3><p className="text-sm text-slate-500 text-center mb-6">Antes de continuar, necesitamos tu nombre.</p><div className="space-y-4"><div><label className="text-xs font-bold text-slate-400 uppercase ml-1">Tu Nombre</label><input type="text" autoFocus value={inputName} onChange={(e) => setInputName(e.target.value)} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"/></div><div className="flex gap-3"><button onClick={handleResetSession} className="flex-1 py-3 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl active:scale-95 btn-press">Cancelar</button><button onClick={handleConfirmIdentity} disabled={!inputName.trim()} className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg disabled:opacity-50 active:scale-95 btn-press">Continuar</button></div></div></div></div>);
  if (viewMode === 'landing') return ( <div className="fixed inset-x-0 top-0 safe-screen bg-slate-50 flex flex-col items-center font-sans w-full overflow-y-auto custom-scrollbar"><NotificationModal isOpen={notification.show} onClose={() => setNotification({ ...notification, show: false })} type={notification.type} title={notification.title} message={notification.message} /><div className="bg-white border-b border-slate-100 p-4 sticky top-0 z-10 w-full shadow-sm"><div className="max-w-md mx-auto flex items-center justify-center gap-2"><Castle className="w-6 h-6 text-blue-600" /><h1 className="text-xl font-extrabold text-slate-800">Pueblo de Juguetes</h1></div></div><div className="max-w-md w-full p-4 space-y-6 pb-20 flex flex-col items-center">{isCreationAllowed ? (<div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 w-full animate-enter-view"><h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2"><Plus className="w-5 h-5 text-blue-500" /> Crear Nuevo Pueblo</h2><div className="space-y-4"><input type="text" value={requestName} onChange={(e) => setRequestName(e.target.value)} placeholder="Nombre del pueblo..." className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl text-lg font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500 transition-all"/><button onClick={initiateCreateTown} disabled={!requestName.trim()} className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white py-3.5 rounded-xl font-bold transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 btn-press">Solicitar Creación</button><p className="text-[10px] text-center text-slate-400">Requiere aprobación del administrador.</p></div></div>) : (<div className="bg-slate-100 rounded-2xl border border-slate-200 p-6 text-center w-full"><Lock className="w-8 h-8 text-slate-400 mx-auto mb-2" /><h3 className="font-bold text-slate-600 mb-1">Inscripciones Cerradas</h3></div>)}<div className="space-y-3 w-full animate-enter-view" style={{animationDelay: '0.1s'}}><div className="flex items-center gap-2 px-2"><MapPin className="w-4 h-4 text-slate-400" /><h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Pueblos Disponibles</h3></div>{publicTowns.length === 0 ? (<div className="text-center py-10 bg-white rounded-2xl border border-dashed border-slate-200 w-full"><p className="text-sm text-slate-400 font-medium">No hay pueblos activos aún.</p></div>) : (<div className="grid gap-3 w-full">{publicTowns.map(town => (<button key={town.id} onClick={() => initiateJoinTown(town.id, town.name)} className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 hover:border-emerald-400 hover:shadow-md transition-all group text-left flex items-center justify-between w-full active:scale-95 btn-press"><div className="flex items-center gap-4"><div className="w-10 h-10 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600 group-hover:scale-110 transition-transform"><Castle className="w-5 h-5" /></div><div><h4 className="font-bold text-slate-800 group-hover:text-emerald-700 transition-colors">{town.name}</h4><span className="text-xs text-slate-400 flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(town.createdAt).toLocaleDateString()}</span></div></div><ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-emerald-500" /></button>))}</div>)}<button onClick={handleLogin} className="w-full mt-4 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors active:scale-95 btn-press"><LogIn className="w-4 h-4" /> Ya tengo cuenta (Google)</button></div></div><div className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-md p-3 text-center border-t border-slate-200 w-full"><button onClick={() => setViewMode('admin')} className="text-[10px] text-slate-400 hover:text-slate-600 font-bold uppercase tracking-widest">Admin</button></div></div>);
  if (viewMode === 'joining_wait') return ( <div className="fixed inset-x-0 top-0 safe-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-500 w-full"><div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl border border-slate-200"><div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-6"><UserPlus className="w-10 h-10 text-blue-500 animate-pulse" /></div><h2 className="text-2xl font-extrabold text-slate-800 mb-2">Solicitud Enviada</h2><p className="text-slate-500 mb-8">El admin del pueblo debe aceptarte.</p><button onClick={handleResetSession} className="text-xs text-slate-400 hover:text-red-500 font-bold mt-2 btn-press">Cancelar y volver</button></div></div>);
  if (viewMode === 'pending' || (isLoading && !townData)) return ( <div className="fixed inset-x-0 top-0 safe-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-500 w-full"><div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl border border-slate-200"><div className="w-20 h-20 bg-amber-50 rounded-full flex items-center justify-center mx-auto mb-6"><Clock className="w-10 h-10 text-amber-500 animate-pulse" /></div><h2 className="text-2xl font-extrabold text-slate-800 mb-2">Creación en Proceso</h2><p className="text-slate-500 mb-8">Espera aprobación del Desarrollador.</p><button onClick={handleResetSession} className="text-xs text-slate-400 hover:text-red-500 font-bold mt-2 btn-press">Cancelar</button></div></div>);
  if (viewMode === 'rejected') return ( <div className="fixed inset-x-0 top-0 safe-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center w-full"><div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl border-2 border-red-100"><div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6"><XCircle className="w-10 h-10 text-red-500" /></div><h2 className="text-2xl font-extrabold text-slate-800 mb-4">Acceso Denegado</h2><button onClick={handleResetSession} className="w-full py-3 bg-slate-900 text-white font-bold rounded-xl shadow-lg active:scale-95 btn-press">Volver al Inicio</button></div></div>);
  if (viewMode === 'admin') { return <div className="text-center p-10">Admin Panel (Desktop Optimized) <button onClick={() => setViewMode('landing')}>Exit</button></div>; }
  
  if (!townData) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-blue-500"/></div>;

  const safeGovernment = townData.government;
  const safePolice = townData.police || { commissionerId: null, officers: [], prisoners: [], records: [] };
  const shouldHideHeader = isFullScreen || appView === 'stats' || appView === 'family_detail' || isCreatingFamily;

  const headerAction = linkedEmail ? (
      <button onClick={() => setShowSettingsModal(true)} className="p-2 bg-green-50 rounded-full shadow-sm border border-green-200 text-green-600 hover:bg-green-100 transition-colors active:scale-95 btn-press" title={`Vinculado: ${linkedEmail}`}>
          <Settings className="w-5 h-5" />
      </button>
  ) : (
      <button onClick={() => setShowAuthInvite(true)} className="p-2 bg-white rounded-full shadow-sm border border-slate-200 text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors animate-pulse active:scale-95 btn-press">
          <Mail className="w-5 h-5" />
      </button>
  );

  return (
    // Updated container to use the safe-screen class which uses the --viewport-height variable
    <div 
        className="safe-screen w-full flex flex-col font-sans bg-slate-50 overflow-hidden"
    >
      {!shouldHideHeader && (
         <div className="w-full flex-none relative z-10">
            <Header count={townData?.toys?.length || 0} actions={headerAction} />
         </div>
      )}
      
      {showSettingsModal && (
          <SettingsModal 
            email={linkedEmail} 
            onClose={() => setShowSettingsModal(false)} 
          />
      )}

      {showAuthInvite && (
          <div className="fixed inset-x-0 top-0 safe-screen z-[8000] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-in fade-in duration-300">
              <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden p-6 text-center animate-in zoom-in-95">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Mail className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-extrabold text-slate-800 mb-2">¡Protege tu Progreso!</h3>
                  <p className="text-sm text-slate-500 mb-6">Te invitamos a registrarte vinculando tu cuenta de Google. Así podrás recuperar tu acceso en cualquier dispositivo.</p>
                  <button onClick={handleLinkAccount} className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg mb-3 flex items-center justify-center gap-2 active:scale-95 btn-press">
                      <LogIn className="w-4 h-4" /> Vincular con Google
                  </button>
                  <button onClick={() => setShowAuthInvite(false)} className="text-xs font-bold text-slate-400 hover:text-slate-600 btn-press">
                      Quizás más tarde
                  </button>
              </div>
          </div>
      )}

      <NotificationModal isOpen={notification.show} onClose={() => setNotification({ ...notification, show: false })} type={notification.type} title={notification.title} message={notification.message} copyText={notification.copyText} />
      <BirthdayModal birthdays={celebratingToys} onClose={() => setCelebratingToys([])} />
      {showMembers && <MembersModal members={townData.members} onClose={() => setShowMembers(false)} />}
      
      {/* GLOBAL DELETE CONFIRMATION MODAL */}
      <ConfirmationModal
        isOpen={!!confirmDeleteId}
        onClose={() => setConfirmDeleteId(null)}
        onConfirm={confirmDelete}
        title="¿Eliminar Habitante?"
        message={`Estás a punto de borrar a ${townData.toys.find(t => t.id === confirmDeleteId)?.name || 'este habitante'}. Esta acción es irreversible.`}
        confirmText="Sí, Eliminar"
        isDangerous={true}
      />
      
      {showJoinRequests && isAdmin && (<div className="fixed inset-x-0 top-0 safe-screen z-[6000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200"><div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 border border-slate-200 animate-in zoom-in-95 duration-300 relative"><button onClick={() => setShowJoinRequests(false)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"><XCircle className="w-6 h-6"/></button><h3 className="text-xl font-bold text-slate-800 mb-1 flex items-center gap-2"><UserPlus className="w-6 h-6 text-blue-500"/> Solicitudes de Permisos</h3><p className="text-sm text-slate-500 mb-6">Personas esperando permiso para editar.</p><div className="space-y-3 max-h-[60vh] overflow-y-auto custom-scrollbar">{townData.joinRequests && townData.joinRequests.length > 0 ? (townData.joinRequests.map(req => (<div key={req.userId} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100"><div><div className="font-bold text-slate-800">{req.name}</div><div className="text-[10px] text-slate-400">{new Date(req.timestamp).toLocaleTimeString()}</div></div><div className="flex gap-2"><button onClick={() => handleRejectMember(req)} className="p-2 bg-white border border-red-100 text-red-500 rounded-lg hover:bg-red-50 active:scale-95 btn-press"><UserX className="w-4 h-4"/></button><button onClick={() => handleApproveMember(req)} className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 shadow-md shadow-blue-200 active:scale-95 btn-press"><UserCheck className="w-4 h-4"/></button></div></div>))) : (<div className="text-center py-8 text-slate-400 text-sm">No hay solicitudes pendientes.</div>)}</div></div></div>)}

      {/* Main scrollable area - Using ref for scroll persistence */}
      <main 
        ref={mainContainerRef}
        className={`flex-1 w-full max-w-5xl mx-auto px-4 py-6 flex flex-col items-center overflow-y-auto custom-scrollbar ${shouldHideHeader ? 'pt-0' : ''}`}
        style={{ willChange: 'transform' }} // Optimization for flicker reduction
      >
        {!shouldHideHeader && (
           <div className="w-full flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6">
             <div className="flex items-center gap-2 justify-between sm:justify-start w-full sm:w-auto">
                 <span className="text-sm font-bold text-blue-600 bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-100 flex items-center gap-1"><Castle className="w-3 h-3" /> {townData.name}</span>
                 {isAdmin && (
                    <button onClick={() => setShowJoinRequests(true)} className="relative p-2 bg-white border border-slate-200 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 ml-2 active:scale-95 btn-press" title="Gestionar Permisos"><UserPlus className="w-4 h-4" />{townData.joinRequests && townData.joinRequests.length > 0 && (<span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse border border-white"></span>)}</button>
                 )}
             </div>
             <div className="flex gap-2 justify-end w-full sm:w-auto">
                 <button onClick={() => setShowMembers(true)} className="flex items-center gap-2 bg-white px-4 py-2 rounded-xl shadow-sm border border-slate-200 text-sm font-bold text-slate-600 hover:text-purple-600 hover:border-purple-200 transition-all flex-1 sm:flex-none justify-center active:scale-95 btn-press"><Users className="w-4 h-4" /><span className="inline">Miembros</span></button>
                 <button onClick={navToStats} className="flex items-center gap-2 bg-white px-4 py-2 rounded-xl shadow-sm border border-slate-200 text-sm font-bold text-slate-600 hover:text-blue-600 hover:border-blue-200 transition-all flex-1 sm:flex-none justify-center active:scale-95 btn-press"><BarChart3 className="w-4 h-4" /><span className="inline">Stats</span></button>
             </div>
           </div>
        )}

        {appView === 'families' && !isCreatingFamily && (
            <FullScreenPage>
                <div className="w-full">
                    <div className="flex items-center gap-3 mb-6">
                        <button onClick={navGoHome} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors active:scale-95 btn-press"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
                        <h2 className="text-2xl font-bold text-slate-800">Familias del Pueblo</h2>
                    </div>
                    <FamilyGrid 
                        toys={townData.toys || []} 
                        onSelectFamily={(f) => navToFamilyDetail(f)} 
                        onCreateFamily={() => setIsCreatingFamily(true)} 
                    />
                </div>
            </FullScreenPage>
        )}

        {/* Social Media View */}
        {appView === 'social' && !isCreatingFamily && (
            <SocialHub 
                toys={townData.toys || []} 
                profiles={townData.socialProfiles || []} 
                onUpdateProfiles={(p) => handleUpdateTownData('socialProfiles', p, 'ha actualizado las redes sociales')} 
                onBack={navGoHome} 
            />
        )}

        {appView === 'stats' && !isCreatingFamily && (
          <FullScreenPage>
             <div className="w-full">
                {/* Custom Modals for Stats */}
                {showMonthSelector && (
                    <SelectionModal 
                        title="Filtrar por Mes" 
                        options={MONTHS} 
                        selected={statsMonth} 
                        onSelect={setStatsMonth} 
                        onClose={() => setShowMonthSelector(false)}
                        allowClear={true}
                        clearLabel="Todos los Meses"
                    />
                )}
                {showTypeSelector && (
                    <SelectionModal 
                        title="Filtrar por Tipo" 
                        options={Object.values(ToyType)} 
                        selected={statsType} 
                        onSelect={(v) => setStatsType(v as ToyType)} 
                        onClose={() => setShowTypeSelector(false)}
                        allowClear={true}
                        clearLabel="Todos los Tipos"
                    />
                )}

                <div className="flex items-center gap-3 mb-4">
                    <button onClick={navGoHome} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors active:scale-95 btn-press"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
                    <h2 className="text-2xl font-bold text-slate-800">Directorio Global</h2>
                </div>
                <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col gap-4 mb-6">
                    <div className="flex flex-col md:flex-row gap-3">
                        <div className="relative flex-1">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Search className="w-4 h-4 text-slate-400" /></div>
                            <input type="text" placeholder="Buscar por nombre..." value={statsSearch} onChange={(e) => setStatsSearch(e.target.value)} className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"/>
                        </div>
                        <div className="flex gap-2 overflow-x-auto pb-1 md:pb-0 no-scrollbar">
                            <button onClick={() => setStatsSort('az')} className={`flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition-colors border active:scale-95 btn-press ${statsSort === 'az' ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'}`}><ArrowUpDown className="w-3 h-3" /> A-Z</button>
                            <button onClick={() => setStatsSort('ageDesc')} className={`flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition-colors border active:scale-95 btn-press ${statsSort === 'ageDesc' ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'}`}><ArrowDownWideNarrow className="w-3 h-3" /> Mayor Edad</button>
                        </div>
                    </div>
                    
                    {/* Custom Selection Triggers */}
                    <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                        <button 
                            onClick={() => setShowMonthSelector(true)}
                            className={`flex items-center gap-2 px-3 py-2 rounded-lg border min-w-fit active:scale-95 transition-all text-xs font-bold btn-press ${statsMonth ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-slate-50 border-slate-100 text-slate-500'}`}
                        >
                            <Calendar className="w-4 h-4" />
                            {statsMonth || "Todos los Meses"}
                            <ChevronDown className="w-3 h-3 ml-1" />
                        </button>

                        <button 
                            onClick={() => setShowTypeSelector(true)}
                            className={`flex items-center gap-2 px-3 py-2 rounded-lg border min-w-fit active:scale-95 transition-all text-xs font-bold btn-press ${statsType ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-slate-50 border-slate-100 text-slate-500'}`}
                        >
                            <Filter className="w-4 h-4" />
                            {statsType || "Todos los Tipos"}
                            <ChevronDown className="w-3 h-3 ml-1" />
                        </button>
                    </div>

                    {(statsMonth || statsType) && (
                        <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 flex items-center gap-2 animate-enter-view">
                            <PartyPopper className="w-5 h-5 text-blue-500" />
                            <div className="text-xs text-blue-700 font-bold">
                                {statsMonth && !statsType && `${getFilteredGlobalToys().length} Habitantes nacieron en ${statsMonth}`}
                                {!statsMonth && statsType && `Hay ${getFilteredGlobalToys().length} ${statsType}s en el pueblo`}
                                {statsMonth && statsType && `${getFilteredGlobalToys().length} ${statsType}s nacieron en ${statsMonth}`}
                            </div>
                        </div>
                    )}
                </div>
                <ToyList 
                    toys={getFilteredGlobalToys()} 
                    onDelete={setConfirmDeleteId} 
                    onEdit={(toy) => setEditingToy(toy)} 
                    showFamilyColumn={true}
                    hideActions={true}
                />
                {editingToy && (<div className="fixed inset-x-0 top-0 safe-screen z-[6000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm"><div className="w-full max-w-lg relative"><ToyForm toys={townData.toys || []} onAddToy={() => {}} onUpdateToy={updateToy} onCancel={() => setEditingToy(null)} editingToy={editingToy} /></div></div>)}
             </div>
          </FullScreenPage>
        )}

        {/* ... (Rest of existing content for home, creating family, family detail) ... */}
        {!isCreatingFamily && appView === 'home' && (
          <div className="w-full space-y-6 animate-enter-view pb-10">
            <button onClick={navToFamilies} className="w-full bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:border-blue-300 hover:shadow-md transition-all group text-left flex items-center justify-between active:scale-95 btn-press">
                <div className="flex items-center gap-4"><div className="w-14 h-14 bg-blue-50 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform"><Users className="w-7 h-7 text-blue-600" /></div><div><h2 className="text-xl font-bold text-slate-800 group-hover:text-blue-700 transition-colors">Familias del Pueblo</h2><p className="text-sm text-slate-500">Ver todas las familias y sus integrantes.</p></div></div><div className="bg-slate-50 p-3 rounded-full group-hover:bg-blue-50"><ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-blue-500" /></div>
            </button>
            <EconomyDashboard 
                toys={townData.toys || []} 
                banks={townData.banks || []} 
                companies={townData.companies || []}
                socialProfiles={townData.socialProfiles || []} 
                onAddBank={(b) => { const newBanks = [...(townData.banks || []), b]; handleUpdateTownData('banks', newBanks, `ha fundado el banco: ${b.name}`); }} 
                onUpdateBank={(id, data) => { const newBanks = (townData.banks || []).map(b => b.id === id ? { ...b, ...data } : b); handleUpdateTownData('banks', newBanks, 'ha actualizado actividad bancaria'); }} 
                onAddCompany={(c) => { const newComps = [...(townData.companies || []), c]; handleUpdateTownData('companies', newComps, `ha registrado la empresa: ${c.name}`); }} 
                onUpdateCompany={(id, data) => { const newComps = (townData.companies || []).map(c => c.id === id ? { ...c, ...data } : c); handleUpdateTownData('companies', newComps, 'ha actualizado la empresa'); }} 
                onUpdateToy={updateToy} 
                onUpdateSocialProfiles={(p) => handleUpdateTownData('socialProfiles', p, 'ha actualizado las redes sociales')}
                onToggleFullScreen={setIsFullScreen} 
            />
            
            <button onClick={navToSocial} className="w-full bg-gradient-to-r from-pink-500 to-rose-600 p-6 rounded-2xl shadow-lg shadow-pink-200 text-white flex items-center justify-between group transition-all transform active:scale-95 btn-press">
                <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center shadow-inner border border-white/40">
                        <Hash className="w-8 h-8 text-pink-100 drop-shadow-md" />
                    </div>
                    <div className="text-left">
                        <h2 className="text-2xl font-black uppercase tracking-widest drop-shadow-sm">Creadores</h2>
                        <p className="text-pink-100 text-sm font-bold tracking-wide">Redes Sociales y TV</p>
                    </div>
                </div>
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center group-hover:bg-white/30 transition-colors">
                    <ArrowLeft className="w-5 h-5 text-white rotate-180" />
                </div>
            </button>

            <TownCenter 
                toys={townData.toys || []} 
                government={safeGovernment} 
                police={safePolice} 
                laws={townData.laws || []} 
                colleges={townData.colleges || []}
                onUpdateGov={(g) => handleUpdateTownData('government', g, 'ha modificado el gabinete')} 
                onUpdatePolice={(p) => handleUpdateTownData('police', p, 'ha actualizado la estación de policía')} 
                onAddLaw={(l) => { const newLaws = [l, ...(townData.laws || [])]; handleUpdateTownData('laws', newLaws, `ha promulgado la ley: ${l.title}`); }} 
                onUpdateColleges={(c) => handleUpdateTownData('colleges', c, 'ha actualizado el sistema educativo')}
                onToggleFullScreen={setIsFullScreen} 
            />
          </div>
        )}

        {isCreatingFamily && (
            <FullScreenPage noScroll={true}>
                <ToyForm toys={townData.toys || []} onAddToy={addToy} onCancel={() => setIsCreatingFamily(false)} />
            </FullScreenPage>
        )}

        {appView === 'family_detail' && selectedFamily && !isCreatingFamily && (
          <FullScreenPage>
             <div className="w-full">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
                    <div className="flex items-center gap-3"><button onClick={() => { window.history.back(); setIsAddingMember(false); setEditingToy(null); setIsCreatingSubFamily(false); }} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors shadow-sm active:scale-95 btn-press"><ArrowLeft className="w-5 h-5 text-slate-600" /></button><div><h2 className="text-2xl sm:text-3xl font-extrabold text-slate-800 break-words leading-tight flex items-center gap-2"><Users className="w-6 h-6 text-blue-500"/>{selectedFamily}</h2><p className="text-sm text-slate-500 font-bold">Gestión Familiar</p></div></div>
                    <div className="flex gap-2 w-full sm:w-auto"><button onClick={navGoHome} className="px-4 py-2.5 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 shadow-sm flex items-center gap-2 flex-1 sm:flex-none justify-center active:scale-95 btn-press"><Home className="w-4 h-4"/> Inicio</button></div>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    {(isAddingMember || editingToy || isCreatingSubFamily) && (
                        <FullScreenPage noScroll={false}>
                            <ToyForm 
                                toys={townData.toys || []} 
                                fixedFamily={selectedFamily} 
                                fixedSubFamily={targetSubFamily} 
                                editingToy={editingToy} 
                                onAddToy={addToy} 
                                onUpdateToy={updateToy} 
                                onCancel={() => { setIsAddingMember(false); setEditingToy(null); setIsCreatingSubFamily(false); setTargetSubFamily(null); }} 
                                isCreatingSubFamily={isCreatingSubFamily} 
                            />
                        </FullScreenPage>
                    )}
                    <div className="lg:col-span-12"><div className="flex items-center justify-between mb-4 px-2"><h3 className="text-lg font-bold text-slate-700 flex items-center gap-2"><Users className="w-5 h-5 text-blue-500" /> Núcleo Familiar</h3><button onClick={() => { setIsAddingMember(true); setTargetSubFamily(null); }} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-xl shadow-lg shadow-blue-200 active:scale-95 transition-all flex items-center gap-2 text-xs btn-press"><Plus className="w-4 h-4" /> <span>Añadir Integrante</span></button></div><div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden"><ToyList toys={mainFamilyMembers} onDelete={setConfirmDeleteId} onEdit={(toy) => { setEditingToy(toy); setIsAddingMember(false); setIsCreatingSubFamily(false); setTargetSubFamily(null); }} /></div></div>
                    {Object.entries(subFamiliesGrouped).map(([subName, members]) => (<div key={subName} className="lg:col-span-12 mt-4"><div className="flex items-center justify-between mb-3 px-2"><h3 className="text-lg font-bold text-purple-700 flex items-center gap-2"><Crown className="w-5 h-5 text-purple-500" /> Sub-familia: {subName}</h3><button onClick={() => { setIsAddingMember(true); setTargetSubFamily(subName); }} className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-xl shadow-lg shadow-purple-200 active:scale-95 transition-all flex items-center gap-2 text-xs btn-press"><Plus className="w-4 h-4" /> <span>Añadir Integrante</span></button></div><div className="bg-purple-50/50 rounded-2xl shadow-sm border border-purple-100 overflow-hidden"><ToyList toys={[...(members as Toy[])].sort((a,b) => a.name.localeCompare(b.name, 'es', { sensitivity: 'base' }))} onDelete={setConfirmDeleteId} onEdit={(toy) => { setEditingToy(toy); setIsAddingMember(false); setIsCreatingSubFamily(false); setTargetSubFamily(subName); }} /></div></div>))}
                    <div className="lg:col-span-12 mt-4 flex justify-center pb-10"><button onClick={() => { setIsCreatingSubFamily(true); setTargetSubFamily(null); }} className="bg-white border-2 border-dashed border-purple-300 text-purple-600 hover:bg-purple-50 font-bold py-4 px-8 rounded-2xl transition-all flex items-center gap-2 w-full max-w-md justify-center active:scale-95 btn-press"><Plus className="w-5 h-5" /> Crear Nueva Sub-familia (Residentes)</button></div>
                </div>
             </div>
          </FullScreenPage>
        )}
      </main>
    </div>
  );
}

export default App;
